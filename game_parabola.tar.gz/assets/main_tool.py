# ==========================================
# main_tool.py  -  shared engine for Mr. Chung's Pokemon Math Battle (Precalculus 11)
#   Scaling, fonts, math text (x^2, <=, infinity...), animations, Pokemon, moves,
#   buttons, messages and music.
#   No game content lives here; main.py supplies the questions, graphs and battles.
# ==========================================
import pygame
import random
import os
import sys


# ==========================================
# 1. PATHS & SCALING
# ==========================================
def resource_path(relative_path):
    base_path = getattr(sys, "_MEIPASS", os.path.abspath("."))
    return os.path.join(base_path, relative_path)


BASE_W, BASE_H = 1080, 950
curr_w, curr_h = 1080, 950


def rx(x): return int((x / BASE_W) * curr_w)
def ry(y): return int((y / BASE_H) * curr_h)
def rs(size): return max(2, int(size * min(curr_w / BASE_W, curr_h / BASE_H)))


# ==========================================
# 2. FONTS & TEXT
# ==========================================
FONT_PATH = "caslon.ttf"
_font_cache = {}


def get_font(size):
    scaled = rs(size)
    if scaled not in _font_cache:
        _font_cache[scaled] = pygame.font.Font(resource_path(FONT_PATH), scaled)
    return _font_cache[scaled]


def draw_text(surface, text, color, base_x, base_y, base_size=26):
    """Plain text (Pokemon names and HP)."""
    surface.blit(get_font(base_size).render(text, True, color), (rx(base_x), ry(base_y)))


# ---------- Math text: x^2, <=, infinity ... with safe fallbacks ----------
# "x^2" is always drawn as a small raised 2, so it works in any font.
# If caslon.ttf is missing one of the math symbols below, a plain-text
# version is used instead (e.g. "<=" for the one-character version), so nothing shows as a box.
_FALLBACK = {
    "\u2264": "<=", "\u2265": ">=", "\u221e": "inf", "\u2212": "-",
    "\u222a": "U", "\u211d": "R", "\u00b1": "+/-", "\u2208": "in",
}
_glyph_ok = {}


def _tobytes(surf):
    fn = getattr(pygame.image, "tobytes", None) or pygame.image.tostring
    return fn(surf, "RGB")


def _font_has(ch):
    """True if caslon.ttf really draws ch (not the 'missing character' box)."""
    if ch not in _glyph_ok:
        ok = False
        try:
            f = pygame.font.Font(resource_path(FONT_PATH), 40)
            m = f.metrics(ch)
            if m and m[0] is not None:
                ok = True
                s = _tobytes(f.render(ch, True, (0, 0, 0), (255, 255, 255)))
                for missing in ("\uffff", "\ufffe"):
                    try:
                        if s == _tobytes(f.render(missing, True, (0, 0, 0), (255, 255, 255))):
                            ok = False
                    except Exception:
                        pass
        except Exception:
            ok = False
        _glyph_ok[ch] = ok
    return _glyph_ok[ch]


def clean_text(t):
    for ch, alt in _FALLBACK.items():
        if ch in t and not _font_has(ch):
            t = t.replace(ch, alt)
    return t


_rich_cache = {}


def render_rich(text, size, color):
    """Text surface with every '\u00b2' drawn as a small raised 2 (cached)."""
    key = (text, size, tuple(color))
    surf = _rich_cache.get(key)
    if surf is None:
        if len(_rich_cache) > 3000:
            _rich_cache.clear()
        t = clean_text(text)
        font = get_font(size)
        small = get_font(max(8, int(size * 0.62)))
        pieces = []
        chunks = t.split("\u00b2")
        for i, ch in enumerate(chunks):
            if ch:
                pieces.append((font.render(ch, True, color), False))
            if i < len(chunks) - 1:
                pieces.append((small.render("2", True, color), True))
        h = font.get_height()
        w = sum(p.get_width() for p, _ in pieces)
        surf = pygame.Surface((max(1, w), h), pygame.SRCALPHA)
        x = 0
        for p, sup in pieces:
            surf.blit(p, (x, int(font.get_ascent() * 0.08) if sup else 0))
            x += p.get_width()
        _rich_cache[key] = surf
    return surf


def text_w(text, size):
    return render_rich(text, size, (0, 0, 0)).get_width()


def fit_size(text, size, max_w, min_size=10):
    """Largest font size (<= size) that keeps text within max_w base pixels."""
    while size > min_size and text_w(text, size) > rx(max_w):
        size -= 1
    return size


def draw_center(screen, text, size, color, base_y, base_x=BASE_W / 2):
    s = render_rich(text, size, color)
    screen.blit(s, s.get_rect(center=(rx(base_x), ry(base_y))))


def draw_lines(screen, text, color, base_x, base_y_center, max_w, size=26):
    """Draws text (one line, or two lines split at '\\n'), shrinking it to fit max_w."""
    lines = text.split("\n")
    if len(lines) > 1:
        size = min(size, 21)
    size = min(fit_size(l, size, max_w) for l in lines)
    surfs = [render_rich(l, size, color) for l in lines]
    lh = surfs[0].get_height()
    top = ry(base_y_center) - lh * len(lines) // 2
    for i, s in enumerate(surfs):
        screen.blit(s, (rx(base_x), top + i * lh))


# ==========================================
# 3. ANIMATION FRAMES
# ==========================================
def load_frames(path_template, target_size=None, scale_factor=1.0, max_frames=60):
    """Load 'name (1).gif', 'name (2).gif', ... until a file is missing."""
    frames = []
    for i in range(1, max_frames + 1):
        try:
            img = pygame.image.load(path_template.format(i=i))
        except (pygame.error, FileNotFoundError, OSError):
            break
        if target_size:
            img = pygame.transform.scale(img, target_size)
        elif scale_factor != 1.0:
            img = pygame.transform.scale(img, (int(img.get_width() * scale_factor),
                                               int(img.get_height() * scale_factor)))
        frames.append(img)
    return frames


class Animation:
    def __init__(self, original_frames, speed=4, loop=False):
        self.original_frames = original_frames
        self.frames = original_frames
        self.speed = speed
        self.loop = loop
        self.timer = 0
        self.is_playing = loop
        self.last_size = (BASE_W, BASE_H)

    def play(self):
        self.timer = 0
        self.is_playing = True

    def draw(self, surface, base_x, base_y):
        if not self.is_playing or not self.original_frames:
            return
        if self.last_size != (curr_w, curr_h):          # only rescale if the window changed
            self.frames = [pygame.transform.scale(img, (rx(img.get_width()), ry(img.get_height())))
                           for img in self.original_frames]
            self.last_size = (curr_w, curr_h)

        frame_idx = self.timer // self.speed
        if frame_idx >= len(self.frames):
            if not self.loop:
                self.is_playing = False
                return
            self.timer, frame_idx = 0, 0
        surface.blit(self.frames[frame_idx], (rx(base_x), ry(base_y)))
        self.timer += 1


def load_vfx():
    """All attack/heal effect frames, loaded once."""
    spec = {
        "hit":         ("hit",           (400, 400)),
        "heal":        ("heal",          (400, 400)),
        "firepunch":   ("firepunch",     (500, 500)),
        "thunderbolt": ("lightning",     (200, 500)),
        "hydropump":   ("water",         (600, 600)),
        "thunder":     ("green_thunder", (500, 600)),
        "leaftornado": ("leaf_tornado",  (400, 600)),
    }
    return {key: load_frames(resource_path(f"vfx/{fname} ({{i}}).gif"), target_size=size)
            for key, (fname, size) in spec.items()}


# ==========================================
# 4. POKEMON
# ==========================================
# Screen layout per sprite folder (pokemon0 = player, pokemon1.. = opponents).
#   folder: (ui_x, ui_y, img_x, img_y, thunderbolt_dx, thunderbolt_dy, sprite_scale)
# To add a new opponent: make a folder pokemonN with 'pokemon_N (1).gif'...
# and 'pokemonN_faint.ogg', then add a row here (or it uses DEFAULT_LAYOUT).
FACTION_LAYOUT = {
    0: (575, 485,  50,  350, 70,    0, 0.75),    # Raichu (player)
    1: (150, 100, 625,  -50, 70,    0, 0.8),     # Charizard
    2: (150, 100, 650,  220, 50, -350, 0.8),     # Blastoise
    3: (150, 100, 600,  175, 50, -350, 0.9),     # Venusaur
    4: (150, 100, 700,   80, 50, -350, 1.3),     # Infernape
    5: (150, 100, 650,  130, 50, -350, 1.1),     # Empoleon
    6: (150, 100, 650,  130, 50, -350, 1.1),     # Torterra
    7: (150, 100, 650,  150, 50, -350, 1.0),     # Snorlax  (adjust img_x, img_y, scale as needed)
    8: (150, 100, 650,  150, 50, -350, 1.0),     # Mewtwo   (adjust img_x, img_y, scale as needed)
}
DEFAULT_LAYOUT = (150, 100, 600, 150, 50, -350, 1.0)

_idle_cache = {}     # folder -> idle frames (so replaying a battle doesn't reload gifs)


class Pokemon:
    ANIM_SPEED = {"hit": 3, "heal": 3, "thunderbolt": 3, "firepunch": 4,
                  "hydropump": 4, "thunder": 3, "leaftornado": 3}

    def __init__(self, faction, name, hp, max_hp, attack, defense, vfx_frames):
        self.faction, self.name = faction, name
        self.hp, self.max_hp = hp, max_hp
        self.attack, self.defense = attack, defense
        self.moves = []

        (self.ui_x, self.ui_y, self.img_x, self.img_y,
         self.tb_offset_x, self.tb_offset_y, scale) = FACTION_LAYOUT.get(faction, DEFAULT_LAYOUT)

        if faction not in _idle_cache:
            _idle_cache[faction] = load_frames(
                resource_path(f"pokemon{faction}/pokemon_{faction} ({{i}}).gif"), scale_factor=scale)
        self.animations = {"idle": Animation(_idle_cache[faction], speed=4, loop=True)}
        for key, speed in self.ANIM_SPEED.items():
            self.animations[key] = Animation(vfx_frames.get(key, []), speed=speed)

        try:
            self.faint_sound = pygame.mixer.Sound(resource_path(f"pokemon{faction}/pokemon{faction}_faint.ogg"))
            self.faint_sound.set_volume(0.4)
        except (pygame.error, FileNotFoundError, OSError):
            self.faint_sound = None

    def play_faint_sound(self):
        if self.faint_sound:
            self.faint_sound.play()

    def trigger_vfx(self, effect_data):
        effects = effect_data if isinstance(effect_data, (list, tuple)) else [effect_data]
        for effect in effects:
            if effect in self.animations:
                self.animations[effect].play()

    def draw(self, surface):
        draw_text(surface, self.name, (255, 255, 255), self.ui_x, self.ui_y)
        ratio = max(0, self.hp / self.max_hp)
        pygame.draw.rect(surface, (255, 0, 0), (rx(self.ui_x), ry(self.ui_y + 40), rx(300), ry(12)))
        pygame.draw.rect(surface, (0, 255, 0), (rx(self.ui_x), ry(self.ui_y + 40), rx(300 * ratio), ry(12)))
        draw_text(surface, f"HP: {int(self.hp)} / {int(self.max_hp)}", (255, 255, 255), self.ui_x, self.ui_y + 60)

        x, y, a = self.img_x, self.img_y, self.animations
        a["idle"].draw(surface, x, y)
        a["hit"].draw(surface, x, y + 25)
        a["heal"].draw(surface, x, y)
        a["firepunch"].draw(surface, x - 20, y - 150)
        a["thunderbolt"].draw(surface, x + self.tb_offset_x, y + self.tb_offset_y)
        a["hydropump"].draw(surface, x - 50, y - 50)
        a["thunder"].draw(surface, x - 50, y - 220)
        a["leaftornado"].draw(surface, x - 50, y - 220)


# ==========================================
# 5. MESSAGES, MOVES, BUTTONS
# ==========================================
class MessageSystem:
    def __init__(self):
        self.queue, self.current = [], ""

    def draw(self, surface):
        draw_lines(surface, self.current, (255, 255, 255), 85, 768, 905)

    def add(self, text, target=None, hp_change=0, vfx=None, sound=None):
        self.queue.append({"text": text, "target": target, "hp_change": hp_change, "vfx": vfx, "sound": sound})

    def clear(self):
        self.current = ""

    def has_active_message(self):
        return bool(self.current) or bool(self.queue)

    def update(self):
        if self.current or not self.queue:
            return
        msg = self.queue.pop(0)
        self.current = msg["text"]
        t = msg["target"]
        if t is None:
            return
        t.hp += msg["hp_change"]
        if msg["hp_change"] < 0:
            if msg["vfx"]:   t.trigger_vfx(msg["vfx"])
            if msg["sound"]: msg["sound"].play()
        elif msg["hp_change"] > 0:
            t.trigger_vfx("heal")
        t.hp = max(0, min(t.hp, t.max_hp))


class Move:
    def __init__(self, name, power, miss_chance, crit_chance, category, vfx, sound):
        self.name, self.power = name, power
        self.miss_chance, self.crit_chance = miss_chance, crit_chance
        self.category, self.vfx, self.sound = category, vfx, sound

    def execute(self, attacker, defender, msg_sys, heal_sound_ref):
        msg_sys.add(f"{attacker.name} used {self.name}!")
        if self.category == "heal":
            msg_sys.add(f"{attacker.name} recovered HP!", target=attacker, hp_change=self.power)
            if heal_sound_ref: heal_sound_ref.play()
        elif self.category == "buff":
            attacker.attack *= self.power
            msg_sys.add(f"{attacker.name}'s Attack sharply rose!")
        else:
            damage = int(self.power * (attacker.attack / 100))
            if random.randint(1, 100) <= self.miss_chance:
                msg_sys.add(f"{attacker.name}'s Attack missed!")
            elif random.randint(1, 100) <= self.crit_chance:
                msg_sys.add(f"A critical hit! It dealt {int(damage * 1.5)} damage!",
                            target=defender, hp_change=-int(damage * 1.5), vfx=self.vfx, sound=self.sound)
            else:
                msg_sys.add(f"It dealt {damage} damage!", target=defender, hp_change=-damage,
                            vfx=self.vfx, sound=self.sound)


class Button:
    """Button that can show x^2, <= etc. and shrinks long answers to fit."""
    def __init__(self, base_x, base_y, base_w, base_h, color=(150, 200, 200)):
        self.text = ""
        self.color = color
        self.text_color = (0, 0, 0)
        self.bx, self.by, self.bw, self.bh = base_x, base_y, base_w, base_h

    def rect(self):
        return pygame.Rect(rx(self.bx), ry(self.by), rx(self.bw), ry(self.bh))

    def draw(self, surface, size=24):
        rect = self.rect()
        pygame.draw.rect(surface, self.color, rect)
        pygame.draw.rect(surface, (0, 0, 0), rect, max(1, rs(2)))
        s = render_rich(self.text, fit_size(self.text, size, self.bw - 14), self.text_color)
        surface.blit(s, s.get_rect(center=rect.center))

    def clicked(self, mousepos):
        return self.rect().collidepoint(mousepos)


# ==========================================
# 6. MUSIC
# ==========================================
MUSIC_END_EVENT = pygame.USEREVENT + 1


def play_random_track(music_pool):
    if not music_pool:
        return
    try:
        pygame.mixer.music.load(resource_path(f"music{random.choice(music_pool)}.ogg"))  # pygbag needs OGG
        pygame.mixer.music.set_volume(0.15)
        pygame.mixer.music.play(0)
    except pygame.error:
        pass
