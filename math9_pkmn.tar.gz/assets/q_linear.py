# ==========================================
# q_linear.py  -  Math 9 questions: Linear Relations (Weeks 8-10)
#   (No pygame here: question making only.  main.py shows them, and draws the
#    tables, grids and graphs with main_tool.draw_visual_panel.)
#
#   n = 1  Points, Patterns & Ratios     W8L2  Plot Point and Identify Quadrant, Finding Basic
#                                              Patterns in a Table, Plotting Points, Simple Proportions
#   n = 2  Representing Relations        W8L3  Make Table and Equation Given Linear Situation,
#                                              Make Table, Plot, Graph - Linear L1, Write Equation...
#   n = 3  Equations from Tables         W9L1  Table to Linear Equation (L2, L3), Linear Function
#                                              Context Questions from Table, Find Rates (table)
#   n = 4  Graphing Lines                W9L2  Make Table, Plot, Graph - Linear L2, Vertical and
#                                              Horizontal Lines, Line or not? (is the table linear?)
#   n = 5  Reading Graphs                W9L3-L4  Interpret Linear Graph in Context (MC),
#                                              predicting from a line, interpolate / extrapolate
#   n = 6  Comparing Relations           W9L3-L4  Compare rates (words, tables, graphs, equations),
#                                              steepest / order the slopes, which drains faster,
#                                              which starts higher, Sam's and Jay's mistakes
#   n = 7  Lines from Two Points         W10L1 Rate & Start review (any table, check with a 2nd point)
#                                        W10L2 Two Points -> Equation & Graph
#
# NOT TAUGHT YET (Nov 2026), so these are NOT in GENERATORS (section 9):
#   "When are the two the same?" questions: b6_equal_time, b6_equal_value, b6_interval,
#   b6_solve, b4_cross_slanted.  Put them back in GENERATORS once that lesson is taught.
#   Line of best fit / scatter plots and negative proportions were taken out.
#
# Every question is randomly generated.  Easy warm-up types are rare (about 1 in 8)
# and still need a real step.
#
# What main.py uses:  make_question(n) -> (text, correct, options, visual)
#   visual = None, or a dict with "notes" / "table" / "grid" / "graph"
#   (the format is described in main_tool.py, section 8).
# ==========================================

import random
import re
import itertools
from math import gcd
from fractions import Fraction as F


# ==========================================
# 1. FORMATTING  (plain ASCII only, so every character exists in caslon.ttf)
# ==========================================
def nice(v, q=100):
    """True if v is a whole number of 1/q's (default: at most 2 decimal places)."""
    return (F(v) * q).denominator == 1


def fnum(v):
    """2 -> '2',  -5/2 -> '-2.5',  1/4 -> '0.25'."""
    v = F(v)
    if v.denominator == 1:
        return str(v.numerator)
    n = int(v * 100)
    sign = "-" if n < 0 else ""
    whole, frac = divmod(abs(n), 100)
    return f"{sign}{whole}." + f"{frac:02d}".rstrip("0")


def money(v, cents=None):
    """'$15', '$7.50', '-$3'.  cents=True forces 2 decimals."""
    v = F(v)
    sign, v = ("-" if v < 0 else ""), abs(v)
    if cents is None:
        cents = v.denominator != 1
    if cents:
        return f"{sign}${int(v)}.{int((v - int(v)) * 100):02d}"
    return f"{sign}${v.numerator}"


def term(m, var="x"):
    m = F(m)
    if m == 1:
        return var
    if m == -1:
        return "-" + var
    return f"{fnum(m)}{var}"


def eq(m, b, var="x", yv="y"):
    """y = mx + b in simplest written form (DeltaMath letters allowed: C = 60t + 150)."""
    m, b = F(m), F(b)
    if m == 0:
        return f"{yv} = {fnum(b)}"
    s = term(m, var)
    if b > 0:
        s += f" + {fnum(b)}"
    elif b < 0:
        s += f" - {fnum(-b)}"
    return f"{yv} = {s}"


def vert(a):
    return f"x = {fnum(a)}"


def expr(m, b, var="t", start_first=False):
    """'26 - 2t' (start first) or '3t + 5'."""
    if start_first and b != 0:
        return f"{fnum(b)} {'+' if m > 0 else '-'} {term(abs(m), var)}"
    return eq(m, b, var).split(" = ", 1)[1]


def pt(x, y):
    return f"({fnum(x)}, {fnum(y)})"


def nz(lo, hi):
    return random.choice([i for i in range(lo, hi + 1) if i != 0])


# list formatters: take all 5 values at once so the choices look alike
def as_plain(vals):        return [fnum(v) for v in vals]
def as_money(vals):        return [money(v, any(F(x).denominator != 1 for x in vals)) for v in vals]
def as_units(u):           return lambda vals: [f"{fnum(v)} {u}" for v in vals]
def as_pct(vals):          return [f"{fnum(v)}%" for v in vals]
def as_prefix(p):          return lambda vals: [f"{p}{fnum(v)}" for v in vals]


NAMES = ["Sam", "Jay", "Ava", "Leo", "Mia", "Noah", "Priya", "Kai", "Haya", "Ben", "Tia", "Omar"]


# ==========================================
# 2. QUESTION BUILDING  (1 correct + 4 traps, traps are real student mistakes first)
# ==========================================
class Question:
    __slots__ = ("text", "correct", "options", "visual")

    def __init__(self, text, correct, options, visual):
        self.text, self.correct, self.options, self.visual = text, correct, options, visual

    def key(self):
        return self.text + repr(self.visual)


def grid(make, xs, ys, skip):
    """All combinations make(x, y) except the correct one: balanced wrong answers."""
    return [make(x, y) for x in xs for y in ys if (x, y) != skip]


def _lead_num(o):
    m = re.search(r"-?\$?-?\d+(?:\.\d+)?", o)
    return F(m.group().replace("$", "")) if m else None


def _pick_traps(correct, cands):
    """
    Choose 4 wrong answers from the candidates (real mistakes first) so the choices
    don't give the answer away:
      - the correct answer must not be the one that "looks most like the others"
        (traps that each change one thing would make it the centre of the group);
      - for numbers, the correct answer lands at a random position in size order,
        so "pick the middle one" doesn't work.
    """
    cands = cands[:10]
    if len(cands) <= 4:
        return cands
    target = random.randrange(5)
    best, best_score = None, None
    for combo in itertools.combinations(range(len(cands)), 4):
        opts = [correct] + [cands[i] for i in combo]
        words = [set(o.replace(",", " ").split()) for o in opts]
        typ = [sum(len(w & v) for v in words if v is not w) for w in words]
        score = 0.0
        if typ[0] == max(typ):
            score += 1.0 if typ.count(typ[0]) == 1 else 0.4
        vals = [_lead_num(o) for o in opts]
        if all(v is not None for v in vals):
            uniq = sorted(set(vals))
            if len(uniq) > 1:                         # correct number at a random spot in size order
                rank = uniq.index(vals[0]) / (len(uniq) - 1)
                score += abs(rank - target / 4)
            cnt = [vals.count(v) for v in vals]       # ...and not the number that shows up most
            if cnt[0] == max(cnt) and cnt[0] > 1:
                score += 0.6 if cnt.count(cnt[0]) == cnt[0] else 0.25
        score += 0.012 * sum(combo)                   # prefer the realistic mistakes
        score += random.random() * 0.05
        if best_score is None or score < best_score:
            best, best_score = combo, score
    return [cands[i] for i in best]


def two_way(text, make, a0, w0, alts, w1, visual=None):
    """
    Choices that combine two parts, e.g. "$5, extrapolate" or "Club B, by $8".
    Balanced grid so neither part gives the answer away:
       (a0, w0) correct, (a0, w1), (a2, w0), (a2, w1), (a3, w0 or w1).
    """
    alts = [a for i, a in enumerate(alts) if a != a0 and a not in alts[:i]]
    if len(alts) < 2:
        return None
    lo = [a for a in alts if a < a0]
    hi = [a for a in alts if a > a0]
    side = random.choice(["low", "high", "mix", "mix"])  # correct value lands anywhere in size order
    if side == "low" and len(lo) >= 2:
        a2, a3 = random.sample(lo, 2)
    elif side == "high" and len(hi) >= 2:
        a2, a3 = random.sample(hi, 2)
    elif lo and hi:
        a2, a3 = random.choice(lo), random.choice(hi)
    else:
        a2, a3 = random.sample(alts[:4], 2)
    traps = [make(a0, w1), make(a2, w0), make(a2, w1), make(a3, random.choice([w0, w1]))]
    if len(set(traps + [make(a0, w0)])) < 5:
        return None
    opts = [make(a0, w0)] + traps
    random.shuffle(opts)
    return Question(text, make(a0, w0), opts, visual)


def build(text, correct, traps, visual=None, extra=()):
    """String choices.  traps (real mistakes) are preferred, then shuffled extras."""
    extra = list(extra)
    random.shuffle(extra)
    cands = []
    for t in list(traps) + extra:
        if t and t != correct and t not in cands:
            cands.append(t)
    if len(cands) < 4:
        return None
    opts = [correct] + _pick_traps(correct, cands)
    random.shuffle(opts)
    return Question(text, correct, opts, visual)


def build_num(text, correct, traps, fmt=as_plain, ok=None, visual=None, extra=None):
    """Numeric choices.  ok(v) filters traps (e.g. must be positive / whole)."""
    correct = F(correct)
    ok = ok or (lambda v: nice(v))
    if extra is None:
        extra = [correct + d for d in (1, -1, 2, -2, 3, -3, 5, -5, 10, -10)]
    extra = list(extra)
    random.shuffle(extra)
    vals = [correct]
    for v in list(traps) + extra:
        if v is None:
            continue
        v = F(v)
        if v not in vals and ok(v):
            vals.append(v)
    if len(vals) < 5:
        return None
    vals = vals[:11]
    strs = fmt(vals)
    if len(set(strs)) < len(strs):
        return None
    chosen = [strs[0]] + _pick_traps(strs[0], strs[1:])
    final = fmt([vals[strs.index(x)] for x in chosen])     # re-format the five together (e.g. $5.00)
    correct_s = final[0]
    random.shuffle(final)
    return Question(text, correct_s, final, visual)


def pos_int(v):  return v.denominator == 1 and v > 0
def any_int(v):  return v.denominator == 1
def pos_q(v):    return v > 0 and nice(v, 4)          # money: quarters only
def at_least(k): return lambda v: v.denominator == 1 and v >= k


# ==========================================
# HOW THE QUESTION MIX WORKS
#   Each battle lists its question types with a weight.  Types are tagged
#   E (easy warm-up, low weight), M (worksheet core) or H (DeltaMath level).
#   Easy types are never "freebies": they still need a real step, and they
#   only come up about 1 question in 8.
# ==========================================


# ==========================================
# 3. BATTLE 1 - Points, Patterns & Ratios
#    W8L2 worksheet + DeltaMath: Plot Point and Identify Quadrant,
#    Finding Basic Patterns in a Table, Plotting Points, Simple Proportions
# ==========================================
QUADS = ["Quadrant I", "Quadrant II", "Quadrant III", "Quadrant IV", "On an axis"]
QUAD_OF = {(1, 1): "Quadrant I", (-1, 1): "Quadrant II", (-1, -1): "Quadrant III", (1, -1): "Quadrant IV"}
LETTERS = "ABCDEFGHJKMNPRSTUVW"


def _point_in(where, r=10):
    """Random lattice point in a quadrant name or 'On an axis'."""
    while True:
        if where == "On an axis":
            p = (0, nz(-r, r)) if random.random() < 0.5 else (nz(-r, r), 0)
        else:
            sx, sy = [k for k, v in QUAD_OF.items() if v == where][0]
            p = (sx * random.randint(1, r), sy * random.randint(1, r))
        if abs(p[0]) != abs(p[1]):
            return p


def b1_quadrant():                                   # E  (DeltaMath: identify quadrant)
    if random.random() < 0.5:
        where = random.choice(QUADS)
        x, y = _point_in(where, 9)
        return build(f"Name the quadrant or axis for the point {pt(x, y)}.", where, QUADS)
    where = random.choice(QUADS[:4])
    pts = [_point_in(w, 9) for w in QUADS]
    right = pts[QUADS.index(where)]
    traps = [pt(*p) for p in pts if p != right]
    return build(f"Which point is in {where}?", pt(*right), traps)


def b1_read_point():                                 # M  (Plotting Points, -10..10 grid like DeltaMath)
    pts = []
    while len(pts) < 4:
        x, y = random.randint(-9, 9), random.randint(-9, 9)
        if (x, y) == (0, 0) or (x, y) in pts or (y, x) in pts:
            continue
        if not pts and (abs(x) == abs(y) or (x * y == 0 and random.random() < 0.8)):
            continue                                 # target: swapping x and y must matter
        pts.append((x, y))
    letters = random.sample(LETTERS, 4)
    x, y = pts[0]
    visual = {"grid": {"r": 10, "points": [(px, py, L) for (px, py), L in zip(pts, letters)]}}
    if random.random() < 0.7:
        traps = [pt(y, x), pt(-x, y), pt(x, -y), pt(-y, x), pt(y, -x), pt(-x, -y)]
        return build(f"What are the coordinates of point {letters[0]}?", pt(x, y),
                     traps[:1] + random.sample(traps[1:], 5), visual, extra=[pt(*p) for p in pts[1:]])
    # which letter is at a point?  (the swapped point is drawn too, so swapping is caught)
    pts[1] = (y, x)
    visual["grid"]["points"] = [(px, py, L) for (px, py), L in zip(pts, letters)]
    opts = [f"Point {L}" for L in letters] + ["None of them"]
    return build(f"Which point is at {pt(x, y)}?", f"Point {letters[0]}", opts[1:], visual)


def b1_moves():                                      # M  (Kai's / Jin's mistake)
    while True:
        x, y = nz(-9, 9), nz(-9, 9)
        if abs(x) != abs(y):
            break
    H = lambda v: "right" if v > 0 else "left"
    V = lambda v: "up" if v > 0 else "down"
    if random.random() < 0.5:
        text = f"From (0, 0), go {H(x)} {abs(x)} and {V(y)} {abs(y)}. Which point is it?"
        traps = [pt(y, x), pt(-x, y), pt(x, -y), pt(-x, -y), pt(-y, -x)]
        return build(text, pt(x, y), traps[:2], extra=traps[2:] + grid(pt, [x, -x, y, -y], [y, -y, x, -x], (x, y)))
    mv = lambda a, b: f"{H(a).capitalize()} {abs(a)}, then {V(b)} {abs(b)}"
    swap = f"{H(x).capitalize()} {abs(y)}, then {V(y)} {abs(x)}"
    traps = [swap, mv(-x, y), mv(x, -y), mv(-x, -y)]
    extra = [f"{H(-x).capitalize()} {abs(y)}, then {V(y)} {abs(x)}", f"{H(x).capitalize()} {abs(y)}, then {V(-y)} {abs(x)}",
             f"{H(-x).capitalize()} {abs(y)}, then {V(-y)} {abs(x)}"]
    return build(f"Starting at (0, 0), how do you plot {pt(x, y)}?", mv(x, y), traps[:2], extra=traps[2:] + extra)


def b1_pattern():                                    # M/H (Finding Basic Patterns in a Table + worksheet)
    kind = random.choices(["next", "middle", "rate", "far"], [2, 3, 2, 3])[0]
    while True:
        m = random.choice([3, 4, 5, 6, 7, 8, 9, 10, 12, -2, -3, -4, -5, -6, -7])
        step = 1 if kind in ("next", "far") and random.random() < 0.6 else random.choice([2, 2, 3, 5])
        x0 = random.choice([0, 1, 2]) if step == 1 else random.choice([1, 2, 3, 4])
        n = 5 if kind == "next" else 4
        xs = [x0 + i * step for i in range(n)]
        b = random.randint(-15, 20)
        ys = [m * x + b for x in xs]
        if all(abs(v) <= 60 for v in ys):
            break
    col = m * step
    if kind in ("next", "middle"):
        i = n - 1 if kind == "next" else random.randint(1, n - 2)
        shown = [("?" if k == i else v) for k, v in enumerate(ys)]
        c = ys[i]
        visual = {"table": {"rows": [("x", xs), ("y", shown)]}}
        traps = [ys[i - 1] + m if step > 1 else ys[i - 1] - m, c + col, c - col, c + m, -c, c + 1]
        return build_num("Assuming a linear pattern, find the missing value.", c, traps,
                         ok=any_int, visual=visual)
    visual = {"table": {"rows": [("x", xs), ("y", ys)]}}
    if kind == "rate":
        traps = [col, -m, -col, ys[1] - ys[0] + 1, m + 1, m - 1, step]
        return build_num("How much does y change when x goes up by 1?", m, traps, ok=any_int, visual=visual)
    X = random.choice([10, 12, 15, 20]) if xs[-1] < 10 else xs[-1] + random.choice([5, 7])
    c = m * X + b
    traps = [ys[-1] + col * (X - xs[-1]), m * X, c + m, c - m, ys[0] + m * X, -c]
    return build_num(f"If the pattern continues, what is y when x = {X}?", c, traps, ok=any_int, visual=visual)


def b1_proportion():                                 # M  (Simple Proportions; positive only, like W8L2)
    while True:
        a, b = random.randint(1, 13), random.randint(2, 12)
        if a != b and gcd(a, b) == 1:
            break
    k = random.randint(2, 9)
    sa = a
    pos = lambda v: v > 0 and any_int(v)
    form = random.randrange(4)
    if form == 0:          # a/b = x/c
        c, ans = b * k, sa * k
        text = f"{sa}/{b} = x/{c}"
        traps = [c - b + sa, F(c * b, sa), sa * c, ans + sa, ans - sa, ans + k]
    elif form == 1:        # a/b = c/x
        c, ans = sa * k, b * k
        text = f"{sa}/{b} = {c}/x"
        traps = [c + b - sa, F(c * sa, b), b * c, ans + b, ans - b, ans + k]
    elif form == 2:        # x/c = a/b
        c, ans = b * k, sa * k
        text = f"x/{c} = {sa}/{b}"
        traps = [c - b + sa, F(c * b, sa), sa * c, ans - sa, ans + sa, ans + k]
    else:                  # c/x = a/b
        c, ans = sa * k, b * k
        text = f"{c}/x = {sa}/{b}"
        traps = [c + b - sa, F(c * sa, b), b * c, ans - b, ans + b, ans + k]
    return build_num(f"Solve for x:   {text}", ans, traps, ok=pos)


ITEMS = ["muffins", "pencils", "apples", "stickers", "notebooks", "juice boxes", "granola bars", "erasers"]
PRICES = [F(1, 4), F(1, 2), F(3, 4), F(1), F(5, 4), F(3, 2), F(2), F(5, 2), F(3), F(4)]


def b1_rate_word():                                  # M  (worksheet: muffins / pencils)
    n1 = random.randint(3, 12)
    n2 = random.choice([n for n in range(2, 25) if n != n1 and n % n1])
    if random.random() < 0.75:
        p, item = random.choice(PRICES), random.choice(ITEMS)
        c1, ans = n1 * p, n2 * p
        text = f"{n1} {item} cost {money(c1)}. How much do {n2} {item} cost?"
        traps = [c1 + (n2 - n1), (n2 - n1) * p, ans + p, ans - p, c1 * n2, c1 + n2]
        return build_num(text, ans, traps, fmt=as_money, ok=pos_q,
                         extra=[ans + d for d in (F(1, 2), -F(1, 2), 1, -1, 2, -2)])
    s = random.choice([40, 50, 60, 70, 80, 90, 100])
    t1, t2 = random.randint(2, 5), random.randint(2, 9)
    if t1 == t2:
        t2 += 1
    d1, ans = s * t1, s * t2
    text = f"A car travels {d1} km in {t1} h. How far does it go in {t2} h?"
    traps = [d1 + (t2 - t1), d1 * t2, ans + s, ans - s, s * (t2 + t1)]
    return build_num(text, ans, traps, fmt=as_units("km"), ok=pos_int,
                     extra=[ans + d for d in (10, -10, 20, -20, 5)])


# ==========================================
# 4. BATTLE 2 - Representing Linear Relations
#    W8L3 worksheet + DeltaMath: Make Table and Equation Given Linear Situation,
#    Make Table, Plot, Graph - Linear L1 (y = ax, y = x + b),
#    Write Equation Given Linear Situation
# ==========================================
def situation():
    """A DeltaMath-style word situation.  m < 0 when decreasing.  Letters like C and t."""
    t = random.choice(["elec", "cafe", "truck", "plant", "save", "walk", "wash",
                       "choc", "battery", "drain", "candle", "bus"])
    H = lambda v: f"{fnum(v)}"
    if t == "elec":
        m, b = random.choice([40, 45, 50, 55, 60, 65, 70, 75, 80, 90]), random.choice([50, 60, 75, 80, 90, 100, 120, 125, 150])
        return dict(sent=f"An electrician charges ${m} per hour plus a ${b} set fee.", m=m, b=b, cont=True,
                    Y="C", X="t", ydesc="total cost ($)", xdesc="hours", fmt=as_money,
                    ask=lambda n: f"What is the total cost for {n} hours?",
                    reach=lambda V: f"How many hours of work cost {money(V)}?")
    if t == "cafe":
        m, b = random.choice([1, F(3, 2), 2, F(5, 2), 3, F(7, 2), 4, F(9, 2), 5]), random.randint(2, 12)
        return dict(sent=f"An internet cafe charges ${b} plus {money(m)} per hour.", m=m, b=b, cont=True,
                    Y="C", X="h", ydesc="cost ($)", xdesc="hours", fmt=as_money,
                    ask=lambda n: f"What does {n} hours at the cafe cost?",
                    reach=lambda V: f"How many hours can you stay for {money(V)}?")
    if t == "truck":
        m, b = random.choice([F(1, 2), F(3, 4), 1, F(5, 4), F(3, 2), F(7, 4), 2]), random.choice(range(25, 105, 5))
        return dict(sent=f"A truck rental costs ${b} plus {money(m)} per km.", m=m, b=b, cont=True,
                    Y="C", X="k", ydesc="cost ($)", xdesc="km driven", fmt=as_money, step=4,
                    ask=lambda n: f"What does the truck cost for {n} km?",
                    reach=lambda V: f"How many km can you drive for {money(V)}?")
    if t == "plant":
        m, b = random.choice([2, 3, 4, 5, F(3, 2), F(5, 2)]), random.randint(3, 20)
        return dict(sent=f"A plant is {b} cm tall and grows {H(m)} cm per week.", m=m, b=b, cont=True,
                    Y="H", X="w", ydesc="height (cm)", xdesc="weeks", fmt=as_units("cm"), step=2,
                    ask=lambda n: f"How tall is the plant after {n} weeks?",
                    reach=lambda V: f"After how many weeks is the plant {fnum(V)} cm tall?")
    if t == "save":
        m, b = random.randint(4, 25), random.choice(range(10, 65, 5))
        return dict(sent=f"Ava has ${b} saved and adds ${m} each week.", m=m, b=b, cont=False,
                    Y="S", X="w", ydesc="savings ($)", xdesc="weeks", fmt=as_money,
                    ask=lambda n: f"How much has Ava saved after {n} weeks?",
                    reach=lambda V: f"After how many weeks does Ava have {money(V)}?")
    if t == "walk":
        m = random.choice([3, 4, 5, 6, 7, 10, 11, 12, 13, 14, 15, 16, 18, 20, 22, 24])
        how = "walks" if m < 10 else "bikes"
        who = random.choice(NAMES)
        b = 0 if random.random() < 0.5 else random.randint(1, 12)
        where = "starting from home" if b == 0 else f"starting {b} km from home"
        return dict(sent=f"{who} {how} {m} km each hour, {where}.", m=m, b=b, cont=True,
                    Y="D", X="t", ydesc="distance from home (km)", xdesc="hours", fmt=as_units("km"),
                    ask=lambda n: f"How far from home is {who} after {n} hours?",
                    reach=lambda V: f"After how many hours is {who} {fnum(V)} km from home?")
    if t == "wash":
        m = random.choice([5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 18, 20, 22, 25, 30])
        who = random.choice(NAMES)
        b = 0 if random.random() < 0.6 else random.choice(range(5, 55, 5))
        extra_s = "" if b == 0 else f" plus a ${b} bonus"
        return dict(sent=f"{who} earns ${m} for each car washed{extra_s}.", m=m, b=b, cont=False,
                    Y="P", X="c", ydesc="pay ($)", xdesc="cars washed", fmt=as_money,
                    ask=lambda n: f"How much does {who} earn for {n} cars?",
                    reach=lambda V: f"How many cars must {who} wash to earn {money(V)}?")
    if t == "choc":
        r, T = random.choice([2, 3, 4, 5, 6]), random.randint(5, 15)
        return dict(sent=f"A box has {r * T} chocolates. Jon eats {r} each night.", m=-r, b=r * T, cont=False,
                    Y="C", X="n", ydesc="chocolates left", xdesc="nights", fmt=as_units("left"),
                    ask=lambda n: f"How many chocolates are left after {n} nights?",
                    reach=lambda V: (f"After how many nights are {V} chocolates left?" if V
                                     else "After how many nights is the box empty?"))
    if t == "battery":
        r = random.choice([2, 3, 4, 5, 6, 8, 10, 12, 15, 20])
        b = random.choice([100, 100, 95, 90, 85, 80, 75, 70, 60])
        b = r * (b // r)                             # a whole number of hours until empty
        return dict(sent=f"A phone battery is at {b}% and drops {r}% each hour.", m=-r, b=b, cont=True,
                    Y="B", X="t", ydesc="battery (%)", xdesc="hours", fmt=as_pct,
                    ask=lambda n: f"What is the battery level after {n} hours?",
                    reach=lambda V: f"After how many hours is the battery at {V}%?")
    if t == "drain":
        r, T = random.randint(3, 10), random.randint(5, 15)
        return dict(sent=f"A tank has {r * T} L of water and drains {r} L per minute.", m=-r, b=r * T, cont=True,
                    Y="W", X="t", ydesc="water (L)", xdesc="minutes", fmt=as_units("L"),
                    ask=lambda n: f"How much water is left after {n} minutes?",
                    reach=lambda V: (f"After how many minutes is the tank at {V} L?" if V
                                     else "After how many minutes is the tank empty?"))
    if t == "candle":
        r, T = random.randint(1, 6), random.randint(4, 15)
        return dict(sent=f"A candle is {r * T} cm tall and burns down {r} cm each hour.", m=-r, b=r * T,
                    cont=True, Y="H", X="t", ydesc="height (cm)", xdesc="hours", fmt=as_units("cm"),
                    ask=lambda n: f"How tall is the candle after {n} hours?",
                    reach=lambda V: (f"After how many hours is the candle {V} cm tall?" if V
                                     else "After how many hours is the candle gone?"))
    r, T = random.randint(2, 8), random.randint(5, 20)
    return dict(sent=f"A ${r * T} bus pass loses ${r} for each ride.", m=-r, b=r * T, cont=False,
                Y="B", X="r", ydesc="money left on pass ($)", xdesc="rides", fmt=as_money,
                ask=lambda n: f"How much is left on the pass after {n} rides?",
                reach=lambda V: f"After how many rides is {money(V)} left?")


def _sit_visual(s):
    return {"notes": [s["sent"], f"({s['Y']} = {s['ydesc']},  {s['X']} = {s['xdesc']})"]}


def b2_words_eq():                                   # M  (Make Table and Equation Given Linear Situation)
    s = situation()
    m, b, X, Y = s["m"], s["b"], s["X"], s["Y"]
    e = lambda mm, bb: eq(mm, bb, X, Y)
    traps = [e(b, m), e(-m, b), e(m, -b), e(m, 0), e(m + b, 0), e(-b, m)]
    extra = [e(1, m), e(m, m), e(-m, -b)] + grid(e, [m, -m, b], [b, -b, 0], (m, b))
    return build(f"Which equation gives {Y} in terms of {X}?", e(m, b), traps[:3], _sit_visual(s),
                 extra=traps[3:] + extra)


def b2_words_value():                                # M  (make a table / predict from the situation)
    s = situation()
    m, b = s["m"], s["b"]
    step = s.get("step", 1)
    if m > 0 and random.random() < 0.65:
        n = random.choice([k for k in range(3, 16) if k % step == 0])
        ans = m * n + b
        traps = [b + m, m * n, b * n + m, b + m * (n - 1), (b + m) * n, ans + m]
        ok = (lambda v: v > 0 and nice(v, 4)) if s["fmt"] is as_money else (lambda v: v > 0 and nice(v, 2))
        return build_num(s["ask"](n), ans, traps, fmt=s["fmt"], ok=ok, visual=_sit_visual(s))
    if m > 0:                                        # how long until it reaches a value (harder)
        t = random.choice([k for k in range(3, 16) if k % step == 0])
        V = m * t + b
        traps = [F(V, m), F(V + b, m), V - b, t + 1, t - 1, t + step]
        return build_num(s["reach"](V), t, traps, fmt=as_units(s["xdesc"].split()[0]), ok=at_least(2),
                         visual=_sit_visual(s))
    r, T = -m, F(b, -m)
    if T.denominator != 1 or T < 4:
        return None
    t = random.randint(2, int(T) - 1) if random.random() < 0.75 else int(T)
    V = b - r * t
    traps = [F(V, r), T, b - V, t + 1, t - 1, F(b + V, r)]
    return build_num(s["reach"](V), t, traps, fmt=as_units(s["xdesc"]), ok=at_least(2), visual=_sit_visual(s))


def _eval_traps(m, b, x):
    c = m * x + b
    return [-(m * x) + b, m * x - b, -(m * x) - b, m + x + b, c + m, x * (m + b)]


def b2_evaluate():                                   # E
    m, b = nz(-9, 9), nz(-12, 12)
    x = nz(-6, 9)
    return build_num(f"If {eq(m, b)}, find y when x = {x}.", m * x + b, _eval_traps(m, b, x), ok=any_int)


def b2_table_from_eq():                              # M  (Make Table, Plot, Graph L1: y = ax, y = x + b)
    form = random.choices(["ax", "xb", "mxb"], [4, 3, 3])[0]
    m = nz(-6, 6) if form != "xb" else 1
    if form == "ax" and abs(m) == 1:
        m = random.choice([-6, -5, -4, -3, -2, 2, 3, 4, 5, 6])
    b = 0 if form == "ax" else nz(-12, 12)
    xs = random.choice([[-3, -2, -1, 0, 1, 2, 3], [-4, -3, -2, -1, 0, 1, 2], [-2, -1, 0, 1, 2, 3, 4],
                        [-5, -4, -3, -2, -1, 0, 1]])
    i = random.choice([k for k, x in enumerate(xs) if x != 0 and (form != "xb" or x < 0)])
    x = xs[i]
    shown = [("?" if k == i else "") for k in range(len(xs))]
    visual = {"table": {"rows": [("x", xs), (eq(m, b), shown)]}}
    traps = _eval_traps(m, b, x) + [m * x + b + (1 if m > 0 else -1), x - b, b - x]
    return build_num("Complete the table. What goes in the ? box?", m * x + b, traps, ok=any_int, visual=visual)


def _eq_traps(m, b, y_first):
    return [eq(b, m), eq(-m, b), eq(m, y_first), eq(m, -b), eq(-m, -b)], \
           [eq(m + 1, b), eq(m - 1, b), eq(m, b + m), eq(m, b - m)] + grid(eq, [m, -m, b], [b, -b, y_first], (m, b))


def b2_match_table():                                # M  (worksheet: Match It Four Ways)
    while True:
        m, b = nz(-6, 6), random.randint(0, 24)
        xs = random.choice([[0, 1, 2, 3], [1, 2, 3, 4], [2, 3, 4, 5], [0, 1, 2, 3, 4]])
        ys = [m * x + b for x in xs]
        if min(ys) >= 0 and b != m:
            break
    traps, extra = _eq_traps(m, b, ys[1] if xs[0] == 0 else ys[0])
    visual = {"table": {"rows": [("x", xs), ("y", ys)]}}
    return build("Which equation matches the table?", eq(m, b), traps, visual, extra)


def b2_match_graph():                                # M  (worksheet: Match It Four Ways)
    while True:
        m = random.choice([1, 2, 3, 4, 5, 6, -1, -2, -3, -4, -5, -6])
        b = random.randint(0, 36)
        xmax = random.choice([4, 5, 6])
        ys = [m * x + b for x in range(xmax + 1)]
        if min(ys) >= 0 and max(ys) <= 40 and b != m:
            break
    ystep = 2 if max(ys) <= 16 else (4 if max(ys) <= 24 else 5)
    ymax = -(-max(ys) // ystep) * ystep
    graph = {"title": "", "xlabel": "x", "ylabel": "y", "xmax": xmax, "xstep": 1,
             "ymax": ymax, "ystep": ystep, "line": (m, b), "pts": [(x, m * x + b) for x in range(xmax + 1)]}
    traps, extra = _eq_traps(m, b, ys[1])
    return build("Which equation matches the graph?", eq(m, b), traps, {"graph": graph}, extra)


GRAPH_TYPES = ["Solid line going up", "Solid line going down", "Dots going up", "Dots going down", "Flat line"]


def b2_graph_type():                                 # M  (worksheet: discrete or continuous)
    k = random.randint(2, 15)
    p = random.choice([2, 3, 4, 5, 6, 8, 10, 12, 15, 18, 20, 25, 30])
    options = [
        (f"Concert tickets cost ${p} each.", "Dots going up"),
        (f"Muffins cost ${random.randint(2, 4)} each.", "Dots going up"),
        (f"A team scores {k} points for each goal.", "Dots going up"),
        (f"Mia earns ${p} for each car she washes.", "Dots going up"),
        (f"A ${p * 5} bus pass loses ${p} for each ride.", "Dots going down"),
        (f"A jar has {k * 10} candies. Each student takes {k}.", "Dots going down"),
        (f"A box has {k * 6} chocolates. Jon eats {k} each night.", "Dots going down"),
        (f"A tank fills {k} L per minute.", "Solid line going up"),
        (f"A plant grows {k} cm each week.", "Solid line going up"),
        (f"Leo walks {random.randint(3, 6)} km per hour.", "Solid line going up"),
        (f"A candle burns down {k} cm each hour.", "Solid line going down"),
        (f"A phone battery drops {k}% each hour.", "Solid line going down"),
        (f"A pool drains {k * 10} L per minute.", "Solid line going down"),
        (f"Each bracelet uses {k} beads.", "Dots going up"),
        (f"A school buys {k} new laptops each month.", "Dots going up"),
        (f"A roll of {k * 20} stamps loses {k} for each letter.", "Dots going down"),
        (f"A car's gas tank loses {k} L each hour.", "Solid line going down"),
        (f"Snow piles up {k} cm each hour.", "Solid line going up"),
        (f"An elevator goes down {k} m each second.", "Solid line going down"),
        (f"A taxi charges ${random.randint(3, 6)} plus ${k} per km.", "Solid line going up"),
        (f"A gym charges ${random.choice([10, 15, 20, 25])} to join plus ${k} per visit.", "Dots going up"),
        (f"A pool has {random.randint(2, 9) * 100} L and fills {k * 5} L per minute.", "Solid line going up"),
    ]
    sent, ans = random.choice(options)
    return build(f"{sent} Which graph fits?", ans, GRAPH_TYPES)


def b2_point_on_graph():                             # M  (Make Table, Plot, Graph: which point belongs)
    form = random.choice(["ax", "xb", "mxb"])
    m = 1 if form == "xb" else random.choice([-4, -3, -2, 2, 3, 4])
    b = 0 if form == "ax" else nz(-9, 9)
    return _point_on_line(m, b, f"Which point is on the graph of {eq(m, b)}?")


# ==========================================
# 5. BATTLE 3 - Writing Equations from Tables
#    W9L1 worksheet + DeltaMath: Table to Linear Equation (Level 2) and (Level 3),
#    Linear Function Context Questions from Table, Find Rates (table),
#    Write Equation Given Linear Situation
# ==========================================
def rand_table(avoid_zero=False):
    """L2: x = 1..4.  L3: x starts negative, equal steps of 2-5.  Worksheet: uneven gaps."""
    while True:
        r = random.random()
        m = F(0) if r < 0.07 else (F(random.choice([1, -1]), 2) if r < 0.15 else F(nz(-7, 7)))
        b = F(random.randint(-12, 12))
        if m == 0 and b == 0:
            continue
        style = random.choices(["L2", "L3", "uneven"], [3, 5, 3])[0]
        if style == "L2":
            xs = [1, 2, 3, 4]
        elif style == "L3":
            s = random.randint(2, 5)
            x0 = random.randint(-4, -1)
            xs = [x0 + k * s for k in range(4)]
        else:
            xs = random.choice([[2, 4, 8, 10], [1, 2, 5, 7], [0, 1, 3, 6], [-2, 0, 1, 4],
                                [2, 4, 8, 9], [1, 3, 4, 8], [-3, -1, 2, 6]])
        if avoid_zero and 0 in xs:
            continue
        if m.denominator == 2 and any(x % 2 for x in xs):
            continue
        ys = [m * x + b for x in xs]
        if all(abs(y) <= 60 for y in ys):
            return m, b, xs, ys


def _col_mistake(xs, ys):
    """Rate = change in y between columns (forgetting x skips)."""
    if xs[1] - xs[0] == 1:
        return None, None
    r = ys[1] - ys[0]
    return r, ys[0] - r * xs[0]


def _tbl(xs, ys):
    return {"table": {"rows": [("x", xs), ("y", [fnum(v) for v in ys])]}}


def b3_equation():                                   # M/H (Table to Linear Equation L2/L3)
    m, b, xs, ys = rand_table()
    visual = _tbl(xs, ys)
    if m == 0:
        return build("Which equation matches the table?", eq(0, b),
                     [vert(b), eq(b, 0), eq(1, b), eq(0, -b), vert(-b)], visual)
    r2, b2 = _col_mistake(xs, ys)
    traps = [eq(r2, b2) if r2 is not None else None,
             eq(m, ys[0]) if xs[0] != 0 else None, eq(-m, b), eq(b, m), eq(m, -b)]
    extra = [eq(m, b + m), eq(m, b - m), eq(-m, -b)] + grid(eq, [m, -m] + ([r2] if r2 is not None else [b]),
                                                         [b, -b, ys[0]], (m, b))
    return build("Which equation matches the table?", eq(m, b), traps, visual, extra)


def b3_rate():                                       # M  (Find Rates: table)
    m, b, xs, ys = rand_table()
    if m == 0 or xs[1] - xs[0] == 1 and random.random() < 0.6:
        return None                                  # prefer tables where x skips
    r2, _ = _col_mistake(xs, ys)
    traps = [r2, -m, -r2 if r2 is not None else None, 1 / m, ys[0], b]
    step = F(1, 2) if m.denominator == 2 else 1
    extra = [m + step, m - step, m + 2 * step, m - 2 * step, m + 3]
    return build_num("Find the rate (slope) from the table.", m, traps, ok=lambda v: nice(v, 4),
                     visual=_tbl(xs, ys), extra=extra)


def b3_start():                                      # M  (y-intercept: work backwards to x = 0)
    m, b, xs, ys = rand_table(avoid_zero=True)
    _, b2 = _col_mistake(xs, ys)
    traps = [ys[0], -b, b + m, b - m, b2, ys[0] - m]
    return build_num("Find the start (y-intercept) from the table.", b, traps,
                     ok=lambda v: nice(v, 2), visual=_tbl(xs, ys))


def table_context():
    """DeltaMath 'Linear Function Context Questions from Table' situations."""
    t = random.choice(["elec", "sales", "truck", "choc", "battery", "coffee", "loan", "plant", "pool"])
    if t == "elec":
        m, b = random.choice([40, 45, 50, 60, 75, 80]), random.choice([50, 60, 75, 80, 100, 120, 150])
        c = dict(intro="An electrician charges a set fee plus an hourly rate.", xh="hours (t)", yh="cost C ($)",
                 X="t", Y="C", fmt=as_money, xu="hours", rate=lambda v: f"{money(v)} per hour",
                 q_rate="What is the hourly rate?", q_start="What is the set fee for a house call?",
                 q_val=lambda n: f"What is the total cost for {n} hours of work?",
                 q_inv=lambda V: f"How many hours of work cost {money(V)}?", xr=(1, 9))
    elif t == "sales":
        m, b = random.choice([15, 20, 25, 30, 40, 50]), random.choice([60, 80, 100, 120, 150])
        c = dict(intro="Mia earns base pay plus a commission for each laptop she sells.",
                 xh="laptops sold (x)", yh="pay P ($)", X="x", Y="P", fmt=as_money, xu="laptops",
                 rate=lambda v: f"{money(v)} per laptop", q_rate="What commission does Mia earn per laptop?",
                 q_start="What is Mia's base pay?", q_val=lambda n: f"What is Mia's pay if she sells {n} laptops?",
                 q_inv=lambda V: f"How many laptops must Mia sell to earn {money(V)}?", xr=(1, 12))
    elif t == "truck":
        m, b = random.choice([F(1, 2), F(3, 4), F(5, 4), F(3, 2), 2]), random.choice([40, 50, 60, 75])
        c = dict(intro="A truck rental has a starting charge plus a fee per km.", xh="km (k)", yh="cost C ($)",
                 X="k", Y="C", fmt=as_money, xu="km", rate=lambda v: f"{money(v)} per km",
                 q_rate="What is the fee per km?", q_start="What is the starting charge?",
                 q_val=lambda n: f"What does the truck cost for {n} km?",
                 q_inv=lambda V: f"How many km can you drive for {money(V)}?", xr=(10, 120), xstep=10)
    elif t == "plant":
        m, b = random.choice([2, 3, 4, F(3, 2), F(5, 2)]), random.randint(3, 15)
        c = dict(intro="The height of a plant, t weeks after it was bought.", xh="weeks (t)", yh="height H (cm)",
                 X="t", Y="H", fmt=as_units("cm"), xu="weeks", rate=lambda v: f"{fnum(v)} cm per week",
                 q_rate="How fast does the plant grow?", q_start="How tall was the plant when it was bought?",
                 q_val=lambda n: f"How tall is the plant after {n} weeks?",
                 q_inv=lambda V: f"After how many weeks is the plant {fnum(V)} cm tall?", xr=(1, 12), xstep=2)
    elif t == "choc":
        r, T = random.choice([2, 3, 4, 5]), random.randint(8, 14)
        m, b = -r, r * T
        c = dict(intro="Chocolates left in a box, t days after a birthday.", xh="days (t)",
                 yh="chocolates left (C)", X="t", Y="C", fmt=as_units("chocolates"), xu="days",
                 rate=lambda v: f"{fnum(v)} chocolates per day",
                 q_rate="What is the rate of change, with units?", q_start="How many chocolates were in the full box?",
                 q_val=lambda n: f"How many chocolates are left after {n} days?",
                 q_inv=lambda V: (f"After how many days are {V} chocolates left?" if V
                                  else "After how many days is the box empty?"), xr=(1, T))
    elif t == "battery":
        r, b = random.choice([4, 5, 6, 8, 10]), random.choice([80, 90, 100])
        T = F(b, r)
        m = -r
        c = dict(intro="A phone's battery level, t hours after leaving home.", xh="hours (t)", yh="battery B (%)",
                 X="t", Y="B", fmt=as_pct, xu="hours", rate=lambda v: f"{fnum(v)}% per hour",
                 q_rate="What is the rate of change, with units?", q_start="What was the battery level when leaving home?",
                 q_val=lambda n: f"What is the battery level after {n} hours?",
                 q_inv=lambda V: f"After how many hours is the battery at {V}%?", xr=(1, int(T)))
    elif t == "coffee":
        r, T = random.choice([3, 4, 5]), random.randint(8, 15)
        m, b = -r, r * T
        c = dict(intro="Money left on a coffee card after buying x coffees.", xh="coffees (x)", yh="card A ($)",
                 X="x", Y="A", fmt=as_money, xu="coffees", rate=lambda v: f"{money(v)} per coffee",
                 q_rate="What is the rate of change, with units?", q_start="How much money was on the card at first?",
                 q_val=lambda n: f"How much is left after {n} coffees?",
                 q_inv=lambda V: (f"After how many coffees is {money(V)} left?" if V
                                  else "How many coffees can the full card buy?"), xr=(1, T))
    elif t == "loan":
        r, T = random.choice([10, 15, 20, 25]), random.randint(6, 12)
        m, b = -r, r * T
        c = dict(intro="Morgan pays back a loan to a friend each week.", xh="weeks (t)", yh="owed L ($)",
                 X="t", Y="L", fmt=as_money, xu="weeks", rate=lambda v: f"{money(v)} per week",
                 q_rate="What is the rate of change, with units?", q_start="How much did Morgan borrow?",
                 q_val=lambda n: f"How much does Morgan owe after {n} weeks?",
                 q_inv=lambda V: (f"After how many weeks does Morgan owe {money(V)}?" if V
                                  else "After how many weeks is the loan paid off?"), xr=(1, T))
    else:
        k, T = random.choice([10, 20, 25, 30, 40, 50]), random.randint(20, 60)
        m, b = -k, k * T
        c = dict(intro="A pool is draining.", xh="minutes (t)", yh="water W (L)",
                 X="t", Y="W", fmt=as_units("L"), xu="minutes", rate=lambda v: f"{fnum(v)} L per minute",
                 q_rate="What is the rate of change, with units?", q_start="How much water was in the pool at the start?",
                 q_val=lambda n: f"How much water is left after {n} minutes?",
                 q_inv=lambda V: (f"After how many minutes is the pool at {V} L?" if V
                                  else "When will the pool be empty?"), xr=(2, T), xstep=random.choice([1, 5]))
    c.update(m=F(m), b=F(b))
    lo, hi = c["xr"]
    xstep = c.get("xstep", 1)
    if F(c["m"]).denominator == 2:
        xstep = max(xstep, 2)
    choices = [x for x in range(lo, hi) if x % xstep == 0 and x > 1]
    xs = sorted(random.sample(choices, 3))
    if random.random() < 0.3:                         # DeltaMath tables often have x = 2.5, 9.5 ...
        k = random.randrange(3)
        h = xs[k] + F(xstep, 2)
        q = 4 if c["fmt"] is as_money else 1
        if h not in xs and h < hi and nice(c["m"] * h, q) and (k == 2 or h < xs[k + 1]):
            xs[k] = h
    c["xs"] = xs
    c["ys"] = [c["m"] * x + c["b"] for x in xs]
    c["free"] = [x for x in choices if x not in xs]
    cell = (lambda v: money(v, any(F(y).denominator != 1 for y in c["ys"]))[1:]) if c["fmt"] is as_money else fnum
    c["visual"] = {"notes": [c["intro"]],
                   "table": {"rows": [(c["xh"], [fnum(x) for x in xs]), (c["yh"], [cell(v) for v in c["ys"]])]}}
    return c


def b3_context():                                    # H  (Linear Function Context Questions from Table)
    c = table_context()
    m, b, xs, ys = c["m"], c["b"], c["xs"], c["ys"]
    fmt, vis = c["fmt"], c["visual"]
    dy, dx = ys[1] - ys[0], xs[1] - xs[0]
    money_like = fmt is as_money
    okv = (lambda v: v >= 0 and nice(v, 4)) if money_like else (lambda v: v >= 0 and nice(v, 2))
    T = F(-b, m) if m < 0 else None
    kinds, wts = ["rate", "start", "val", "inv"], [3, 3, 2, 2]
    if T is not None and T.denominator == 1 and T not in xs:
        kinds.append("xint"); wts.append(2)          # "when is it empty / paid off?"
    kind = random.choices(kinds, wts)[0]
    if kind == "xint":
        traps = [T + 1, T - 1, F(b, -dy) if dy else None, xs[-1], F(ys[-1], -m) + 1]
        return build_num(c["q_inv"](0), T, traps, fmt=as_units(c["xu"]), ok=lambda v: pos_int(v) and v > 1,
                         visual=vis)
    if kind == "rate":
        rate_all = lambda vals: [c["rate"](v) for v in vals]
        traps = [dy if dx != 1 else None, -m, ys[0] / xs[0], dx / dy, ys[-1] - ys[0]]
        return build_num(c["q_rate"], m, traps, fmt=rate_all, ok=lambda v: nice(v, 4) and v != 0, visual=vis,
                         extra=[m * 2, m + (5 if abs(m) >= 10 else 1), m - (5 if abs(m) >= 10 else 1)])
    if kind == "start":
        traps = [ys[0], ys[0] + m * xs[0], b + m, b - m, ys[0] - dy]
        return build_num(c["q_start"], b, traps, fmt=fmt, ok=okv, visual=vis)
    if not c["free"]:
        return None
    n = random.choice(c["free"])
    if kind == "val":
        ans = m * n + b
        near = min(xs, key=lambda x: abs(x - n))
        traps = [m * n, ys[0] + m * n, ys[xs.index(near)] + dy * (n - near), ans + m, ans - m, -ans]
        return build_num(c["q_val"](n), ans, traps, fmt=fmt, ok=okv, visual=vis)
    V = m * n + b
    traps = [F(V, m), F(V + b, m), F(V - b, -m), n + 1, n - 1, F(V - b, dy) if dy else None]
    return build_num(c["q_inv"](V), n, traps, fmt=as_units(c["xu"]), ok=lambda v: v.denominator == 1 and v > 0,
                     visual=vis)


def b3_two_points():                                 # H  (W9L1 taxi table / Write Equation Given Linear Situation)
    t = random.choice(["plant", "salary", "pool", "rent"])
    while True:
        x1 = random.randint(1, 4)
        x2 = x1 + random.randint(2, 6)
        if t == "plant":
            m, b = random.randint(2, 6), random.randint(3, 12)
            sent = f"A plant is {m * x1 + b} cm tall after {x1} weeks and {m * x2 + b} cm after {x2} weeks."
            X, Y = "w", "H"
        elif t == "salary":
            m, b = random.choice([1000, 1500, 2000, 2500]), random.choice([40000, 45000, 50000])
            sent = f"Lucy earns ${m * x1 + b} in year {x1} and ${m * x2 + b} in year {x2}."
            X, Y = "n", "S"
        elif t == "pool":
            m, b = -random.choice([20, 25, 40, 50]), random.choice([800, 1000, 1200])
            sent = f"A pool has {m * x1 + b} L after {x1} min and {m * x2 + b} L after {x2} min."
            X, Y = "t", "W"
        else:
            m, b = random.choice([5, 10, 15, 20]), random.choice([20, 30, 50])
            sent = f"Renting a canoe costs ${m * x1 + b} for {x1} h and ${m * x2 + b} for {x2} h."
            X, Y = "h", "C"
        if m * x2 + b > 0:
            break
    y1 = m * x1 + b
    dy = m * (x2 - x1)
    e = lambda mm, bb: eq(mm, bb, X, Y)
    half = dy / x2                                   # divided by x2 instead of (x2 - x1)
    traps = [e(m, y1), e(dy, b), e(-m, b), e(b, m), e(m, y1 - m)] + ([e(half, b)] if nice(half) and half != m else [])
    extra = [e(m, b + m), e(m, -b), e(dy, y1 - dy * x1)] + grid(e, [m, -m, dy], [b, -b, y1], (m, b))
    return build(f"Which equation gives {Y} in terms of {X}?", e(m, b), traps, {"notes": [sent]}, extra)


# ==========================================
# 6. BATTLE 4 - Graphing Linear Relations
#    W9L2 worksheet + DeltaMath: Make Table, Plot, Graph - Linear L2,
#    Vertical and Horizontal Lines
# ==========================================
def b4_table_value():                                # M  (Make Table, Plot, Graph L2: y = mx + b, x = -3..3)
    m = random.choice([-5, -4, -3, -2, 2, 3, 4, 5])
    b = nz(-8, 8)
    xs = random.choice([[-3, -2, -1, 0, 1, 2, 3], [-4, -3, -2, -1, 0, 1, 2]])
    i = random.choice([k for k, x in enumerate(xs) if x != 0])
    x = xs[i]
    shown = [("?" if k == i else "") for k in range(len(xs))]
    visual = {"table": {"rows": [("x", xs), (eq(m, b), shown)]}}
    return build_num("Complete the table. What goes in the ? box?", m * x + b, _eval_traps(m, b, x),
                     ok=any_int, visual=visual)


def _rand_line(rng=4):
    while True:
        m, b = random.choice([-3, -2, -1, 1, 2, 3]), random.randint(-rng, rng)
        if b != m:
            return m, b


def b4_which_line():                                 # H  (graph several lines; which one is y = mx + b?)
    m, b = _rand_line()
    cands = [(-m, b), (m, -b), (b, m) if b else (m, b + 2), (-m, -b), (m + (1 if m > 0 else -1), b)]
    others = []
    for c in cands:
        if c != (m, b) and c not in others and c[0] != 0:
            others.append(c)
    if len(others) < 4:
        return None
    none_right = random.random() < 0.2               # sometimes the line isn't drawn at all
    shown = random.sample(others, 4) if none_right else random.sample(others, 3) + [(m, b)]
    random.shuffle(shown)
    names = ["A", "B", "C", "D"]
    lines = [(mm, bb, nm) for (mm, bb), nm in zip(shown, names)]
    opts = [f"Line {nm}" for nm in names] + ["None of them"]
    ans = "None of them" if none_right else f"Line {names[shown.index((m, b))]}"
    return build(f"Which line is {eq(m, b)}?", ans, [o for o in opts if o != ans],
                 {"grid": {"r": 8, "lines": lines}})


def b4_match_graph():                                # M  (Vertical and Horizontal Lines: write the equation)
    r = random.random()
    if r < 0.1:
        c = nz(-8, 8)
        line, ans = ("h", c), eq(0, c)
        traps = [vert(c), eq(c, 0), eq(0, -c), vert(-c)]
    elif r < 0.2:
        c = nz(-8, 8)
        line, ans = ("v", c), vert(c)
        traps = [eq(0, c), vert(-c), eq(c, 0), eq(0, -c)]
    else:                                            # halves too: W9L3 "step right 2, up 1"
        m = F(random.choice([-5, -4, -3, -2, -1, 1, 2, 3, 4, 5, 1, -1, 2, -2] +
                            [F(1, 2), F(-1, 2), F(3, 2), F(-3, 2), F(5, 2), F(-5, 2)]))
        b = F(random.randint(-8, 8))
        if b == m:
            return None
        line, ans = (m, b), eq(m, b)
        traps = [eq(-m, b), eq(m, -b), eq(b, m), eq(-m, -b)] + grid(eq, [m, -m, b, m + 1], [b, -b, m], (m, b))
    return build("Which equation matches the line?", ans, traps, {"grid": {"r": 8, "lines": [line]}})


def b4_hv_type():                                    # M  (Vertical and Horizontal Lines: type of line)
    r = random.random()
    if r < 0.4:                                      # through two points with the same x (or same y)
        c = random.choice([0] + [k for k in range(-12, 13) if k])     # c = 0: the line is an axis
        d1, d2 = random.sample([k for k in range(-9, 10) if k != c], 2)
        if random.random() < 0.5:
            return build(f"Which line goes through {pt(c, d1)} and {pt(c, d2)}?", vert(c),
                         [eq(0, c), eq(0, d1), vert(d1), eq(0, d2), vert(d2)])
        return build(f"Which line goes through {pt(d1, c)} and {pt(d2, c)}?", eq(0, c),
                     [vert(c), vert(d1), eq(0, d1), vert(d2), eq(0, d2)])
    c = nz(-15, 15)
    if r < 0.6:                                      # which point is on x = c (or y = c)?
        a, d = random.sample([k for k in range(-9, 10) if abs(k) != abs(c) and k], 2)
        if random.random() < 0.5:
            return build(f"Which point is on the line x = {c}?", pt(c, a),
                         [pt(a, c), pt(d, c), pt(0, c), pt(a, 0), pt(-c, a), pt(a, d)])
        return build(f"Which point is on the line y = {c}?", pt(a, c),
                     [pt(c, a), pt(c, d), pt(c, 0), pt(0, a), pt(a, -c), pt(d, a)])
    if r < 0.8:
        return build(f"Describe the line x = {c}.", f"Vertical, through ({c}, 0)",
                     [f"Horizontal, through (0, {c})", f"Vertical, through (0, {c})",
                      f"Horizontal, through ({c}, 0)", f"Slanted, through ({c}, {c})"])
    return build(f"Describe the line y = {c}.", f"Horizontal, through (0, {c})",
                 [f"Vertical, through ({c}, 0)", f"Horizontal, through ({c}, 0)",
                  f"Vertical, through (0, {c})", f"Slanted, through ({c}, {c})"])


def b4_hv_through():                                 # M  (worksheet: horizontal line through (5, -7))
    a, c = nz(-9, 9), nz(-9, 9)
    while abs(c) == abs(a):
        c = nz(-9, 9)
    if random.random() < 0.5:
        return build(f"Write the equation of the horizontal line through {pt(a, c)}.", eq(0, c),
                     [vert(a), eq(0, a), vert(c), eq(a, c), eq(0, -c)])
    return build(f"Write the equation of the vertical line through {pt(a, c)}.", vert(a),
                 [eq(0, a), eq(0, c), vert(c), eq(c, a), vert(-a)])


def b4_describe():                                   # M  (worksheet: up or down? where does it cross?)
    while True:
        m, b = nz(-9, 9), nz(-12, 12)
        if b != m and abs(b) != abs(m):
            break
    d, f = ("Up", "Down") if m > 0 else ("Down", "Up")
    o = lambda w, p: f"{w}, crosses at {p}"
    traps = [o(f, pt(0, b)), o(d, pt(0, m)), o(f, pt(0, m)), o(random.choice([d, f]), pt(b, 0))]
    return build(f"Describe the line {eq(m, b)} (left to right).", o(d, pt(0, b)), traps)


def b4_cross():                                      # M  (W9L2: the horizontal and vertical line through a point)
    a, c = nz(-8, 8), nz(-8, 8)
    while abs(a) == abs(c):
        c = nz(-8, 8)
    first, second = (eq(0, c), vert(a)) if random.random() < 0.5 else (vert(a), eq(0, c))
    return build(f"Where do the lines {first} and {second} cross?", pt(a, c),
                 [pt(c, a), pt(-a, c), pt(a, -c), pt(0, c), pt(a, 0)],
                 extra=grid(pt, [a, -a, c, 0], [c, -c, a, 0], (a, c)))


def b4_cross_slanted():                              # NOT TAUGHT YET (where do two slanted lines cross?)
    while True:
        x0, y0 = random.randint(-3, 3), random.randint(-4, 4)
        m1, m2 = random.sample([-3, -2, -1, 1, 2, 3], 2)
        b1, b2 = y0 - m1 * x0, y0 - m2 * x0
        if abs(b1) <= 6 and abs(b2) <= 6 and abs(x0) != abs(y0):
            break
    traps = [pt(y0, x0), pt(-x0, y0), pt(x0, -y0), pt(0, b1), pt(0, b2)]
    return build(f"Where do {eq(m1, b1)} and {eq(m2, b2)} cross?", pt(x0, y0), traps,
                 extra=grid(pt, [x0, -x0, y0, 0], [y0, -y0, x0, b1, b2], (x0, y0)))


def _point_on_line(m, b, text):
    x0 = nz(-4, 4)
    y0 = m * x0 + b
    on = lambda x, y: y == m * x + b
    cands = [(x0, -m * x0 + b), (x0, m * x0 - b), (y0, x0), (-x0, y0), (x0, y0 + 1), (x0, y0 - 1),
             (x0 + 1, y0), (b, 0)]
    for x in (x0 - 2, x0 - 1, x0 + 1, x0 + 2):               # sign slips at other x-values
        cands += [(x, -m * x + b), (x, m * x - b), (m * x + b, x)]
    traps = [pt(x, y) for x, y in cands if not on(x, y)]
    return build(text, pt(x0, y0), traps[:4], extra=traps[4:])


def b4_point_on_line():                              # M  (worksheet: Line-Up)
    m, b = nz(-4, 4), random.randint(-6, 6)
    return _point_on_line(m, b, f"Which point is on the line {eq(m, b)}?")


def b4_line_or_not():                                # M  (W9L2 Think 1: line or not?  W9L3 card 4)
    """Is the table linear?  Check the RATE (y-jump / x-jump) between columns, not just the
    y-jumps: when x skips unevenly, the y-jumps change but the rate can stay the same."""
    n = random.choice([4, 4, 5])
    for _ in range(300):
        if random.random() < 0.55:                   # uneven x-gaps (W9L3 card 4)
            gaps = [random.randint(1, 3) for _ in range(n - 1)]
            if len(set(gaps)) == 1:
                continue
        else:
            gaps = [random.choice([1, 1, 2])] * (n - 1)
        xs = [random.randint(-3, 2)]
        for d in gaps:
            xs.append(xs[-1] + d)
        m, b = nz(-5, 5), random.randint(-8, 10)
        ys = [m * x + b for x in xs]
        linear = random.random() < 0.5
        if not linear:
            if random.random() < 0.4:                # a curve, like Mia's table 0, 1, 4, 9
                c = random.randint(-6, 6)
                ys = [x * x + c for x in xs]
            else:                                    # one value is off the line
                k = random.randint(1, n - 1)
                ys[k] += random.choice([-3, -2, -1, 1, 2, 3])
        jumps = [ys[i + 1] - ys[i] for i in range(n - 1)]
        rates = [F(jumps[i], gaps[i]) for i in range(n - 1)]
        if any(abs(y) > 40 for y in ys) or not all(nice(r, 2) for r in rates):
            continue
        if linear != (len(set(rates)) == 1):
            continue
        break
    else:
        return None
    lst = lambda vals: ", ".join(fnum(v) for v in vals)
    yes = lambda r: f"Yes, the rate is {fnum(r)} each time"
    yes_j = lambda j: f"Yes, y goes up {fnum(j)} each time" if j > 0 else f"Yes, y goes down {fnum(-j)} each time"
    no_r = lambda rs: f"No, the rates are {lst(rs)}"
    no_j = lambda js: f"No, the y-jumps are {lst(js)}"
    tweak = rates[:]
    tweak[-1] += random.choice([1, -1])
    if linear:
        right = yes(rates[0])
        traps = [no_j(jumps) if len(set(jumps)) > 1 else None,
                 yes_j(jumps[0]) if gaps[0] != 1 else None,
                 yes(-rates[0]), no_r(tweak), yes(rates[0] + 1), yes(rates[0] - 1)]
    else:
        right = no_r(rates)
        traps = [yes(rates[0]), yes(rates[-1]), no_j(jumps) if jumps != rates else None,
                 yes_j(jumps[0]) if gaps[0] != 1 else None, no_r(tweak), yes(-rates[0])]
    return build("Is the table linear (one straight line)?", right, traps, _tbl(xs, ys))


# ==========================================
# 7. BATTLE 5 - Reading Graphs & Making Predictions
#    W9L3-L4 worksheets + DeltaMath: Interpret Linear Graph in Context (MC),
#    predict from the line (given x find y / given y find x), interpolate or extrapolate
# ==========================================
def _nice_step(top):
    return next(s for s in (1, 2, 5, 10, 20, 25, 50, 100, 200) if top / s <= 10)


def make_graph(title, xl, yl, m, b, xmax, xstep=1, n_labels=2, label_fmt=None):
    """Context graph dict + the labelled points.  Decreasing lines stop at y = 0."""
    T = F(b, -m) if m < 0 else None
    top = b if m < 0 else b + m * xmax
    ystep = _nice_step(top)
    ymax = int(-(-top // ystep) * ystep)
    label_fmt = label_fmt or (lambda x, y: pt(x, y))
    x_last = xmax if T is None else min(xmax, int(T) - 1)
    xs_ok = [x for x in range(xstep, x_last + 1, xstep) if nice(m * x + b, 4)]
    if len(xs_ok) < n_labels:
        return None, None
    lab = sorted(random.sample(xs_ok, n_labels))
    pts = [(x, m * x + b) for x in lab]
    g = {"title": title, "xlabel": xl, "ylabel": yl, "xmax": xmax, "xstep": xstep, "ymax": ymax,
         "ystep": ystep, "line": (m, b), "labels": [(x, y, label_fmt(x, y)) for x, y in pts]}
    return g, pts


# For DeltaMath's "interpret the x-value for a given y-value" and "where the line meets the x-axis":
#   title: (meaning of x when y = V,  the swapped (wrong) reading,  meaning of the x-axis point or None)
MEANING_X = {
    "Gym Membership": (lambda V: f"The months until the total cost is {money(V)}",
                       lambda V: f"The total cost after {fnum(V)} months", None),
    "Savings Account": (lambda V: f"The weeks until {money(V)} is saved",
                        lambda V: f"The savings after {fnum(V)} weeks", None),
    "Taxi Ride": (lambda V: f"How far you can ride for {money(V)}",
                  lambda V: f"The cost of a {fnum(V)} km ride", None),
    "Plant Growth": (lambda V: f"The weeks until the plant is {fnum(V)} cm tall",
                     lambda V: f"The plant's height after {fnum(V)} weeks", None),
    "Car Gas Tank": (lambda V: f"The hours until {fnum(V)} L of gas is left",
                     lambda V: f"The gas left after {fnum(V)} hours", "How long until the tank is empty"),
    "The Elevator": (lambda V: f"The seconds until it is {fnum(V)} m high",
                     lambda V: f"Its height after {fnum(V)} seconds", "When the elevator reaches the ground"),
    "Phone Battery": (lambda V: f"The hours until the battery is at {fnum(V)}%",
                      lambda V: f"The battery level after {fnum(V)} hours", "When the battery runs out"),
}


def graph_situation():
    """A context graph with meanings for the rate, start and points (DeltaMath MC style)."""
    t = random.choice(["gym", "save", "taxi", "plant", "gas", "elevator", "battery"])
    xstep = 1
    if t == "gym":
        b, m, xmax = random.choice([50, 60, 75, 80, 100, 120]), random.choice([20, 25, 30, 40, 50]), random.choice([8, 10, 12])
        c = dict(title="Gym Membership", xl="Months", yl="Total cost ($)", xu="months", noun="total cost",
                 fmt=as_money, rate=lambda v: f"{money(v)} per month",
                 mean=lambda x, y: f"{fnum(x)} months cost {money(y)} in total",
                 m_rate="The cost for each month", m_recip="How many months $1 buys",
                 m_start="The sign-up fee (at 0 months)", m_at1="The total cost for 1 month",
                 inv=lambda V: f"After how many months is the total cost {money(V)}?")
    elif t == "save":
        b, m, xmax = random.choice([20, 30, 40, 50, 60, 80]), random.choice([5, 10, 15, 20, 25]), random.choice([8, 10, 12])
        c = dict(title="Savings Account", xl="Weeks", yl="Savings ($)", xu="weeks", noun="savings",
                 fmt=as_money, rate=lambda v: f"{money(v)} per week",
                 mean=lambda x, y: f"After {fnum(x)} weeks, {money(y)} is saved",
                 m_rate="The amount saved each week", m_recip="The weeks it takes to save $1",
                 m_start="The amount in the account at the start", m_at1="The savings after 1 week",
                 inv=lambda V: f"After how many weeks are the savings {money(V)}?")
    elif t == "taxi":
        b, m, xmax = random.choice([F(5, 2), 3, F(7, 2), 4, 5]), random.choice([F(3, 2), 2, F(5, 2), 3]), 10
        c = dict(title="Taxi Ride", xl="Distance (km)", yl="Cost ($)", xu="km", noun="cost",
                 fmt=as_money, rate=lambda v: f"{money(v)} per km",
                 mean=lambda x, y: f"A {fnum(x)} km ride costs {money(y)}",
                 m_rate="How much the taxi costs per km", m_recip="How far you can ride for $1",
                 m_start="The flat fee to order the taxi", m_at1="The total cost of a 1 km ride",
                 inv=lambda V: f"How far can you ride for {money(V)}?")
    elif t == "plant":
        b, m, xmax = random.choice([2, 4, 5, 6, 8, 10]), random.randint(2, 5), random.choice([8, 10])
        c = dict(title="Plant Growth", xl="Weeks", yl="Height (cm)", xu="weeks", noun="height",
                 fmt=as_units("cm"), rate=lambda v: f"{fnum(v)} cm per week",
                 mean=lambda x, y: f"At {fnum(x)} weeks, it is {fnum(y)} cm tall",
                 m_rate="How much the plant grows each week", m_recip="The weeks it takes to grow 1 cm",
                 m_start="The plant's height when planted", m_at1="The plant's height after 1 week",
                 inv=lambda V: f"After how many weeks is the plant {fnum(V)} cm tall?")
    elif t == "gas":
        r, T = random.choice([5, 6, 8, 10]), random.choice([5, 6, 8, 10])
        b, m, xmax = r * T, -r, T
        c = dict(title="Car Gas Tank", xl="Time driving (h)", yl="Gas in tank (L)", xu="hours", noun="gas",
                 fmt=as_units("L"), rate=lambda v: f"{fnum(v)} L per hour",
                 mean=lambda x, y: f"After {fnum(x)} h, {fnum(y)} L of gas is left",
                 m_rate="The litres of gas used each hour", m_recip="The hours it takes to use 1 L",
                 m_start="The gas in the tank at the start", m_at1="The gas left after 1 hour",
                 inv=lambda V: f"After how many hours is {fnum(V)} L of gas left?")
    elif t == "elevator":
        b, r = random.choice([60, 80, 100, 120]), random.choice([2, 4, 5, 10])
        m, xmax = -r, min(10, b // r)
        c = dict(title="The Elevator", xl="Time (s)", yl="Height (m)", xu="seconds", noun="height",
                 fmt=as_units("m"), rate=lambda v: f"{fnum(v)} m per second",
                 mean=lambda x, y: f"After {fnum(x)} s, it is {fnum(y)} m high",
                 m_rate="How far it goes down each second", m_recip="The seconds it takes to drop 1 m",
                 m_start="Its height at the start", m_at1="Its height after 1 second",
                 inv=lambda V: f"After how many seconds is it {fnum(V)} m high?")
    else:
        b, m = 100, -random.choice([10, 20, 25])
        xmax = min(10, 100 // -m)
        c = dict(title="Phone Battery", xl="Time (h)", yl="Battery (%)", xu="hours", noun="battery",
                 fmt=as_pct, rate=lambda v: f"{fnum(v)}% per hour",
                 mean=lambda x, y: f"After {fnum(x)} h, the battery is at {fnum(y)}%",
                 m_rate="The percent of battery used each hour", m_recip="The hours it takes to use 1%",
                 m_start="The battery level at the start", m_at1="The battery level after 1 hour",
                 inv=lambda V: f"After how many hours is the battery at {fnum(V)}%?")
    m, b = F(m), F(b)
    c.update(zip(("xfor", "yfor", "m_xint"), MEANING_X[c["title"]]))
    lf = (lambda x, y: f"({fnum(x)}, {money(y)})") if c["fmt"] is as_money else pt
    g, pts = make_graph(c["title"], c["xl"], c["yl"], m, b, xmax, xstep, label_fmt=lf)
    if g is None:
        return graph_situation()
    c.update(m=m, b=b, graph=g, pts=pts, T=(F(b, -m) if m < 0 else None), xstep=xstep, lf=lf)
    return c


def b5_meaning():                                    # M  (Interpret Linear Graph in Context)
    c = graph_situation()
    vis = {"graph": c["graph"]}
    kinds = ["rate", "rate", "start", "start", "point", "point", "at1", "xfory"]
    if c["m_xint"] and c["m"] < 0:
        kinds.append("xint")
    kind = random.choice(kinds)
    swap_start = f"The {c['noun']} after {c['graph']['xmax']} {c['xu']}"
    if kind == "rate":
        return build("What does the rate (slope) of the line mean?", c["m_rate"],
                     [c["m_recip"], c["m_start"], c["m_at1"], swap_start], vis)
    if kind == "start":
        return build("What does the start value (y-intercept) mean?", c["m_start"],
                     [c["m_at1"], c["m_rate"], c["m_recip"], swap_start], vis)
    if kind == "at1":
        return build("What does the y-value at x = 1 mean?", c["m_at1"],
                     [c["m_start"], c["m_rate"], c["m_recip"], swap_start], vis)
    if kind == "xint":
        return build("The line reaches 0 at the bottom (y = 0). What does that point mean?", c["m_xint"],
                     [c["m_start"], c["m_rate"], c["m_at1"], c["m_recip"]], vis)
    if kind == "xfory":
        V = random.choice(c["pts"])[1]
        return build(f"What does the x-value mean when y = {fnum(V)}?", c["xfor"](V),
                     [c["yfor"](V), c["m_rate"], c["m_start"], c["m_at1"]], vis)
    (x1, y1), (x2, y2) = c["pts"]
    x, y = (x2, y2) if random.random() < 0.5 else (x1, y1)
    traps = [c["mean"](y, x), c["mean"](x + c["xstep"], y), c["mean"](x, c["b"]), f"It changes by {c['rate'](y)}"]
    label = [l[2] for l in c["graph"]["labels"] if l[0] == x][0]
    return build(f"What does the point {label} on the line mean?", c["mean"](x, y), traps, vis)


def b5_rate():                                       # M  (rate with units, check the scales)
    c = graph_situation()
    m = c["m"]
    (x1, y1), (x2, y2) = c["pts"]
    rate_all = lambda vals: [c["rate"](v) for v in vals]
    traps = [-m, y2 - y1 if x2 - x1 > 1 else None, F(x2 - x1, y2 - y1), F(y1, x1) if F(y1, x1) != m else None, 2 * m]
    return build_num("Find the rate of change, with units.", m, traps, fmt=rate_all,
                     ok=lambda v: nice(v) and v != 0, visual={"graph": c["graph"]},
                     extra=[m + d for d in (5, -5, 10, -10, 1, -1, F(1, 2), -F(1, 2))])


def _predict_x(c, extrapolate):
    xmax, T, st = c["graph"]["xmax"], c["T"], c["xstep"]
    label_x = {p[0] for p in c["pts"]}
    hi = (int(T) - 1) if T is not None else xmax + 10 * st
    if extrapolate:
        choices = list(range(xmax + st, hi + 1, st))
    else:
        choices = [x for x in range(st, min(xmax, hi + 1), st) if x not in label_x]
    choices = [x for x in choices if nice(c["m"] * x + c["b"], 4)]
    return random.choice(choices) if choices else None


def b5_predict():                                    # M  (predict from the line: given x find y)
    c = graph_situation()
    m, b = c["m"], c["b"]
    xp = _predict_x(c, random.random() < 0.6)
    if xp is None:
        return None
    ans = m * xp + b
    traps = [m * xp, b + m * (xp - 1), b - m * xp, ans + m, ans - m, ans + c["graph"]["ystep"]]
    return build_num(f"Use the line to predict the {c['noun']} at {fnum(xp)} {c['xu']}.", ans, traps,
                     fmt=c["fmt"], ok=lambda v: v >= 0 and nice(v, 4), visual={"graph": c["graph"]})


def b5_predict_x():                                  # H  (predict from the line: given y find x)
    c = graph_situation()
    m, b = c["m"], c["b"]
    xp = _predict_x(c, random.random() < 0.6)
    if xp is None:
        return None
    V = m * xp + b
    traps = [F(V, m), F(V + b, m), F(V - b, -m), xp + c["xstep"], xp - c["xstep"], V - b]
    return build_num(c["inv"](V), xp, traps, fmt=as_units(c["xu"]), ok=lambda v: v > 0 and nice(v, 2),
                     visual={"graph": c["graph"]})


def b5_inter_extra():                                # M  (W9L4 sunflower: interpolate or extrapolate?)
    """Three data dots, evenly spaced (like weeks 2, 6, 10).  Between the first and last dot is
    interpolate; before the first dot (even x = 0) or after the last dot is extrapolate."""
    c = graph_situation()
    m, b, T = c["m"], c["b"], c["T"]
    g = dict(c["graph"])
    xmax = g["xmax"]
    good = lambda x: x >= 0 and (T is None or x < T) and nice(m * x + b, 4)
    for _ in range(40):
        gap = random.choice([2, 2, 3, 4])
        first = random.choice([1, 2, 3])
        dots = [first, first + gap, first + 2 * gap]
        if dots[-1] <= xmax and all(good(x) for x in dots):
            break
    else:
        return None
    g["labels"] = [(x, m * x + b, c["lf"](x, m * x + b)) for x in dots]
    ext = random.random() < 0.5
    if ext:
        choices = list(range(0, dots[0])) + list(range(dots[-1] + 1, xmax + 7))
    else:
        choices = [x for x in range(dots[0] + 1, dots[-1]) if x not in dots]
    choices = [x for x in choices if good(x)]
    if not choices:
        return None
    xp = random.choice(choices)
    v = m * xp + b
    vals = [v, m * xp, v + m]
    if len(set(vals)) < 3 or min(vals) < 0:
        return None
    vals += [v - m, b + m * (xp - 1)]
    vals = [x for i, x in enumerate(vals) if x >= 0 and x not in vals[:i]]
    s = dict(zip(vals, c["fmt"](vals)))
    right, wrong = ("extrapolate", "interpolate") if ext else ("interpolate", "extrapolate")
    return two_way(f"The dots are the data. {c['noun'].capitalize()} at {fnum(xp)} {c['xu']}? "
                   f"Interpolate or extrapolate?",
                   lambda a, w: f"{s[a]}, {w}", v, right, vals[1:], wrong, {"graph": g})


def b5_zero():                                       # M  (worksheet: when does it reach 0?)
    for _ in range(30):
        c = graph_situation()
        if c["T"] is not None and c["T"].denominator == 1:
            break
    else:
        return None
    T, m, b = c["T"], c["m"], c["b"]
    traps = [T + 1, T - 1, T + 2, -m, F(b, 10) if b % 10 == 0 else None]
    return build_num(f"When does the {c['noun']} reach 0?", T, traps, fmt=as_units(c["xu"]),
                     ok=at_least(2), visual={"graph": c["graph"]})


def b5_two_points():                                 # E  (W9L4 warm-up: rate from two points)
    m = random.choice([n for n in range(-30, 31, 5) if n] + [nz(-9, 9)])
    x1 = random.randint(0, 6)
    x2 = x1 + random.randint(2, 6)
    y1 = random.choice(range(10, 160, 5)) if m > 0 else random.choice(range(100, 300, 10))
    y2 = y1 + m * (x2 - x1)
    traps = [y2 - y1, x2 - x1, -m, F(x2 - x1, y2 - y1), F(y2, x2)]
    return build_num(f"Find the rate of change from {pt(x1, y1)} to {pt(x2, y2)}.", m, traps,
                     ok=lambda v: nice(v))


# ==========================================
# 8. BATTLE 6 - Comparing Linear Relations
#    W9L3-L4 worksheets + DeltaMath: Compare Rates in Context (health club, taxi, earnings),
#    Compare Rates (Linear Representations), comparing slopes and steepness
# ==========================================
def two_relations():
    """Two situations that are equal at a whole-number time t0 (DeltaMath Comparing Two Linear Functions)."""
    t = random.choice(["garage", "plan", "school", "tree", "read", "car", "candle"])
    dec = t in ("car", "candle")
    for _ in range(500):
        t0 = random.randint(3, 10)
        if t == "garage":
            rA, rB = random.sample([2, 3, 4, 5, 6, 8], 2)
        elif t == "plan":
            rA, rB = random.sample([10, 15, 20, 25, 30, 40], 2)
        elif t == "school":
            rA, rB = random.sample([20, 25, 30, 40, 50, 55, 60], 2)
        elif t == "tree":
            rA, rB = random.sample([3, 4, 5, 6, 8, 10], 2)
        elif t == "read":
            rA, rB = random.sample([15, 20, 25, 30, 35, 40], 2)
        elif t == "car":
            rA, rB = random.sample([50, 60, 70, 80, 90, 100], 2)
        else:
            rA, rB = random.sample([1, 2, 3, 4, 5], 2)
        bA = random.choice({"garage": [2, 4, 5, 6, 8, 10], "plan": [10, 20, 25, 30, 40, 50],
                            "school": [600, 700, 750, 800, 850, 900], "tree": [20, 30, 40, 50, 60],
                            "read": [10, 20, 40, 50, 60, 80], "car": [200, 250, 300, 350, 400],
                            "candle": [10, 12, 15, 18, 20]}[t])
        mA, mB = (-rA, -rB) if dec else (rA, rB)
        bB = bA + (mA - mB) * t0
        if bB <= 0 or (t in ("garage", "plan") and bB > 120) or (dec and mA * t0 + bA <= 0):
            continue
        if t == "candle" and bB > 60:
            continue
        break
    else:
        return two_relations()
    nA, nB = ("A", "B")
    if t == "garage":
        s = lambda n, b, r: f"Garage {n} charges ${b} plus ${r} per hour."
        c = dict(xu="hours", q="cost", fmt=as_money, big="more expensive", small="cheaper", pre="Garage ")
    elif t == "plan":
        s = lambda n, b, r: f"Plan {n}: ${b} sign-up fee plus ${r} per month."
        c = dict(xu="months", q="total cost", fmt=as_money, big="more expensive", small="cheaper", pre="Plan ")
    elif t == "school":
        s = lambda n, b, r: f"School {n} has {b} students and grows by {r} each year."
        c = dict(xu="years", q="number of students", fmt=as_units("students"), big="bigger", small="smaller",
                 pre="School ")
    elif t == "tree":
        s = lambda n, b, r: f"Tree {n} is {b} cm tall and grows {r} cm per year."
        c = dict(xu="years", q="height", fmt=as_units("cm"), big="taller", small="shorter", pre="Tree ")
    elif t == "read":
        s = lambda n, b, r: f"Reader {n} is on page {b} and reads {r} pages per day."
        c = dict(xu="days", q="page number", fmt=as_units("pages"), big="farther along", small="behind",
                 pre="Reader ")
    elif t == "car":
        s = lambda n, b, r: f"Car {n} is {b} km from the stadium, driving toward it at {r} km/h."
        c = dict(xu="hours", q="distance from the stadium", fmt=as_units("km"), big="farther away",
                 small="closer", pre="Car ")
    else:
        s = lambda n, b, r: f"Candle {n} is {b} cm tall and burns {r} cm per hour."
        c = dict(xu="hours", q="height", fmt=as_units("cm"), big="taller", small="shorter", pre="Candle ")
    c.update(t=t, t0=t0, A=(F(mA), F(bA)), B=(F(mB), F(bB)),
             notes=[s(nA, bA, abs(mA)), s(nB, bB, abs(mB))])
    return c


def _val(rel, x):
    return rel[0] * x + rel[1]


def b6_equal_time():                                 # NOT TAUGHT YET (when are they the same?)
    c = two_relations()
    (mA, bA), (mB, bB), t0 = c["A"], c["B"], c["t0"]
    jo = F(bA + bB, abs(mA - mB))
    traps = [jo, abs(bA - bB), F(abs(bA - bB), abs(mA) + abs(mB)), t0 + 1, t0 - 1, t0 + 2]
    small = lambda v: pos_int(v) and 2 <= v <= max(14, 2 * t0)
    return build_num(f"When is the {c['q']} the same for both?", t0, traps, fmt=as_units(c["xu"]),
                     ok=small, visual={"notes": c["notes"]})


def b6_equal_value():                                # NOT TAUGHT YET (the value when they match)
    c = two_relations()
    (mA, bA), (mB, bB), t0 = c["A"], c["B"], c["t0"]
    y0 = _val(c["A"], t0)
    traps = [bA + bB, _val(c["A"], t0 + 1), _val(c["B"], t0 - 1), abs(bA - bB), mA * t0 + bB]
    return build_num(f"What is the {c['q']} when they match?", y0, traps, fmt=c["fmt"],
                     ok=lambda v: v > 0 and nice(v, 4), visual={"notes": c["notes"]})


def b6_interval():                                   # NOT TAUGHT YET (when is A cheaper?  t > t0)
    c = two_relations()
    (mA, bA), (mB, bB), t0 = c["A"], c["B"], c["t0"]
    who = random.choice(["A", "B"])
    want_big = random.random() < 0.5
    me, other = (c["A"], c["B"]) if who == "A" else (c["B"], c["A"])
    later = _val(me, t0 + 1) > _val(other, t0 + 1)       # is "me" bigger after t0?
    after = later == want_big
    word = c["big"] if want_big else c["small"]
    right, wrong = (f"t > {t0}", f"t < {t0}") if after else (f"t < {t0}", f"t > {t0}")
    jo = F(bA + bB, abs(mA - mB))
    alts = [int(jo)] if jo.denominator == 1 and jo != t0 and jo <= max(14, 2 * t0) else []
    alts += [x for x in (t0 - 2, t0 + 2, t0 - 1, t0 + 3) if x > 0]
    random.shuffle(alts)
    sym = right.split()[1]
    other = "<" if sym == ">" else ">"
    return two_way(f"When is {c['pre']}{who} {word}?  (t = {c['xu']})", lambda a, w: f"t {w} {a}",
                   t0, sym, alts, other, {"notes": c["notes"]})


def b6_at_time():                                    # M  (W9L4 Ava & Ben: compare at a given x)
    c = two_relations()
    t0 = c["t0"]
    k = random.choice([x for x in range(1, 13) if x != t0])
    a, b = _val(c["A"], k), _val(c["B"], k)
    if a <= 0 or b <= 0:
        return None
    big = "A" if a > b else "B"
    d = abs(a - b)
    f = lambda v: c["fmt"]([v])[0]
    o = lambda n, v: f"{c['pre']}{n}, by {f(v)}"
    other = "B" if big == "A" else "A"
    wrong_d = abs(c["A"][1] - c["B"][1])
    dm = abs(c["A"][0] - c["B"][0])
    alts = [wrong_d, dm * k, dm, d + dm] + ([d - dm] if d > dm else [])
    return two_way(f"After {k} {c['xu']}, which is {c['big']}? By how much?",
                   lambda a, w: o(w, a), d, big, alts, other, {"notes": c["notes"]})


def b6_write_eq():                                   # E  (write the equation for one situation)
    c = two_relations()
    who = random.choice(["A", "B"])
    m, b = c[who]
    e = lambda mm, bb: eq(mm, bb, "t", who)
    traps = [e(b, m), e(-m, b), e(m, 0)]
    return build(f"Which equation shows {c['pre']}{who}?  (t = {c['xu']})", e(m, b), traps,
                 {"notes": c["notes"]}, extra=grid(e, [m, -m, b], [b, -b, 0, m], (m, b)))


RATE_CTX = [
    # (kind, unit word, x header, y header, rate choices, start choices, who-words)
    ("club",   "month", "months", "cost ($)", [35, 39, 42, 45, 48, 51, 55, 59], [0, 20, 25, 30, 50, 75],
     ["Club A", "Club B", "Club C"], "costs", "less", "more"),
    ("taxi",   "km",    "km",     "cost ($)", [F(5, 4), F(3, 2), F(7, 4), 2, F(9, 4), F(5, 2), 3], [3, F(7, 2), 4, F(9, 2), 5],
     ["Taxi A", "Taxi B", "Taxi C"], "costs", "less", "more"),
    ("earn",   "hour",  "hours",  "pay ($)",  [14, F(29, 2), 15, 16, F(33, 2), 17, 18, 20], [0],
     ["Aria", "Leo", "Haya"], "earns", "less", "more"),
    ("save",   "week",  "weeks",  "savings ($)", [5, F(15, 2), 10, F(25, 2), 15, F(35, 2), 20], [0, 10, 20, 30, 40],
     ["Vani", "Tia", "Jon"], "saves", "less", "more"),
]


def _rate_rep(kind, who, unit, xh, yh, m, b, rep):
    """One relation shown as words, an equation, a table or a graph (like DeltaMath)."""
    if rep == "graph":
        g, pts = make_graph(f"{who}", xh.capitalize(), yh.capitalize(), m, b, random.choice([8, 10]),
                            label_fmt=lambda x, y: f"({fnum(x)}, {money(y)})", n_labels=1)
        if g is None:
            return _rate_rep(kind, who, unit, xh, yh, m, b, "table")
        g["labels"].insert(0, (0, b, f"(0, {money(b)})"))
        return {"notes": [f"{who}: see the graph."], "graph": g}
    if rep == "eq":
        return {"notes": [f"{who}:  y = {expr(m, b, 'x')}   (x = {xh})"]}
    if rep == "words":
        if kind == "earn":
            return {"notes": [f"{who} earns {money(m)} per hour."]}
        if kind == "save":
            return {"notes": [f"{who} starts with ${fnum(b)} and saves {money(m)} each week."]}
        start = f"${fnum(b)}" if b.denominator == 1 else money(b)
        return {"notes": [f"{who} charges {start} to start plus {money(m)} per {unit}."]}
    step = random.choice([2, 4, 5])
    x0 = random.choice([1, 2, 3, 4])
    xs = [x0 + step * k for k in range(3)]
    ys = [m * x + b for x in xs]
    cents = any(F(y).denominator != 1 for y in ys)
    return {"notes": [f"{who}:"], "table": {"rows": [(xh, xs), (yh, [money(y, cents)[1:] for y in ys])]}}


def b6_compare_rate():                               # M  (Compare Rates in Context)
    kind, unit, xh, yh, rates, starts, names, verb, less, more = random.choice(RATE_CTX)
    mA, mB = random.sample(rates, 2)
    mA, mB = F(mA), F(mB)
    bA, bB = F(random.choice(starts)), F(random.choice(starts))
    while True:
        repA, repB = random.sample(["eq", "words", "table", "graph", "graph"], 2)
        if {repA, repB} != {"table", "graph"} and repA != repB:
            break
    vA = _rate_rep(kind, names[0], unit, xh, yh, mA, bA, repA)
    vB = _rate_rep(kind, names[1], unit, xh, yh, mB, bB, repB)
    plain = [n for v in (vA, vB) if "table" not in v for n in v["notes"]]
    tab = [v for v in (vA, vB) if "table" in v]
    visual = {"notes": plain + (tab[0]["notes"] if tab else [])}
    if tab:
        visual["table"] = tab[0]["table"]
    for v in (vA, vB):
        if "graph" in v:
            visual["graph"] = v["graph"]
    d = abs(mA - mB)
    word = less if mA < mB else more
    other_word = more if word == less else less
    o = lambda w, v: f"{money(v)} {w} per {unit}"
    alts = ([abs(bA - bB)] if bA != bB else []) + [mA + mB, d * 2] + \
           [v for v in (d - F(1, 2), d / 2, d + 1) if v > 0 and nice(v, 4)]
    random.shuffle(alts)
    return two_way(f"Compare {names[0]}'s rate per {unit} to {names[1]}'s.", lambda a, w: o(w, a),
                   d, word, alts, other_word, visual)


def b6_sort_rates():                                 # H  (Compare Rates: sort three representations)
    kind, unit, xh, yh, rates, starts, names, verb, less, more = random.choice(RATE_CTX)
    ms = [F(v) for v in random.sample(rates, 3)]
    bs = [F(random.choice(starts)) for _ in range(3)]
    reps = ["words", "eq", "table"]
    random.shuffle(reps)
    visual = {"notes": []}
    table_part = None
    for n, m, b, rep in zip(names, ms, bs, reps):
        v = _rate_rep(kind, n, unit, xh, yh, m, b, rep)
        if "table" in v:
            table_part = (v["notes"], v["table"])
        else:
            visual["notes"] += v["notes"]
    visual["notes"] += table_part[0]
    visual["table"] = table_part[1]
    order = [n for _, n in sorted(zip(ms, names), reverse=True)]
    by_start = [n for _, n in sorted(zip(bs, names), reverse=True)] if len(set(bs)) == 3 else None
    perms = [", ".join(p) for p in itertools.permutations(names)]
    ans = ", ".join(order)
    traps = [", ".join(reversed(order))] + ([", ".join(by_start)] if by_start else []) + [p for p in perms if p != ans]
    return build(f"Order by rate per {unit}, greatest to least.", ans, traps, visual)


# Things that go DOWN at a steady rate (W9L4 Your Turn 2: two tanks draining)
DRAIN = [
    # (thing, what is left, x unit (one), x letter meaning, value format, rates, starts, words)
    ("Tank", "water", "minute", "minutes", as_units("L"), [2, 3, 4, 5, 6, 8, 10, 12, 15],
     [40, 50, 60, 75, 80, 90, 100, 120, 150],
     lambda n, b, r: f"Tank {n} holds {b} L and drains {r} L per minute."),
    ("Candle", "wax", "hour", "hours", as_units("cm"), [1, 2, 3, 4, 5, 6],
     [12, 15, 18, 20, 24, 25, 30, 36],
     lambda n, b, r: f"Candle {n} is {b} cm tall and burns down {r} cm per hour."),
    ("Phone", "battery", "hour", "hours", as_pct, [4, 5, 6, 8, 10, 12, 15, 20],
     [50, 60, 70, 75, 80, 85, 90, 95, 100],
     lambda n, b, r: f"Phone {n} is at {b}% and drops {r}% per hour."),
    ("Card", "money", "coffee", "coffees", as_money, [2, 3, 4, 5, 6, 7],
     [20, 25, 30, 35, 40, 45, 50, 60],
     lambda n, b, r: f"Card {n} has ${b}. Each coffee costs ${r}."),
]


def b6_drain():                                      # M  (W9L4 Your Turn 2: which drains faster? more at start?)
    thing, what, one, xs_word, fmt, rates, starts, words = random.choice(DRAIN)
    rA, rB = random.sample(rates, 2)
    bA, bB = random.sample(starts, 2)
    if random.random() < 0.6:
        notes = [f"{thing} A:  y = {expr(-rA, bA, 'x')}", f"{thing} B:  y = {expr(-rB, bB, 'x')}",
                 f"(x = {xs_word},  y = {what} left)"]
    else:
        notes = [words("A", bA, rA), words("B", bB, rB)]
    f = lambda v: fmt([v])[0]
    if random.random() < 0.6:                        # who goes down faster, and by how much?
        fast = "A" if rA > rB else "B"
        d = abs(rA - rB)
        alts = [abs(bA - bB), rA + rB, d + 1, 2 * d] + ([d - 1] if d > 1 else [])
        return two_way(f"Which {thing.lower()} goes down faster? By how much per {one}?",
                       lambda a, w: f"{thing} {w}, {f(a)} more", d, fast, alts,
                       "B" if fast == "A" else "A", {"notes": notes})
    more = "A" if bA > bB else "B"
    d = abs(bA - bB)
    alts = [abs(rA - rB), d + 5, d + 10, 2 * d] + ([d - 5] if d > 5 else [])
    return two_way(f"Which {thing.lower()} has more {what} at the start? By how much?",
                   lambda a, w: f"{thing} {w}, by {f(a)}", d, more, alts,
                   "B" if more == "A" else "A", {"notes": notes})


def b6_order_slopes():                               # M  (W9L3 card sort, W9L4 Part 2: steepest?)
    names = ["A", "B", "C"]
    mode = random.choice(["least", "steep", "down"])
    use_pts = random.random() < 0.6                  # two marked points per line, on a grid (W9L4 Part 2)
    for _ in range(300):
        if mode == "down":                           # all three go down (W9L4 Part 2)
            ms = [F(v) for v in random.sample([-1, -2, -3, -4, -5, F(-1, 2), F(-3, 2)], 3)]
        else:
            ms = [F(v) for v in random.sample([F(-1, 2), -1, -2, -3, -4, F(1, 2), 1, 2, 3, 4, 5, F(3, 2), F(-3, 2)], 3)]
            if all(m > 0 for m in ms) or all(m < 0 for m in ms):
                continue
        if len({abs(m) for m in ms}) < 3:
            continue
        bs = random.sample(range(-5, 9), 3)
        lines, ok = [], True
        for m, b in zip(ms, bs):
            dx = 2 if m.denominator == 2 else random.choice([1, 2, 3])
            x1 = random.randint(-2, 3)
            p, q = (x1, m * x1 + b), (x1 + dx, m * (x1 + dx) + b)
            if use_pts and not all(abs(v) <= 8 and F(v).denominator == 1 for v in (*p, *q)):
                ok = False
                break
            lines.append((p, q))
        if ok:
            break
    else:
        return None
    if use_pts:
        notes = [f"Line {n}: {pt(*p)} and {pt(*q)}" for n, (p, q) in zip(names, lines)]
        visual = {"notes": notes,
                  "grid": {"r": 8, "lines": [(m, b, n) for m, b, n in zip(ms, bs, names)],
                           "points": [(x, y, "") for p, q in lines for x, y in (p, q)]}}
    else:
        visual = {"notes": [f"Line {n}:  {eq(m, b)}" for n, m, b in zip(names, ms, bs)]}
    by = lambda key, rev=False: ", ".join(n for _, n in sorted(zip(key, names), reverse=rev))
    if mode == "least":
        text = "Order the lines by slope, from least to greatest."
        ans = by(ms)
        traps = [by([abs(m) for m in ms]), by(ms, True), by(bs)]
    else:
        text = ("All three lines go down. " if mode == "down" else "") + "Order from steepest to least steep."
        ans = by([abs(m) for m in ms], True)
        traps = [by(ms, True), by([abs(m) for m in ms]), by(bs, True)]
    perms = [", ".join(p) for p in itertools.permutations(names)]
    return build(text, ans, traps, visual, extra=perms)


def b6_greater_rate():                               # M  (W9L4 Part 3: circle the greater rate, or "same")
    pool = [F(1, 2), F(1), F(3, 2), F(2), F(5, 2), F(3), F(4), F(5), F(6)]
    same = random.random() < 0.2
    for _ in range(200):
        m1, m2 = random.sample(pool, 2)
        if same:
            m2 = m1
        b1, b2 = random.randint(-9, 12), random.choice([0] + list(range(-9, 13)))
        if b1 == b2:
            continue
        if not same and random.random() < 0.7 and (m1 - m2) * (b1 - b2) > 0:
            continue                                 # usually the smaller rate has the bigger start
        break
    e1, e2 = eq(m1, b1), eq(m2, b2)
    d, db = abs(m1 - m2), F(abs(b1 - b2))
    eb = e1 if b1 > b2 else e2                       # bigger start (Sam's mistake)
    es = e2 if b1 > b2 else e1
    by = lambda e, v: f"{e}, by {fnum(v)}"
    if same:
        right = "Same rate"
        traps = [by(eb, db), by(eb, m1), by(es, db), by(eb, 2 * m1), by(e1, 1)]
    else:
        big, small = (e1, e2) if m1 > m2 else (e2, e1)
        right = by(big, d)
        traps = [by(eb, db), by(small, d), "Same rate", by(big, db), by(big, m1 + m2), by(small, db)]
    return build(f"Which has the greater rate (slope)?   {e1}   or   {e2}", right, traps)


def b6_misread():                                    # M  (W9L3 Sam / W9L4 Jay: Check Your Thinking)
    who = random.choice(NAMES)
    if random.random() < 0.5:                        # Sam: compares the starts, not the rates
        for _ in range(100):
            ms, ml = sorted(random.sample([F(1, 2), F(1), F(3, 2), F(2), F(3), F(4), F(5)], 2))
            bs, bl = random.randint(-4, 12), random.randint(-9, 6)
            if bs > bl:
                break
        weak, strong = eq(ms, bs), eq(ml, bl)
        text = (f"{who} says {weak} is steeper than {strong} because {fnum(bs)} > {fnum(bl)}. "
                f"Which line is really steeper, and why?")
        return build(text, f"{strong}: bigger rate",
                     [f"{weak}: bigger start", f"{weak}: bigger rate", f"{strong}: smaller start",
                      "Same: they are both lines"])
    for _ in range(100):                             # Jay: "greater at x = 1, so always greater"
        m1, m2 = sorted(random.sample([1, 2, 3, 4, 5], 2))
        b1, b2 = random.choice([20, 30, 40, 50, 60, 80, 100]), random.choice([0, 0, 2, 5, 10])
        if m1 + b1 > m2 + b2:
            break
    e1, e2 = eq(m1, b1), eq(m2, b2)
    text = (f"{who} plugs x = 1 into {e1} and {e2} and gets {m1 + b1} and {m2 + b2}. "
            f"{who} says {e1} is always greater. Is that right?")
    return build(text, f"No: {e2} grows faster, so it catches up",
                 ["Yes: it starts higher", "Yes: it is greater at x = 1", f"No: {e1} grows faster",
                  "Yes: two lines never cross"])


def b6_solve():                                      # NOT TAUGHT YET (warm-up: solve 26 - 2t = 38 - 4t)
    while True:
        t = random.randint(3, 12)
        m1, m2 = random.sample([-6, -5, -4, -3, -2, 2, 3, 4, 5, 6, 7, 8, 9], 2)
        b1 = random.randint(5, 50)
        b2 = b1 + (m1 - m2) * t
        if 0 < b2 <= 90 and b1 != b2:
            break
    sf = random.random() < 0.5
    text = f"Solve:   {expr(m1, b1, 't', sf)} = {expr(m2, b2, 't', sf)}"
    traps = [-t, abs(b2 - b1), F(b1 + b2, abs(m1 - m2)), t + 1, t - 1, t + 2, t - 2]
    return build_num(text, t, traps, fmt=as_prefix("t = "), ok=lambda v: pos_int(v) or v == -t)


# ==========================================
# 8b. BATTLE 7 - Lines from Two Points
#    W10L1 (Rate & Start review: any table, plug in a point, check with a second point)
#    W10L2 (Two Points -> Equation & Graph).  Wrong answers = the worksheets' equation-bank
#    mistakes:  first y used as the start,  change in y not divided by the change in x,
#    subtracted in different orders (wrong sign),  b = y + mx instead of y - mx.
# ==========================================
def two_pts(span=5, ylim=20, halves=True, ints_only_b=True):
    """Two points on y = mx + b, listed in a random order: ((x1, y1), (x2, y2), m, b)."""
    while True:
        if halves and random.random() < 0.12:
            m = F(random.choice([1, -1, 3, -3]), 2)
        else:
            m = F(random.choice([1, 2, 2, 3, 3, 4, 5, -1, -2, -2, -3, -3, -4, -5]))
        b = F(random.randint(-8, 9))
        if random.random() < 0.25:                     # like card 1: one point is (0, b)
            x1 = 0
        else:
            x1 = nz(-span, span)
        x2 = x1 + random.choice([2, 2, 3, 3, 4, 5]) * random.choice([1, 1, -1])
        if abs(x2) > span + 1 or x2 == x1:
            continue
        if m.denominator == 2 and (x1 % 2 or x2 % 2):
            continue
        y1, y2 = m * x1 + b, m * x2 + b
        if abs(y1) > ylim or abs(y2) > ylim or y1 == y2:
            continue
        if random.random() < 0.4:                      # either point can be listed first
            (x1, y1), (x2, y2) = (x2, y2), (x1, y1)
        return (x1, y1), (x2, y2), m, b


def _two_pt_mistakes(p, q, m, b):
    """(m, b) pairs students really get, most common first (W10 equation banks)."""
    (x1, y1), (x2, y2) = p, q
    dx, dy = x2 - x1, y2 - y1
    out = []
    if x1 != 0:
        out.append((m, y1))                            # first y-value used as the start
    out.append((dy, y1 - dy * x1))                     # forgot to divide by the change in x
    out.append((-m, y1 + m * x1))                      # subtracted in different orders
    out.append((m, y1 + m * x1))                       # b = y + mx instead of y - mx
    if x2 != 0:
        out.append((m, y2))                            # second y-value used as the start
    if dy:
        r = F(dx, dy)
        out.append((r, y1 - r * x1))                   # change in x over change in y
    return [(a, c) for a, c in out if nice(a) and nice(c) and (a, c) != (m, b)]


def _eq_list(pairs):
    return [eq(a, c) for a, c in pairs if nice(a) and nice(c)]


def b7_equation():                                   # M/H  (W10L2: two points -> y = mx + b)
    p, q, m, b = two_pts()
    traps = _eq_list(_two_pt_mistakes(p, q, m, b))
    extra = _eq_list([(m, -b), (-m, b), (-m, -b), (m, b + m), (m, b - m), (m + 1, b), (m - 1, b)])
    return build(f"Find the equation of the line through {pt(*p)} and {pt(*q)}.", eq(m, b),
                 traps, extra=extra)


def b7_grid():                                       # M  (W10L1 cards 3, 6 and W10L2 cards 4, 5)
    p, q, m, b = two_pts(span=5, ylim=7, halves=False)
    names = random.sample(["A", "B", "P", "Q", "M", "N"], 2)
    g = {"r": 8, "points": [(p[0], p[1], names[0]), (q[0], q[1], names[1])]}
    if random.random() < 0.45:                       # the line is drawn: read the start, then check it
        g["lines"] = [(m, b)]
        text = f"Find the equation of the line. Use the points {names[0]} and {names[1]}."
    else:                                            # only the two dots: draw the line in your head
        text = f"Which equation is the line through {names[0]} and {names[1]}?"
    traps = _eq_list(_two_pt_mistakes(p, q, m, b))
    extra = _eq_list([(m, -b), (-m, b), (-m, -b), (m, b + m), (m, b - m), (m + 1, b), (m - 1, b)])
    return build(text, eq(m, b), traps, {"grid": g}, extra)


def b7_rate():                                       # M  (W10L2 warm-up + Noah's mistake)
    p, q, m, b = two_pts()
    (x1, y1), (x2, y2) = p, q
    dx, dy = x2 - x1, y2 - y1
    traps = [-m, dy, F(dx, dy), F(y2 + y1, x2 + x1) if x2 + x1 else None,
             F(y2, x2) if x2 else None, dy - dx]
    step = F(1, 2) if m.denominator == 2 else 1
    return build_num(f"Find the rate (slope) of the line through {pt(*p)} and {pt(*q)}.", m, traps,
                     ok=lambda v: nice(v) and v != 0,
                     extra=[m + step, m - step, m + 2 * step, m - 2 * step, 2 * m])


def b7_start():                                      # M  (plug in a point and solve for b)
    while True:
        p, q, m, b = two_pts()
        if p[0] != 0 and q[0] != 0:
            break
    (x1, y1), (x2, y2) = p, q
    dy = y2 - y1
    traps = [y1, y1 + m * x1, y2, y1 - dy * x1, -b, b + m, b - m, y2 + m * x2]
    return build_num(f"Find the start (y-intercept) of the line through {pt(*p)} and {pt(*q)}.",
                     b, traps, ok=nice)


def _ctx_two():
    """A word situation with two data points (W10L2 #3: taxi rides)."""
    t = random.choice(["taxi", "plumber", "gym", "plant", "candle", "tank"])
    x1 = random.randint(1, 5)
    x2 = x1 + random.randint(2, 6)
    if t == "taxi":
        m, b = F(random.choice([F(3, 2), 2, F(5, 2), 3])), F(random.choice([3, 4, 5, 6]))
        if (m * x1).denominator != 1:
            x1 += 1
            x2 += 2
        c = dict(xu="km", fmt=as_money, okq=pos_q,
                 sent=lambda: f"A {x1} km taxi ride costs {money(m * x1 + b)}. A {x2} km ride costs {money(m * x2 + b)}.",
                 val=lambda n: f"How much does a {n} km ride cost?", start="What is the flat fee (the cost at 0 km)?",
                 rate=lambda v: f"{money(v)} per km", q_rate="How much does the taxi charge per km?",
                 inv=lambda V: f"How far can you ride for {money(V)}?")
    elif t == "plumber":
        m, b = F(random.choice([40, 50, 60, 75, 80])), F(random.choice([50, 60, 75, 90, 100]))
        c = dict(xu="hours", fmt=as_money, okq=pos_q,
                 sent=lambda: f"A plumber charges {money(m * x1 + b)} for {x1} hours and {money(m * x2 + b)} for {x2} hours.",
                 val=lambda n: f"How much does {n} hours of work cost?", start="What is the plumber's call-out fee (at 0 hours)?",
                 rate=lambda v: f"{money(v)} per hour", q_rate="What is the hourly rate?",
                 inv=lambda V: f"How many hours of work cost {money(V)}?")
    elif t == "gym":
        m, b = F(random.choice([20, 25, 30, 35, 40])), F(random.choice([40, 50, 60, 75, 80, 100]))
        c = dict(xu="months", fmt=as_money, okq=pos_q,
                 sent=lambda: f"A gym costs {money(m * x1 + b)} in total for {x1} months and {money(m * x2 + b)} for {x2} months.",
                 val=lambda n: f"What is the total cost for {n} months?", start="What is the sign-up fee (at 0 months)?",
                 rate=lambda v: f"{money(v)} per month", q_rate="How much is the gym per month?",
                 inv=lambda V: f"After how many months is the total cost {money(V)}?")
    elif t == "plant":
        m, b = F(random.choice([2, 3, 4, 5])), F(random.randint(3, 12))
        c = dict(xu="weeks", fmt=as_units("cm"), okq=lambda v: v > 0 and nice(v, 2),
                 sent=lambda: f"A plant is {fnum(m * x1 + b)} cm tall after {x1} weeks and {fnum(m * x2 + b)} cm tall after {x2} weeks.",
                 val=lambda n: f"How tall is the plant after {n} weeks?", start="How tall was the plant at week 0?",
                 rate=lambda v: f"{fnum(v)} cm per week", q_rate="How much does the plant grow each week?",
                 inv=lambda V: f"In which week is the plant {fnum(V)} cm tall?")
    elif t == "candle":
        r = random.choice([2, 3, 4])
        m, b = F(-r), F(r * random.randint(x2 + 4, x2 + 12))
        c = dict(xu="hours", fmt=as_units("cm"), okq=lambda v: v > 0 and nice(v, 2),
                 sent=lambda: f"A candle is {fnum(m * x1 + b)} cm tall after {x1} hours and {fnum(m * x2 + b)} cm after {x2} hours.",
                 val=lambda n: f"How tall is the candle after {n} hours?", start="How tall was the candle before it was lit?",
                 rate=lambda v: f"{fnum(v)} cm per hour", q_rate="What is the rate of change, with units?",
                 inv=lambda V: f"After how many hours is the candle {fnum(V)} cm tall?")
    else:
        r = random.choice([5, 10, 15, 20, 25])
        m, b = F(-r), F(r * random.randint(x2 + 4, x2 + 12))
        c = dict(xu="minutes", fmt=as_units("L"), okq=lambda v: v > 0 and nice(v, 2),
                 sent=lambda: f"A tank has {fnum(m * x1 + b)} L after {x1} minutes and {fnum(m * x2 + b)} L after {x2} minutes.",
                 val=lambda n: f"How much water is left after {n} minutes?", start="How much water was in the tank at the start?",
                 rate=lambda v: f"{fnum(v)} L per minute", q_rate="What is the rate of change, with units?",
                 inv=lambda V: f"After how many minutes does the tank have {fnum(V)} L?")
    c.update(m=m, b=b, x1=x1, x2=x2, y1=m * x1 + b, y2=m * x2 + b)
    c["visual"] = {"notes": [c["sent"]()]}
    return c


def b7_context():                                    # H  (W10L2 #3: 2 km costs $9, 6 km costs $17)
    c = _ctx_two()
    m, b, x1, x2, y1, y2 = c["m"], c["b"], c["x1"], c["x2"], c["y1"], c["y2"]
    dy = y2 - y1
    kind = random.choices(["val", "start", "rate", "inv"], [4, 3, 1, 2])[0]
    if kind == "rate":
        rate_all = lambda vals: [c["rate"](v) for v in vals]
        return build_num(c["q_rate"], m, [dy, -m, F(y2, x2), F(y1, x1), F(x2 - x1, dy)], fmt=rate_all,
                         ok=lambda v: nice(v, 4) and v != 0, visual=c["visual"],
                         extra=[m * 2, m + (5 if abs(m) >= 10 else 1), m - (5 if abs(m) >= 10 else 1)])
    if kind == "start":
        traps = [y1, y1 - dy, y1 + m * x1, y1 - m, b + m, b - m]
        return build_num(c["start"], b, traps, fmt=c["fmt"], ok=c["okq"], visual=c["visual"])
    end = int(-b / m) if m < 0 else None
    if kind == "val":
        hi = (end - 1) if end else x2 + 8
        ns = [n for n in range(2, hi + 1) if n not in (x1, x2)]
        if not ns:
            return None
        n = random.choice(ns)
        ans = m * n + b
        traps = [F(y1 * n, x1), m * n, y2 + dy, y2 + dy * (n - x2), ans + m, ans - m, b + m * (n - 1)]
        return build_num(c["val"](n), ans, traps, fmt=c["fmt"], ok=c["okq"], visual=c["visual"])
    hi = (end - 1) if end else x2 + 8
    ns = [n for n in range(2, hi + 1) if n not in (x1, x2)]
    if not ns:
        return None
    n = random.choice(ns)
    V = m * n + b
    traps = [F(V, m), F(V - b, dy) if dy else None, F(V * x1, y1), n + 1, n - 1, F(V + b, m)]
    return build_num(c["inv"](V), n, traps, fmt=as_units(c["xu"]), ok=lambda v: pos_int(v),
                     visual=c["visual"])


def b7_third_point():                                # M  (check with a second point: is it on the line?)
    p, q, m, b = two_pts(halves=False)
    used = {p[0], q[0]}
    x3 = random.choice([x for x in range(-6, 9) if x not in used])
    y3 = m * x3 + b
    on = lambda x, y: y == m * x + b
    cands = [(x3, a * x3 + c) for a, c in _two_pt_mistakes(p, q, m, b)]
    cands += [(y3, x3), (x3, y3 + 1), (x3, y3 - 1), (x3 + 1, y3), (-x3, y3), (x3, -y3)]
    traps = []
    for x, y in cands:
        s = pt(x, y)
        if not on(x, y) and nice(y) and abs(y) <= max(30, 2 * abs(y3)) and s not in traps:
            traps.append(s)
    return build(f"A line goes through {pt(*p)} and {pt(*q)}. Which point is also on it?",
                 pt(x3, y3), traps[:4], extra=traps[4:])


def b7_same_line():                                  # M  (W10L2 Think It Through: (1, 4), (3, 10), (5, 15))
    while True:
        m, b = nz(-4, 5), random.randint(-6, 8)
        x1 = random.randint(-3, 3)
        s1, s2 = random.randint(1, 4), random.randint(1, 4)
        if random.random() < 0.6 and s1 == s2:
            continue                                 # mostly uneven steps, like the worksheet
        xs = [x1, x1 + s1, x1 + s1 + s2]
        ys = [m * x + b for x in xs]
        linear = random.random() < 0.5
        r2 = m
        if not linear:
            r2 = m + random.choice([-2, -1, 1, 2])
            if r2 == 0:
                continue
            ys[2] = ys[1] + r2 * s2
        if all(abs(y) <= 30 for y in ys):
            break
    dy1, dy2 = ys[1] - ys[0], ys[2] - ys[1]
    Y = lambda r: f"Yes: the rate is {fnum(r)} both times"
    N = lambda a, c: f"No: the rates are {fnum(a)} and {fnum(c)}"
    J = lambda a, c: f"No: the y-jumps are {fnum(a)} and {fnum(c)}"
    if linear:
        right = Y(m)
        traps = [J(dy1, dy2) if dy1 != dy2 else None, Y(dy1) if s1 != 1 else None, Y(-m),
                 N(m, m + 1), N(m, m - 1), N(dy1, m)]
    else:
        right = N(m, r2)
        traps = [Y(m), Y(r2), N(dy1, dy2) if (dy1, dy2) != (m, r2) else None,
                 N(m, r2 + (1 if r2 > m else -1)), N(-m, r2)]
    pts = [pt(x, y) for x, y in zip(xs, ys)]
    return build(f"Are {pts[0]}, {pts[1]} and {pts[2]} on the same line?", right, traps)


MISTAKE_WORDS = {
    "nodiv": "Forgot to divide by the x-change",
    "firsty": "Used the first y as the start",
    "sign": "Got the sign of the rate wrong",
    "flip": "Divided the x-change by the y-change",
    "ok": "Nothing: the equation is correct",
}


def b7_mistake():                                    # M  (W10 Check Your Thinking: Ben / Noah)
    who = random.choice(["Ben", "Noah", "Priya", "Leo", "Ana", "Sam"])
    for _ in range(50):
        p, q, m, b = two_pts(halves=False)
        (x1, y1), (x2, y2) = p, q
        dx, dy = x2 - x1, y2 - y1
        kind = random.choices(list(MISTAKE_WORDS), [3, 3, 3, 2, 2])[0]
        if kind == "nodiv":
            wm, wb = dy, y1 - dy * x1
        elif kind == "firsty":
            if x1 == 0:
                continue
            wm, wb = m, y1
        elif kind == "sign":
            wm, wb = -m, y1 + m * x1
        elif kind == "flip":
            wm = F(dx, dy)
            wb = y1 - wm * x1
        else:
            wm, wb = m, b
        if not (nice(wm) and nice(wb)) or (kind != "ok" and (wm, wb) == (m, b)):
            continue
        break
    else:
        return None
    return build(f"{who} finds the line through {pt(*p)} and {pt(*q)} and writes {eq(wm, wb)}. "
                 f"What went wrong?", MISTAKE_WORDS[kind],
                 [v for k, v in MISTAKE_WORDS.items() if k != kind])


# ==========================================
# 9. QUESTION PICKER  (weighted mix per battle, no repeats in a session)
#    Weights: E types total about 1 in 8.  Change a number to see a type more or less.
#    Not taught yet (leave out until the lesson): b6_equal_time, b6_equal_value, b6_interval,
#    b6_solve, b4_cross_slanted.
# ==========================================
GENERATORS = {
    1: [(b1_quadrant, 2), (b1_read_point, 4), (b1_moves, 3), (b1_pattern, 5), (b1_proportion, 3), (b1_rate_word, 3)],
    2: [(b2_evaluate, 1), (b2_words_eq, 5), (b2_words_value, 4), (b2_table_from_eq, 3),
        (b2_match_table, 2), (b2_match_graph, 2), (b2_graph_type, 2), (b2_point_on_graph, 2)],
    3: [(b3_equation, 6), (b3_rate, 2), (b3_start, 2), (b3_context, 6), (b3_two_points, 2)],
    4: [(b4_table_value, 3), (b4_which_line, 3), (b4_match_graph, 3), (b4_hv_type, 2),
        (b4_hv_through, 2), (b4_describe, 2), (b4_cross, 1), (b4_point_on_line, 2), (b4_line_or_not, 3)],
    5: [(b5_two_points, 1), (b5_meaning, 5), (b5_rate, 3), (b5_predict, 3), (b5_predict_x, 3),
        (b5_inter_extra, 3), (b5_zero, 1)],
    6: [(b6_write_eq, 1), (b6_at_time, 3), (b6_compare_rate, 4), (b6_sort_rates, 2),
        (b6_drain, 3), (b6_order_slopes, 3), (b6_greater_rate, 3), (b6_misread, 2)],
    7: [(b7_rate, 1), (b7_equation, 6), (b7_grid, 4), (b7_start, 2), (b7_context, 5),
        (b7_third_point, 2), (b7_same_line, 2), (b7_mistake, 2),
        (b3_equation, 2), (b3_context, 1)],                 # W10L1 review: equation from any table
}

_seen = {lvl: set() for lvl in GENERATORS}


def next_question(level, last_gen=None):
    """Returns (Question, generator).  Avoids repeats and the same type twice in a row."""
    gens, weights = zip(*GENERATORS[level])
    for attempt in range(400):
        g = random.choices(gens, weights)[0]
        if g is last_gen and attempt < 200 and len(gens) > 1:
            continue
        q = g()
        if q is None:
            continue
        if q.key() in _seen[level] and attempt < 300:
            continue
        _seen[level].add(q.key())
        return q, g
    raise RuntimeError("could not make a question")


# ==========================================
# 10. WHAT main.py CALLS
# ==========================================
TOPIC_COUNT = 7
_last_gen = {}          # topic -> the question type used last (never the same type twice in a row)


def make_question(n):
    """(question text, correct choice, 5 choices, visual or None) for topic n (1-7)."""
    q, _last_gen[n] = next_question(n, _last_gen.get(n))
    return q.text, q.correct, q.options, q.visual
