# ==========================================
# pokedex.py  -  every Pokemon the game can show.  THE file to edit when you add a Pokemon.
#   (No pygame here: plain data, used by single player and team battles.)
#   Same file as the Precalculus 11 game (same sprite folders).
#
# Sprite files, for folder N:
#   pokemonN/pokemonN_front (1).gif, (2).gif, ...   facing you (opponents)
#   pokemonN/pokemonN_back (1).gif, (2).gif, ...    seen from behind (your own Pokemon)
#   pokemonN/pokemonN_faint.ogg                     faint sound (optional)
# If a Pokemon has only one of front/back, that one is used for both.
# Sprites are sized and placed automatically (the game finds the visible part of the GIF),
# so a new sprite needs no position numbers. "scale" makes one a bit bigger (1.2) or smaller (0.8).
# "shift" moves one a little from its automatic spot: (x, y) in screen pixels,
# e.g. (0, 20) = 20 lower, (-15, 0) = 15 to the left.
# Exception: an entry with "single" uses those exact hand-tuned numbers in single player
# (the original game's positions). Team battles always use the automatic spots.
#
# To add a Pokemon: copy an entry, change the name, folder and moves. That's it.
#
# Folders (new Pokemon take the next free number: 17, 18, ...):
#    0 Pikachu     1 Raichu                                  the students' team
#    2 Charizard   3 Blastoise   4 Venusaur                  Kanto starters   (music2-4)
#    5 Infernape   6 Empoleon    7 Torterra                  Sinnoh starters  (music5-7)
#    8 Blaziken    9 Swampert   10 Sceptile                  Hoenn starters   (music8-10)
#   11 Snorlax    12 Mewtwo     13 Wobbuffet                 other opponents
#   14 Vaporeon   15 Flareon    16 Jolteon                   Eeveelutions
#   17 Scrafty    18 Lilligant  19 Audino   20 Purugly       Class Raid (students pick these)
#   21 Luxray     22 Eevee      23 Seadra   24 Magikarp
#
# Moves: (name, power, miss %, crit %, effect)
#   effect = the animation and sound: "hit", "fire", "water", "leaf", "bolt", "thunder"
#   Damage = power x attack / 100.  Low power: rarely misses, crits often.
#                                   High power: misses often, rarely crits.
# "attack" = the move name used when a student answers correctly (Pikachu and Raichu).
# Class Raid: every Pokemon with an "attack" (except Mewtwo, the boss) can be picked by a student.
#   "attack_effect" = its animation in the raid (same names as the moves' effects, or None = nothing).
#   Single player and Team Battle never read "attack_effect", and only use "attack" for Pikachu/Raichu.
# ==========================================

POKEMON = {
    # ---------- the students' team ----------
    "Pikachu": {"folder": 0, "attack": "Thundershock", "attack_effect": "bolt", "scale": 0.8},     # smaller than Raichu
    "Raichu":  {"folder": 1, "attack": "Thunderbolt", "attack_effect": "bolt",
                "single": (575, 485, 50, 350, 70, 0, 0.75)},                 # original single-player spot

    # ---------- opponents ----------
    # (Vaporeon, Flareon and Jolteon have no "single" spot, so in single player they use the automatic one.)
    "Vaporeon": {"folder": 14, "attack": "Hydro Pump", "attack_effect": "water", "moves": [
        ("Water Gun",    20,  0, 30, "water"),
        ("Bite",         30,  8, 15, "hit"),
        ("Aurora Beam",  35, 15,  8, "hit"),
        ("Hydro Pump",   45, 35,  5, "water")]},
    "Flareon": {"folder": 15, "scale": 1.2, "attack": "Flamethrower", "attack_effect": "fire", "moves": [                      # head size like Vaporeon's
        ("Ember",        20,  0, 30, "fire"),
        ("Quick Attack", 30,  8, 15, "hit"),
        ("Flamethrower", 35, 15,  8, "fire"),
        ("Fire Blast",   45, 35,  5, "fire")]},
    "Jolteon": {"folder": 16, "scale": 1.0, "shift": (0, 0), "attack": "Thunderbolt", "attack_effect": "bolt", "moves": [
        ("Thundershock", 20,  0, 30, "bolt"),
        ("Double Kick",  30,  8, 15, "hit"),
        ("Pin Missile",  35, 15,  8, "hit"),
        ("Thunder",      45, 35,  5, "thunder")]},

    # ---------- single-player opponents (same moves as the original game) ----------
    # "single" = the original hand-tuned single-player layout:
    #   (HP box x, HP box y, sprite x, sprite y, Thunderbolt x shift, Thunderbolt y shift, sprite scale)
    #   sprite x, y = top-left corner of the GIF;  scale = zoom on the GIF's real size.
    "Charizard": {"folder": 2, "single": (150, 100, 625,  -50, 70,    0, 0.8),
                  "attack": "Flamethrower", "attack_effect": "fire", "moves": [
        ("Tackle",       25,  0,  0, "hit"),
        ("Iron Tail",    30,  9, 15, "hit"),
        ("Flamethrower", 35, 15,  5, "fire"),
        ("Fire Punch",   30, 12, 10, "fire")]},
    "Blastoise": {"folder": 3, "single": (150, 100, 650,  175, 50, -350, 0.9),
                  "attack": "Hydro Pump", "attack_effect": "water", "moves": [
        ("Tackle",       25,  0,  0, "hit"),
        ("Iron Tail",    30, 10, 15, "hit"),
        ("Skull Bash",   30, 20, 30, "hit"),
        ("Hydro Pump",   35, 30, 10, "water")]},
    "Venusaur": {"folder": 4, "single": (150, 100, 600,  175, 50, -350, 0.9),
                 "attack": "Solar Beam", "attack_effect": "thunder", "moves": [
        ("Bolt Strike",  30, 10, 10, "thunder"),
        ("Body Slam",    35, 15,  5, "hit"),
        ("Skull Bash",   25,  5, 20, "hit"),
        ("Leaf Tornado", 40, 30,  5, "leaf")]},
    "Infernape": {"folder": 5, "single": (150, 100, 700,   80, 50, -350, 1.3),
                  "attack": "Flare Blitz", "attack_effect": "fire", "moves": [
        ("Iron Tail",    30,  9, 15, "hit"),
        ("Body Slam",    35, 15,  5, "hit"),
        ("Skull Bash",   25,  5, 20, "hit"),
        ("Fire Punch",   30, 12, 10, "fire")]},
    "Empoleon": {"folder": 6, "single": (150, 100, 700,  130, 50, -350, 1.1),
                 "attack": "Surf", "attack_effect": "water", "moves": [
        ("Aqua Jet",     20,  0, 30, "water"),
        ("Drill Peck",   30,  8, 15, "hit"),
        ("Flash Cannon", 35, 15,  8, "hit"),
        ("Hydro Pump",   45, 35,  5, "water")]},
    "Torterra": {"folder": 7, "single": (150, 100, 675,  130, 50, -350, 1.1),
                 "attack": "Wood Hammer", "attack_effect": "hit", "moves": [
        ("Bite",         20,  0, 30, "hit"),
        ("Body Slam",    30,  8, 12, "hit"),
        ("Earthquake",   40, 25,  5, "hit"),
        ("Leaf Tornado", 45, 35,  5, "leaf")]},
    "Snorlax": {"folder": 11, "single": (150, 100, 650,  150, 50, -350, 1.0),
                "attack": "Body Slam", "attack_effect": "hit", "moves": [
        ("Headbutt",     20,  0, 30, "hit"),
        ("Fire Punch",   30,  8, 15, "fire"),
        ("Body Slam",    40, 20,  8, "hit"),
        ("Giga Impact",  50, 40,  5, "hit")]},
    # ---- Hoenn starters (Math 9: Graphing Lines, Reading Graphs, Comparing Relations) ----
    # Same moves and single-player spots as the old Linear Relations game (its folders 1, 2, 3).
    # If a sprite sits in the wrong place, change its "single" numbers, or delete "single"
    # to use the automatic spot.
    "Blaziken": {"folder": 8, "single": (150, 100, 650,  150, 70, -350, 1.1),
                 "attack": "Blaze Kick", "attack_effect": "fire", "moves": [
        ("Blaze Kick",     35, 15,  5, "fire"),
        ("High Jump Kick", 30, 10, 15, "hit"),
        ("Flamethrower",   35, 15,  5, "fire"),
        ("Brave Bird",     30,  9, 10, "hit")]},
    "Swampert": {"folder": 9, "single": (150, 100, 650,  160, 50, -350, 1.0),
                 "attack": "Muddy Water", "attack_effect": "water", "moves": [
        ("Hydro Pump",     35, 30, 10, "water"),
        ("Muddy Water",    30, 10, 10, "water"),
        ("Quick Attack",   30, 20, 30, "hit"),
        ("Hammer Arm",     25,  0,  0, "hit")]},
    "Sceptile": {"folder": 10, "single": (150, 100, 650,  165, 50, -350, 1.0),
                 "attack": "Leaf Blade", "attack_effect": "hit", "moves": [
        ("Leaf Blade",     35, 15,  5, "leaf"),
        ("Leaf Storm",     40, 30,  5, "leaf"),
        ("Energy Ball",    30, 10, 10, "thunder"),
        ("X-Scissor",      25,  5, 20, "hit")]},
    # ---- Linear Relations boss (Math 9: Lines from Two Points, Week 10) ----
    # No "single" numbers: it uses the automatic spot.  If it looks too big or small,
    # add "scale": 0.9 (or 1.1) here.
    "Wobbuffet": {"folder": 13, "single": (150, 100, 750,  165, 50, -350, 1.0),
                  "attack": "Counter", "attack_effect": "hit", "moves": [
        ("Counter",        20,  0, 30, "hit"),
        ("Mirror Coat",    30,  8, 15, "thunder"),
        ("Charm",          35, 15,  8, "hit"),
        ("Destiny Bond",   45, 35,  5, "hit")]},

    # ---- Class Raid only (students pick them; they are never opponents, so no "moves") ----
    # If one looks too big or small in the raid, add "scale": 0.9 (or 1.1), like Pikachu above.
    "Scrafty":   {"folder": 17, "attack": "High Jump Kick", "attack_effect": "hit"},
    "Lilligant": {"folder": 18, "attack": "Petal Dance",    "attack_effect": "hit"},
    "Audino":    {"folder": 19, "attack": "Hyper Voice",    "attack_effect": "hit"},
    "Purugly":   {"folder": 20, "attack": "Body Slam",      "attack_effect": "hit"},
    "Luxray":    {"folder": 21, "attack": "Thunder Fang",   "attack_effect": "bolt"},
    "Eevee":     {"folder": 22, "attack": "Quick Attack",   "attack_effect": "hit"},
    "Seadra":    {"folder": 23, "attack": "Hydro Pump",     "attack_effect": "water"},
    "Magikarp":  {"folder": 24, "attack": "Splash",         "attack_effect": None},     # does no damage

    # ---- Class Raid boss (Mewtwo).  Also kept for the Precalculus 11 game. ----
    # (Math 9 renumbered its folders in Nov 2026: copy this file to the Precalc 11 game
    #  only together with the renamed sprite folders and music files.)
    "Mewtwo": {"folder": 12, "single": (150, 100, 650,  150, 50, -350, 1.0), "moves": [
        ("Aura Sphere",  25,  0, 30, "hit"),
        ("Psychic",      30,  8, 15, "hit"),
        ("Flamethrower", 40, 20,  8, "fire"),
        ("Thunder",      50, 40,  5, "thunder")]},
}

# effect -> (animations, sound file name without .ogg)
# These use only the vfx files you already have:
#   hit = vfx/hit,  firepunch = vfx/firepunch,  hydropump = vfx/water,
#   leaftornado = vfx/leaf_tornado,  thunderbolt = vfx/lightning,  thunder = vfx/green_thunder
# A new move just picks one of these effects; it never needs a new vfx file.
EFFECTS = {
    "hit":     (["hit"],                "hit"),
    "fire":    (["firepunch"],          "firepunch"),
    "water":   (["hydropump"],          "hydropump"),
    "leaf":    (["leaftornado", "hit"], "leaftornado"),
    "bolt":    (["thunderbolt", "hit"], "thunderbolt"),
    "thunder": (["thunder", "hit"],     "thunderbolt"),
}

PLAYER_ATTACK_EFFECT = "bolt"     # the students' attack when they answer correctly
_DEFAULT_MOVES = [("Tackle", 30, 5, 10, "hit")]


def info(name):
    """The entry for a Pokemon (an empty one if the name isn't listed)."""
    return POKEMON.get(name, {"folder": None})


def moves(name):
    return info(name).get("moves") or _DEFAULT_MOVES


def attack_name(name):
    return info(name).get("attack", "Thundershock")
