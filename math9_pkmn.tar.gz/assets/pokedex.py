# ==========================================
# pokedex.py  -  every Pokemon the game can show.  THE file to edit when you add a Pokemon.
#   (No pygame here: plain data, used by single player, Team Battle and Class Raid.)
#
# Sprite files, for folder N:
#   pokemonN/pokemonN_front (1).gif, (2).gif, ...   facing you (opponents)
#   pokemonN/pokemonN_back (1).gif, (2).gif, ...    seen from behind (your own Pokemon)
#   pokemonN/pokemonN_faint.ogg                     faint sound (optional)
# If a Pokemon has only one of front/back, that one is used for both.
# Sprites are sized and placed automatically (the game finds the visible part of the GIF),
# so a new sprite needs no position numbers.  ALL positions, sizes and effect settings live in
# this file (section 2 at the bottom): where each mode puts its Pokemon (SPOTS), how big the
# attack animations are (FX), and per-Pokemon nudges:
#   "scale": 1.2            bigger (0.8 = smaller) in every mode
#   "shift": (0, 20)        moved in every mode: (right, down) in screen pixels
#   "team":  {"scale": 1.1, "shift": (0, 10)}    Team Battle only (on top of the two above)
#   "raid":  {"scale": 0.9, "shift": (20, -10)}  Class Raid only (Mewtwo too: its box gets bigger/smaller)
#   "single": (...)         single player only: exact hand-tuned numbers
#
# To add a Pokemon: copy an entry, change the name, folder and moves. That's it.
#
# Folders (a new Pokemon takes the next free number: 21, 22, ...):
#    0 Pikachu     1 Raichu                                  the students' team
#    2 Venusaur    3 Charizard    4 Blastoise                Kanto starters   (music1-3)
#    5 Sceptile    6 Blaziken     7 Swampert                 Hoenn starters   (music7-9)
#    8 Torterra    9 Infernape   10 Empoleon                 Sinnoh starters  (music4-6)
#   11 Meganium   12 Typhlosion  13 Feraligatr               Johto starters
#   14 Vaporeon   15 Jolteon     16 Flareon                  Eeveelutions
#   17 Eevee      18 Marill      19 Magikarp                 Class Raid (Magikarp = Mr. Chung, watching)
#                                                            (Marill: also Precalc's 4.7 opponent)
#   20 Mewtwo                                                Class Raid boss  (music10-12)
#
# Moves: (name, power, miss %, crit %, effect)
#   effect = the animation and sound: "hit", "fire", "water", "leaf", "bolt", "thunder"
#   Damage = power x attack / 100.  Low power: rarely misses, crits often.
#                                   High power: misses often, rarely crits.
# "attack" = the move name used when a student answers correctly (Pikachu and Raichu).
# Class Raid: every Pokemon with an "attack" (except Mewtwo, the boss, and Magikarp, the teacher's)
#   can be picked by a student (or only the ones in RAID_POOL in online.py).
#   "attack_effect" = its animation in the raid (same names as the moves' effects, or None = nothing).
#   Single player and Team Battle never read "attack_effect", and only use "attack" for Pikachu/Raichu.
# ==========================================

# ==========================================
# 1. EVERY POKEMON
# ==========================================
POKEMON = {
    # ---------- the students' team ----------
    "Pikachu": {"folder": 0, "attack": "Thundershock", "attack_effect": "bolt", "scale": 0.8},     # smaller than Raichu
    "Raichu":  {"folder": 1, "attack": "Thunderbolt", "attack_effect": "bolt",
                "single": (575, 485, 50, 350, 70, 0, 0.75)},                 # original single-player spot

    # ---------- Kanto starters (music1-3) ----------
    # "single" = the original hand-tuned single-player layout:
    #   (HP box x, HP box y, sprite x, sprite y, Thunderbolt x shift, Thunderbolt y shift, sprite scale)
    #   sprite x, y = top-left corner of the GIF;  scale = zoom on the GIF's real size.
    # No "single" = the automatic spot. If a sprite sits in the wrong place, add "scale" or "shift".
    "Venusaur": {"folder": 2, "single": (150, 100, 600,  175, 50, -350, 0.9),
                 "attack": "Solar Beam", "attack_effect": "thunder", "moves": [
        ("Bolt Strike",  30, 10, 10, "thunder"),
        ("Body Slam",    35, 15,  5, "hit"),
        ("Skull Bash",   25,  5, 20, "hit"),
        ("Leaf Tornado", 40, 30,  5, "leaf")]},
    "Charizard": {"folder": 3, "single": (150, 100, 625, -100, 70,    0, 1.0),
                  "raid": {"scale": 1.8, "shift": (0, -50)},   
                  "attack": "Flamethrower", "attack_effect": "fire", "moves": [
        ("Tackle",       25,  0,  0, "hit"),
        ("Iron Tail",    30,  9, 15, "hit"),
        ("Flamethrower", 35, 15,  5, "fire"),
        ("Fire Punch",   30, 12, 10, "fire")]},
    "Blastoise": {"folder": 4, "single": (150, 100, 650,  175, 50, -350, 0.9),
                  "attack": "Hydro Pump", "attack_effect": "water", "moves": [
        ("Tackle",       25,  0,  0, "hit"),
        ("Iron Tail",    30, 10, 15, "hit"),
        ("Skull Bash",   30, 20, 30, "hit"),
        ("Hydro Pump",   35, 30, 10, "water")]},

    # ---------- Hoenn starters (music7-9) ----------
    "Sceptile": {"folder": 5, "single": (150, 100, 650,  165, 50, -350, 1.0),
                 "raid": {"scale": 1.1, "shift": (0, -20)},   
                 "attack": "Leaf Blade", "attack_effect": "hit", "moves": [
        ("Leaf Blade",     35, 15,  5, "leaf"),
        ("Leaf Storm",     40, 30,  5, "leaf"),
        ("Energy Ball",    30, 10, 10, "thunder"),
        ("X-Scissor",      25,  5, 20, "hit")]},
    "Blaziken": {"folder": 6, "single": (150, 100, 650,  150, 70, -350, 1.1),
                 "raid": {"scale": 1.2, "shift": (0, -20)},   
                 "attack": "Blaze Kick", "attack_effect": "fire", "moves": [
        ("Blaze Kick",     35, 15,  5, "fire"),
        ("High Jump Kick", 30, 10, 15, "hit"),
        ("Flamethrower",   35, 15,  5, "fire"),
        ("Brave Bird",     30,  9, 10, "hit")]},
    "Swampert": {"folder": 7, "single": (150, 100, 650,  160, 50, -350, 1.0),
                 "attack": "Muddy Water", "attack_effect": "water", "moves": [
        ("Hydro Pump",     35, 30, 10, "water"),
        ("Muddy Water",    30, 10, 10, "water"),
        ("Quick Attack",   30, 20, 30, "hit"),
        ("Hammer Arm",     25,  0,  0, "hit")]},

    # ---------- Sinnoh starters (music4-6) ----------
    "Torterra": {"folder": 8, "single": (150, 100, 675,  130, 50, -350, 1.1),
                 "raid": {"scale": 1.2, "shift": (0, -20)},   
                 "attack": "Wood Hammer", "attack_effect": "hit", "moves": [
        ("Bite",         20,  0, 30, "hit"),
        ("Body Slam",    30,  8, 12, "hit"),
        ("Earthquake",   40, 25,  5, "hit"),
        ("Leaf Tornado", 45, 35,  5, "leaf")]},
    "Infernape": {"folder": 9, "single": (150, 100, 700,   80, 50, -350, 1.3),
                  "raid": {"scale": 1.5, "shift": (0, -30)},   
                  "attack": "Flare Blitz", "attack_effect": "fire", "moves": [
        ("Iron Tail",    30,  9, 15, "hit"),
        ("Body Slam",    35, 15,  5, "hit"),
        ("Skull Bash",   25,  5, 20, "hit"),
        ("Fire Punch",   30, 12, 10, "fire")]},
    "Empoleon": {"folder": 10, "single": (150, 100, 700,  130, 50, -350, 1.1),
                 "raid": {"scale": 1.3, "shift": (0, -20)},   
                 "attack": "Surf", "attack_effect": "water", "moves": [
        ("Aqua Jet",     20,  0, 30, "water"),
        ("Drill Peck",   30,  8, 15, "hit"),
        ("Flash Cannon", 35, 15,  8, "hit"),
        ("Hydro Pump",   45, 35,  5, "water")]},

    # ---------- Johto starters (new: automatic spots; same move pattern as the others) ----------
    "Meganium": {"folder": 11,
                 "raid": {"scale": 1.3, "shift": (0, -20)},   
                 "attack": "Petal Blizzard", "attack_effect": "leaf", "moves": [
        ("Razor Leaf",     20,  0, 30, "leaf"),
        ("Body Slam",      30,  8, 15, "hit"),
        ("Petal Blizzard", 35, 15,  8, "leaf"),
        ("Solar Beam",     45, 35,  5, "thunder")]},
    "Typhlosion": {"folder": 12, "attack": "Flamethrower", "attack_effect": "fire", "moves": [
        ("Ember",        20,  0, 30, "fire"),
        ("Quick Attack", 30,  8, 15, "hit"),
        ("Flamethrower", 35, 15,  8, "fire"),
        ("Eruption",     45, 35,  5, "fire")]},
    "Feraligatr": {"folder": 13,
                   "raid": {"scale": 1.3, "shift": (0, -20)},   
                   "attack": "Hydro Pump", "attack_effect": "water", "moves": [
        ("Water Gun",    20,  0, 30, "water"),
        ("Crunch",       30,  8, 15, "hit"),
        ("Waterfall",    35, 15,  8, "water"),
        ("Hydro Pump",   45, 35,  5, "water")]},

    # ---------- Eeveelutions (Team Battle uses Vaporeon and Flareon) ----------
    "Vaporeon": {"folder": 14,
                 "raid": {"scale": 1.1, "shift": (0, -10)},   
                 "attack": "Hydro Pump", "attack_effect": "water", "moves": [
        ("Water Gun",    20,  0, 30, "water"),
        ("Bite",         30,  8, 15, "hit"),
        ("Aurora Beam",  35, 15,  8, "hit"),
        ("Hydro Pump",   45, 35,  5, "water")]},
    "Jolteon": {"folder": 15,
                "raid": {"scale": 1.1, "shift": (0, -10)}, 
                "attack": "Thunderbolt", "attack_effect": "bolt", "moves": [
        ("Thundershock", 20,  0, 30, "bolt"),
        ("Double Kick",  30,  8, 15, "hit"),
        ("Pin Missile",  35, 15,  8, "hit"),
        ("Thunder",      45, 35,  5, "thunder")]},
    "Flareon": {"folder": 16, "scale": 1.2,
                "raid": {"scale": 1.3, "shift": (0, -10)}, 
                "attack": "Flamethrower", "attack_effect": "fire", "moves": [  # head size like Vaporeon's
        ("Ember",        20,  0, 30, "fire"),
        ("Quick Attack", 30,  8, 15, "hit"),
        ("Flamethrower", 35, 15,  8, "fire"),
        ("Fire Blast",   45, 35,  5, "fire")]},

    # ---------- Class Raid picks (Marill is also Precalc's 4.7 opponent, so it has moves) ----------
    # If one looks too big or small, add "scale": 0.9 (or 1.1), like Pikachu above.
    "Eevee":    {"folder": 17,
                 "raid": {"scale": 0.8, "shift": (0, 0)},   
                 "attack": "Quick Attack", "attack_effect": "hit"},
    "Marill":   {"folder": 18,
                 "raid": {"scale": 0.9, "shift": (0, 0)}, 
                 "attack": "Bubble Beam",  "attack_effect": "water", "moves": [  # Precalc 4.7
        ("Water Gun",    20,  0, 30, "water"),
        ("Rollout",      30,  8, 15, "hit"),
        ("Bubble Beam",  35, 15,  8, "water"),
        ("Hydro Pump",   45, 35,  5, "water")]},
    "Magikarp": {"folder": 19, "attack": "Splash",       "attack_effect": None},   # Mr. Chung (watches; no damage)

    # ---------- Class Raid boss ----------
    # (Also the Precalculus 11 game's Unit 4 Review opponent.)
    "Mewtwo": {"folder": 20, "single": (150, 100, 650,  150, 50, -350, 1.0), "moves": [
        ("Aura Sphere",  25,  0, 30, "hit"),
        ("Psychic",      30,  8, 15, "hit"),
        ("Flamethrower", 40, 20,  8, "fire"),
        ("Thunder",      50, 40,  5, "thunder")]},
}

# effect -> (animations, sound file name without .ogg)
# These use only the vfx files you already have:
#   hit = vfx/hit,  firepunch = vfx/firepunch,  hydropump = vfx/water,
#   leaftornado = vfx/leaf_tornado,  thunderbolt = vfx/lightning,  thunder = vfx/green_thunder
# A new move just picks one of these effects; it never needs a new vfx file.
EFFECTS = {
    "hit":     (["hit"],                "hit"),
    "fire":    (["firepunch"],          "firepunch"),
    "water":   (["hydropump"],          "hydropump"),
    "leaf":    (["leaftornado", "hit"], "leaftornado"),
    "bolt":    (["thunderbolt", "hit"], "thunderbolt"),
    "thunder": (["thunder", "hit"],     "thunderbolt"),
}

PLAYER_ATTACK_EFFECT = "bolt"     # the students' attack when they answer correctly
_DEFAULT_MOVES = [("Tackle", 30, 5, 10, "hit")]


def info(name):
    """The entry for a Pokemon (an empty one if the name isn't listed)."""
    return POKEMON.get(name, {"folder": None})


def moves(name):
    return info(name).get("moves") or _DEFAULT_MOVES


def attack_name(name):
    return info(name).get("attack", "Thundershock")


# ==========================================
# 2. WHERE POKEMON STAND, AND THE ATTACK ANIMATIONS  (all modes, all in one place)
# ==========================================
# Screen = 1080 x 950 base pixels; the battle area is y = 0 to 720 (the text box is below).
# x goes right, y goes DOWN.
#   anchor = (x, y) of the point under the Pokemon's feet   (bigger y = lower on the screen)
#   scale  = zoom on the GIF's real size (0.6 = 60%)        size = (height, width): fitted into this box
#   box    = (x, y) of the top-left corner of its name / HP box
#   panel  = True: a see-through dark box behind the name and HP
SPOTS = {
    # single player (a Pokemon with "single" numbers uses those instead)
    "single_player": dict(anchor=(250, 715), scale=0.85, box=(575, 485)),
    "single_enemy":  dict(anchor=(820, 420), scale=0.85, box=(150, 100)),
    # Team Battle: your side seen from behind (1st on the left, a bit back), the other side from the front
    "team_mine1": dict(anchor=(140, 650), scale=0.65, box=(774, 520), panel=True),
    "team_mine2": dict(anchor=(435, 685), scale=0.70, box=(774, 614), panel=True),
    "team_foe1":  dict(anchor=(720, 455), scale=0.60, box=(36, 24), panel=True),
    "team_foe2":  dict(anchor=(905, 470), scale=0.70, box=(36, 118), panel=True),
    # Class Raid (Mewtwo's HP is the long bar at the top: BOSS_BAR in battles.py)
    "raid_boss": dict(anchor=(825, 500), size=(330, 330), box=(36, 24), panel=True),
    "raid_me":   dict(anchor=(250, 682), scale=0.62, box=(720, 592), panel=True),
}

# Attack / heal animations played ON a Pokemon, for each place (or mode):
#   scale = size (1.0 = single player's size)     shift = (right, down) in pixels
#   by_effect = one animation only, moved: "hit", "heal", "firepunch" (all fire moves),
#               "hydropump" (water), "thunderbolt" (bolt), "thunder", "leaftornado"
#   (lightning / leaf effects come down onto the feet; the others play on the middle of the Pokemon)
#   Single player's hand-tuned spots ("single" numbers) keep the original fixed effect positions.
FX = {
    "single":    dict(scale=1.0, shift=(0, 0), by_effect={}),
    "team":      dict(scale=0.6, shift=(0, 0), by_effect={}),
    "raid_boss": dict(scale=1.0, shift=(0, 0), by_effect={"firepunch": (0, -50)}),   # on Mewtwo
    "raid_me":   dict(scale=0.8, shift=(0, 0), by_effect={"firepunch": (0, -50)}),   # on your Pokemon
}


def _mode(place):
    return place.split("_")[0]          # "team_foe1" -> "team"


def spot(place, name):
    """The spot for one Pokemon in one place, with its "scale" / "shift" and per-mode nudges applied."""
    base, e = SPOTS[place], info(name)
    m = e.get(_mode(place))
    m = m if isinstance(m, dict) else {}
    k = e.get("scale", 1) * m.get("scale", 1)
    dx = e.get("shift", (0, 0))[0] + m.get("shift", (0, 0))[0]
    dy = e.get("shift", (0, 0))[1] + m.get("shift", (0, 0))[1]
    out = dict(base, anchor=(base["anchor"][0] + dx, base["anchor"][1] + dy))
    if "scale" in out:
        out["scale"] = out["scale"] * k
    if "size" in out:
        out["size"] = (int(out["size"][0] * k), int(out["size"][1] * k))
    return out


def fx(place):
    """Animation settings for a place ("raid_boss"), else its mode ("team"), else single player's."""
    return FX.get(place) or FX.get(_mode(place)) or FX["single"]
