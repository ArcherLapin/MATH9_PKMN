# ==========================================
# q_similarity.py  -  Math 9 questions: Similarity & Scale (Week 12)
#   (No pygame here: question making only.  main.py shows them; Team Battle and Class Raid use them too.)
#
#   n = 1  Proportions & Similar Figures   W12L1  DeltaMath: Simple Proportions; Identify Corresponding
#                                                 Parts of Similar Figures (point, angle, side)
#   n = 2  Scale Factor                    W12L2  DeltaMath: Find the Scale Factor (fractions like 5/2);
#                                                 Similar Figures / Direct Scale (Level 1)
#   n = 3  Similar Triangles               W12L3  DeltaMath: Solve for Side or Perimeter, Similar Triangles;
#                                                 Similar Figures / Proportion (Level 1); Word Problems,
#                                                 Similar Triangles (Shadow type only, no Mirror)
#   n = 4  Scale Diagrams                  W12L4  DeltaMath: Scale Word Problems (L1) (Park perimeter / area,
#                                                 cm and m); Create Scaled Drawings on a Grid (Level 1)
#
#   Same question forms as the W12 worksheets and their back sides (Stepping Stones, Shape Factory,
#   Crossnumber, Camp Map), and the same mistakes as their Check Your Thinking boxes:
#     Kim multiplies the wrong pair (4 x 6 = 9x),  Lee does original / copy,  Ivy adds 3 cm to each side,
#     the flipped ratio (8/12 = DE/10),  Nia multiplies the drawing's area by the scale only once.
#   Scale factor:  k = copy / original  (DeltaMath: original = pre-image, copy = image), written as a
#   fraction in lowest terms (5/2), like DeltaMath's answers.
#   Order matters (worksheet W12L1): ABC ~ DEF means A <-> D, B <-> E, C <-> F, so side BA matches ED,
#   never DE.  Sides are asked both ways (AB and BA), ~ statements are sometimes written from another
#   vertex (BCA ~ EFD), and the same letters in the wrong order is always one of the wrong answers.
#
#   Every question fits ONE line in the text box.  Anything longer (a story, a student's work, a list
#   of rectangles) is in the yellow Show Info panel; pictures are in Show Diagram.
#   Pictures (drawn by main_tool.py, section 8):
#     "figs":   similar figures side by side, with vertex names, side lengths and angles (x in red)
#     "sqgrid": shapes and points on a square grid (scaled copies, the camp map)
#   Plain ASCII only (pygbag): "~" for "is similar to", "<->" for "matches", no degree sign in text
#   (the diagrams draw their own small degree circle).  Answers are whole numbers or end in .5
#   (scale diagrams: one decimal), except scale factors (fractions).
#
#   make_question(n) -> (text, correct, [5 choices], visual or None)
# ==========================================
import itertools
import math
import random
from fractions import Fraction as F

from q_tools import build, build_num, two_way, fnum, nice, info, as_units, Picker, NAMES


# ==========================================
# 0. SMALL HELPERS
# ==========================================
def frac(v):
    """5/2 -> '5/2',  3 -> '3'."""
    v = F(v)
    return str(v.numerator) if v.denominator == 1 else f"{v.numerator}/{v.denominator}"


def as_frac(vals):
    return [frac(v) for v in vals]


CM, M, KM = as_units("cm"), as_units("m"), as_units("km")
SQ = as_units("squares")
M2 = as_units("m^2")                     # main_tool draws ^2 as a small raised 2


def a_(v):
    """'a' or 'an' before a number: an 8 cm side, an 11 cm side, a 12 cm side."""
    s = fnum(v)
    return "an" if s.startswith("8") or s.split(".")[0] in ("11", "18") else "a"


def half(v):
    """A length students can write: a whole number or .5, and more than 0."""
    return v > 0 and nice(v, 2)


def tenth(v):
    return v > 0 and nice(v, 10)


# Scale factors used everywhere: whole numbers, simple fractions, both enlargements and reductions.
KS = [F(2), F(3), F(4), F(1, 2), F(1, 3), F(1, 4), F(3, 2), F(5, 2), F(2, 3), F(3, 4),
      F(4, 3), F(5, 3), F(2, 5), F(3, 5), F(5, 4), F(4, 5)]


def pick_k(simple=False):
    return random.choice(KS[:8] if simple else KS)


# Letters for two similar figures (never shared between the two, no I or O).
LETTERS3 = ["ABC", "DEF", "JKL", "MNP", "PQR", "STU", "XYZ", "RST", "UVW", "GHK"]
LETTERS4 = ["ABCD", "EFGH", "PQRS", "WXYZ", "JKLM", "STUV"]
LETTERS5 = ["ABCDE", "PQRST", "FGHJK", "VWXYZ", "JKLMN"]


def letter_pair(n):
    pool = {3: LETTERS3, 4: LETTERS4, 5: LETTERS5}[n]
    while True:
        a, b = random.sample(pool, 2)
        if not set(a) & set(b):
            return a, b


def dihedral(n):
    """A matching that keeps the order around the figure: vertex i <-> (s + e*i) mod n."""
    s, e = random.randrange(n), random.choice([1, -1])
    return [(s + e * i) % n for i in range(n)]


def all_dihedral(n):
    return [[(s + e * i) % n for i in range(n)] for s in range(n) for e in (1, -1)]


# ---- ORDER MATTERS.  ABC ~ DEF means A <-> D, B <-> E, C <-> F, so BA <-> ED (never DE).
#      Every side is named in the matching order: the letters of the answer follow the letters asked.
def say_order(n, plain=0.5):
    """The order to write a ~ statement in.  Half the time A, B, C...; otherwise another start
    (and direction): any order for a triangle, around the figure for 4 or 5 sides (BCA ~ EFD, CBAD ~ ...)."""
    if random.random() < plain:
        return list(range(n))
    return random.sample(range(n), n) if n == 3 else dihedral(n)


def renamed(L, q):
    """The figure's letters in the order q:  renamed('ABC', [1, 2, 0]) = 'BCA'."""
    return "".join(L[i] for i in q)


def matches(L1, names2, a, b):
    """True if b is a's matching part (same letters IN THE SAME ORDER): with ABC ~ DEF, BA -> ED."""
    return len(a) == len(b) and all(c in L1 and names2[L1.index(c)] == d for c, d in zip(a, b))


# ==========================================
# 1. SHAPES FOR THE DIAGRAMS
# ==========================================
def tri_from_sides(a, b, c):
    """Triangle ABC with BC = a, CA = b, AB = c:  A at (0, 0), B on the x-axis, C above."""
    x = (b * b + c * c - a * a) / (2 * c)
    y = math.sqrt(max(b * b - x * x, 0.0))
    return [(0.0, 0.0), (float(c), 0.0), (x, y)]


def angles_of(a, b, c):
    A = math.degrees(math.acos((b * b + c * c - a * a) / (2 * b * c)))
    B = math.degrees(math.acos((a * a + c * c - b * b) / (2 * a * c)))
    return A, B, 180 - A - B


def rand_triangle(lo=4, hi=15):
    """Whole-number sides (opposite A, B, C) and whole-number angles that add to 180,
    all at least 25 degrees and at least 7 apart (so matching by angles is clear)."""
    for _ in range(1000):
        s = random.sample(range(lo, hi + 1), 3)
        a, b, c = s
        if max(s) >= sum(s) - max(s) - 1:
            continue
        A, B, C = angles_of(a, b, c)
        ra, rb = round(A), round(B)
        angs = [ra, rb, 180 - ra - rb]
        if min(angs) < 25 or min(abs(x - y) for x, y in itertools.combinations(angs, 2)) < 7:
            continue
        return [a, b, c], angs
    raise RuntimeError("no triangle")


def side_between(i, j):
    """Triangle: the side between vertices i and j is opposite vertex 3 - i - j."""
    return 3 - i - j


def place(pts, k=1.0, turn=None, flip=None):
    """The copy: flipped (sometimes), turned and scaled.  Same vertex order as pts."""
    turn = random.uniform(0, 360) if turn is None else turn
    flip = random.random() < 0.5 if flip is None else flip
    c, s = math.cos(math.radians(turn)), math.sin(math.radians(turn))
    out = []
    for x, y in pts:
        if flip:
            x = -x
        out.append((k * (x * c - y * s), k * (x * s + y * c)))
    return out


def fig(pts, names, sides=None, angles=None, title=""):
    """One figure for the "figs" picture.  sides[i] labels pts[i] -> pts[i+1]; angles[i] sits at pts[i]."""
    n = len(pts)
    return {"pts": [(round(x, 3), round(y, 3)) for x, y in pts], "names": list(names),
            "sides": [str(v) for v in (sides or [""] * n)], "angles": list(angles or [""] * n), "title": title}


def tri_sides_labels(lengths, show):
    """Side labels in fig() order (AB, BC, CA) from lengths opposite (A, B, C).  show = {opp vertex: text}."""
    order = [2, 0, 1]                    # AB is opposite C, BC opposite A, CA opposite B
    return [show.get(o, "") for o in order]


# ==========================================
# 2. TOPIC 1 - Proportions & Similar Figures  (W12L1)
# ==========================================
def t1_solve():                                      # Simple Proportions (Stepping Stones)
    while True:
        p, q = random.randint(1, 12), random.randint(2, 12)
        if p != q and math.gcd(p, q) == 1:
            break
    m1, m2 = random.sample(range(1, 7), 2)
    vals = [p * m1, q * m1, p * m2, q * m2]
    if random.random() < 0.5:                        # either fraction can come first
        vals = vals[2:] + vals[:2]
    i = random.randrange(4)
    if i in (0, 2) and random.random() < 0.3:        # a negative, like the worksheet's -7/4 = x/8
        vals[0], vals[2] = -vals[0], -vals[2]
    ans = vals[i]
    shown = ["x" if k == i else fnum(v) for k, v in enumerate(vals)]
    o = [v for k, v in enumerate(vals) if k != i]
    traps = [F(o[0] * o[1], o[2]), F(o[0] * o[2], o[1]), F(o[1] * o[2], o[0])]    # Kim: the wrong pair
    j = i ^ 2                                        # same spot in the other fraction
    traps.append(vals[i ^ 1] + (vals[j] - vals[j ^ 1]))                          # same difference (adding)
    traps.append(-ans)
    traps = [F(round(float(t) * 10), 10) for t in traps]                          # rounded like Kim's 2.7
    return build_num(f"Solve:   {shown[0]}/{shown[1]} = {shown[2]}/{shown[3]}", ans, traps,
                     ok=lambda v: v != 0 and nice(v, 10) and abs(v) <= 300)


PHOTO = [("photo", "wide", "tall"), ("poster", "wide", "tall"), ("painting", "wide", "tall"),
         ("flag", "long", "wide"), ("logo", "wide", "tall"), ("screen image", "wide", "tall")]


def t1_word():                                       # worksheet Your Turn 3 (photo enlargement)
    item, w1, w2 = random.choice(PHOTO)
    for _ in range(200):
        a, b = random.sample(range(4, 25), 2)
        k = pick_k()
        A, B = a * k, b * k
        if half(A) and half(B) and A <= 80 and B <= 80 and A != b and B != a:
            break
    else:
        return None
    word = "larger" if k > 1 else "smaller"
    story = f"A {item} is {a} cm {w1} and {b} cm {w2}. A {word} copy of it is {fnum(A)} cm {w1}."
    traps = [b + (A - a), F(a * A, b), F(a * b, A), A, b + A]
    return build_num(f"How {w2} is the copy?", B, traps, fmt=CM, ok=half, visual=info(story))


def _not_same_order(n):
    """A matching that keeps the order around the figure, but not simply A->D, B->E, C->F."""
    while True:
        p = dihedral(n) if n > 3 else random.sample(range(3), 3)
        if p != list(range(n)):
            return p


def t1_pair():                                       # Identify Corresponding Parts (a ~ statement)
    n = random.choice([3, 3, 4])
    L1, L2 = letter_pair(n)
    p = _not_same_order(n)
    names2 = [L2[p[i]] for i in range(n)]            # names2[i] matches L1[i]
    q = say_order(n)
    st = f"{renamed(L1, q)} ~ {renamed(names2, q)}."
    kind = random.choice(["angle", "side", "side", "point"])
    if kind in ("point", "angle"):
        pre = "Point " if kind == "point" else "angle "
        i = random.randrange(n)
        pair = lambda a, b: f"{pre}{a} <-> {pre}{b}"
        right = pair(L1[i], names2[i])
        traps = [pair(L1[i], L2[i])] if L2[i] != names2[i] else []       # matched by alphabet order
        traps += [pair(L1[i], c) for c in L2 if c not in (names2[i], L2[i])]
        traps += [pair(L1[j], c) for j in range(n) if j != i for c in L2 if c != names2[j]]
    else:
        ends = [(0, 1), (1, 2), (0, 2)] if n == 3 else [(i, (i + 1) % n) for i in range(n)]
        sides = [tuple(random.sample(e, 2)) for e in ends]               # each side written AB or BA
        one = lambda s: L1[s[0]] + L1[s[1]]
        two = lambda s: names2[s[0]] + names2[s[1]]                     # in matching order
        pair = lambda a, b: f"{a} <-> {b}"
        s = random.choice(sides)
        right = pair(one(s), two(s))
        others = [t for t in sides if t != s]
        traps = [pair(one(s), two(s)[::-1]),                            # right letters, wrong order
                 pair(one(s), L2[s[0]] + L2[s[1]])]                     # matched by alphabet order
        traps += [pair(one(s), two(t)) for t in others] + [pair(one(s), two(t)[::-1]) for t in others]
        traps += [pair(one(t), two(t)[::-1]) for t in others]           # another side, letters flipped
        traps += [pair(one(t), two(u)) for t in others for u in sides if u != t]
    traps = [t for t in traps if not matches(L1, names2, *(x.split()[-1] for x in t.split(" <-> ")))]
    return build(f"{st}   Which pair matches?", right, traps[:3], extra=traps[3:])


def t1_pentagon():                                   # Identify Corresponding Parts (point, angle, side)
    L1, L2 = letter_pair(5)
    p = _not_same_order(5)
    names2 = [L2[p[i]] for i in range(5)]
    q = say_order(5)
    st = f"{renamed(L1, q)} ~ {renamed(names2, q)}."
    i = random.randrange(5)
    kind = random.choice(["point", "angle", "side", "side"])
    if kind in ("point", "angle"):
        pre = "Point " if kind == "point" else "angle "
        right = pre + names2[i]
        traps = [pre + L2[i]] + [pre + c for c in L2 if c not in (names2[i], L2[i])]
        return build(f"{st}   {pre}{L1[i]} matches which?", right, traps)
    j = (i + random.choice([1, -1])) % 5             # the side asked is L1[i] L1[j], in that order (AB or BA)
    right = names2[i] + names2[j]                    # same order: AB -> its match, BA -> the reverse
    alpha = L2[i] + L2[j]                            # matched by alphabet order
    sides2 = [L2[k] + L2[(k + 1) % 5] for k in range(5)]
    traps = [right[::-1], alpha, alpha[::-1]] + sides2 + [s[::-1] for s in sides2]
    traps = [t for t in traps if not matches(L1, names2, L1[i] + L1[j], t)]
    return build(f"{st}   Side {L1[i]}{L1[j]} matches which side?", right, traps[:3], extra=traps[3:])


def t1_tri_complete():                               # worksheet Guided 2: match by angles, write the ~ statement
    L1, L2 = letter_pair(3)
    sides, angs = rand_triangle()
    pts = tri_from_sides(*sides)
    p = random.sample(range(3), 3)
    names2 = [L2[p[i]] for i in range(3)]
    show = random.sample(range(3), 2)
    a_shown = [angs[i] if i in show else "" for i in range(3)]
    k = random.choice([0.6, 0.7, 1.4, 1.6, 1.8])
    vis = {"figs": [fig(pts, L1, angles=a_shown), fig(place(pts, k), names2, angles=a_shown)]}
    q = say_order(3)                                 # sometimes  BCA ~ ___  (the answer follows that order)
    left, right = renamed(L1, q), renamed(names2, q)
    perms = ["".join(t) for t in itertools.permutations(L2)]
    traps = ["".join(names2), L2] + [t for t in perms if t not in (right, L2)]   # A-B-C order / alphabet
    return build(f"The triangles are similar. Complete:   {left} ~ ___", right, traps, vis)


def rand_quad():
    """A convex quadrilateral with 4 different whole-number side labels (about to scale)."""
    for _ in range(1000):
        cuts = sorted(random.uniform(0, 360) for _ in range(4))
        gaps = [(cuts[(i + 1) % 4] - cuts[i]) % 360 for i in range(4)]
        if min(gaps) < 45:
            continue
        pts = []
        for t in cuts:
            r = random.uniform(2.5, 5)
            pts.append((r * math.cos(math.radians(t)), r * math.sin(math.radians(t))))
        convex = True
        for i in range(4):
            (x1, y1), (x2, y2), (x3, y3) = pts[i], pts[(i + 1) % 4], pts[(i + 2) % 4]
            if (x2 - x1) * (y3 - y2) - (y2 - y1) * (x3 - x2) <= 0.3:
                convex = False
        if not convex:
            continue
        L = [math.dist(pts[i], pts[(i + 1) % 4]) for i in range(4)]
        sc = random.uniform(7, 10) / max(L)
        pts = [(x * sc, y * sc) for x, y in pts]
        labels = [round(l * sc) for l in L]
        if len(set(labels)) == 4 and min(labels) >= 2:
            return pts, labels
    raise RuntimeError("no quadrilateral")


def t1_quad_complete():                              # worksheet Guided 2: the copy has been turned
    L1, L2 = letter_pair(4)
    pts, labels = rand_quad()
    p = dihedral(4)
    names2 = [L2[p[i]] for i in range(4)]
    k = random.choice([F(2), F(3), F(3, 2)])
    copy_labels = [fnum(l * k) for l in labels]
    vis = {"figs": [fig(pts, L1, sides=labels), fig(place(pts, float(k)), names2, sides=copy_labels)]}
    q = say_order(4)                                 # sometimes  CBAD ~ ___  (the answer follows that order)
    left, right = renamed(L1, q), renamed(names2, q)
    opts = [renamed(L2, t) for t in all_dihedral(4)]
    traps = ["".join(names2), L2] + [o for o in opts if o != right]          # A-B-C-D order / alphabet
    return build(f"The figures are similar. Complete:   {left} ~ ___", right, traps, vis)


# ==========================================
# 3. TOPIC 2 - Scale Factor  (W12L2)
# ==========================================
def _side_pair(simple=False, top=40):
    for _ in range(300):
        k = pick_k(simple)
        o = k.denominator * random.randint(1, 12)
        c = o * k
        if 2 <= o <= top and 2 <= c <= top and o != c:
            return o, c, k
    return None


def _k_traps(o, c, k):
    traps = [1 / k, F(abs(c - o))]
    n, d = k.numerator, k.denominator
    for nn, dd in ((n + 1, d), (n, d + 1), (n - 1, d), (n, d - 1), (d, n + 1), (n + 1, d + 1)):
        if nn > 0 and dd > 0 and F(nn, dd) != k:
            traps.append(F(nn, dd))
    return traps


def t2_find_k():                                     # Find the Scale Factor (answers as fractions)
    o, c, k = _side_pair()
    return build_num(f"{a_(o).capitalize()} {o} cm side is copied as {fnum(c)} cm. Find the scale factor k.", k,
                     _k_traps(o, c, k),
                     fmt=as_frac, ok=lambda v: v > 0 and v.denominator <= 12 and v.numerator <= 40, extra=[])


def t2_type():                                       # k, and enlargement or reduction (Lee's mistake)
    o, c, k = _side_pair()
    w0, w1 = ("enlargement", "reduction") if k > 1 else ("reduction", "enlargement")
    alts = [1 / k] + [t for t in _k_traps(o, c, k)[2:] if t.denominator <= 12 and t != 1]
    return two_way("Find k. Enlargement or reduction?", lambda a, w: f"k = {frac(a)}, {w}", k, w0, alts, w1,
                   info(f"{a_(o).capitalize()} {o} cm side of a figure is copied as {fnum(c)} cm."))


def t2_copy():                                       # Copy = original x k  (Complete the table)
    for _ in range(200):
        k = pick_k()
        o = k.denominator * random.randint(1, 10)
        if o >= 3 and k != 1:
            break
    c = o * k
    traps = [F(o, k), o * k.numerator, F(o, k.denominator), o + k.numerator - k.denominator, o + c]
    return build_num(f"An original side is {o} cm and k = {frac(k)}. Find the copy's side.", c, traps,
                     fmt=CM, ok=half)


def t2_original():                                   # Original = copy / k
    for _ in range(200):
        k = pick_k()
        o = k.denominator * random.randint(1, 10)
        c = o * k
        if o >= 3 and half(c):
            break
    traps = [c * k, F(c, k.numerator), c * k.denominator, c - (k.numerator - k.denominator), c + o]
    return build_num(f"A copy's side is {fnum(c)} cm and k = {frac(k)}. Find the original side.", o, traps,
                     fmt=CM, ok=half)


def _rect_or_tri():
    shape = random.choice(["rect", "rect", "tri"])
    for _ in range(300):
        w, h = random.sample(range(3, 15), 2)
        k = pick_k(simple=random.random() < 0.5)
        W, H = w * k, h * k
        if half(W) and half(H) and W <= 40 and H <= 40 and W != w and H != h and W != h and H != w:
            break
    else:
        return None
    if shape == "rect":
        pts = lambda a, b: [(0, 0), (a, 0), (a, b), (0, b)]
        lab = lambda a, b: [a, b, "", ""]             # bottom, right
    else:
        pts = lambda a, b: [(0, 0), (a, 0), (0, b)]
        lab = lambda a, b: [a, "", b]                 # bottom, left
    return shape, pts, lab, w, h, W, H, k


def t2_diagram():                                    # Similar Figures / Direct Scale (Level 1)
    made = _rect_or_tri()
    if made is None:
        return None
    shape, pts, lab, w, h, W, H, k = made
    sc = 1 / max(w, h)                                # drawn to scale, the copy k times as big
    o_pts = [(x * sc, y * sc) for x, y in pts(w, h)]
    c_pts = [(x * sc * float(k), y * sc * float(k)) for x, y in pts(w, h)]
    kind = random.choice(["copy", "copy", "orig", "k"])
    if kind == "k":
        vis = {"notes": ["Lengths in cm."], "figs": [fig(o_pts, "", sides=lab(w, h), title="Original"),
                                                     fig(c_pts, "", sides=lab(fnum(W), fnum(H)), title="Copy")]}
        return build_num("The copy is similar to the original. Find the scale factor k.", k,
                         _k_traps(w, W, k), fmt=as_frac, ok=lambda v: v > 0 and v.denominator <= 12, visual=vis,
                         extra=[])
    if kind == "copy":
        vis = {"notes": ["Lengths in cm."], "figs": [fig(o_pts, "", sides=lab(w, h), title="Original"),
                                                     fig(c_pts, "", sides=lab(fnum(W), "x"), title="Copy")]}
        traps = [h + (W - w), F(h * w, W), F(W * w, h), h * W, W]
        return build_num("The copy is similar to the original. Find x.", H, traps, fmt=CM, ok=half, visual=vis)
    vis = {"notes": ["Lengths in cm."], "figs": [fig(o_pts, "", sides=lab(w, "x"), title="Original"),
                                                 fig(c_pts, "", sides=lab(fnum(W), fnum(H)), title="Copy")]}
    traps = [H - (W - w), H * k, F(W * H, w), H, F(H, 2)]
    return build_num("The copy is similar to the original. Find x.", h, traps, fmt=CM, ok=half, visual=vis)


def t2_which_similar():                              # worksheet Your Turn 3 (Rectangle A, B, C)
    for _ in range(300):
        w, h = sorted(random.sample(range(2, 13), 2))
        k = random.choice([F(3, 2), F(2), F(5, 2), F(3), F(1, 2), F(4, 3)])
        W, H = w * k, h * k
        if W.denominator == 1 and H.denominator == 1 and W != w:
            break
    else:
        return None
    t = random.choice([1, 2, 3, 4])
    wrong = [(w + t, h + t), (W, H + 1), (W + 1, H), (w * 2, h * 3), (W, H - 1), (h, w + h), (W + 2, H + 2)]
    wrong = [(a, b) for a, b in wrong if a > 0 and b > 0 and F(a, b) != F(w, h)]
    wrong = list(dict.fromkeys(wrong))
    random.shuffle(wrong)
    none = random.random() < 0.15
    rects = wrong[:4] if none else [(W, H)] + wrong[:3]
    if len(rects) < 4:
        return None
    random.shuffle(rects)
    names = ["A", "B", "C", "D"]
    notes = [f"Rectangle R:  {w} cm by {h} cm", ""] + \
            [f"Rectangle {n}:  {fnum(a)} cm by {fnum(b)} cm" for n, (a, b) in zip(names, rects)]
    right = "None of them" if none else f"Rectangle {names[rects.index((W, H))]}"
    opts = [f"Rectangle {n}" for n in names] + ["None of them"]
    return build("Which rectangle is similar to rectangle R?", right, [o for o in opts if o != right],
                 {"notes": notes})


def eq_(v, top, bottom):
    """' = 2/5' after 'k = 8/20', or nothing when top/bottom is already in lowest terms."""
    return "" if F(v) == F(top, bottom) and frac(v) == f"{fnum(top)}/{fnum(bottom)}" else f" = {frac(v)}"


def t2_mistake():                                    # Check Your Thinking (Lee) + Think It Through (Ivy)
    who = random.choice(NAMES)
    kind = random.choice(["flip", "flip", "add", "ok"])
    if kind == "add":
        w, h = random.sample(range(2, 10), 2)
        t = random.randint(1, 5)
        story = f"{who} wants a bigger copy of {a_(w)} {w} cm by {h} cm rectangle, so {who} adds {t} cm to each side."
        right = f"No: {w + t}/{w} and {h + t}/{h} are not equal"
        traps = [f"Yes: every side grew by {t} cm", "Yes: it is still a rectangle", f"Yes: k = {t}",
                 "No: a copy must be smaller", f"No: k must be {t}/{w + t}"]
        return build("Is the copy similar? Why?", right, traps, info(story))
    o, c, k = _side_pair(top=30)
    if kind == "flip":
        wk = F(o, c)
        wt = "enlargement" if wk > 1 else "reduction"
        story = f"{a_(o).capitalize()} {o} cm side is copied as {fnum(c)} cm.  {who} writes:  k = {o}/{fnum(c)}{eq_(wk, o, c)}, so {wt}."
        right = "Used original / copy"
    else:
        wt = "enlargement" if k > 1 else "reduction"
        story = f"{a_(o).capitalize()} {o} cm side is copied as {fnum(c)} cm.  {who} writes:  k = {fnum(c)}/{o}{eq_(k, c, o)}, so {wt}."
        right = "Nothing: the work is correct"
    traps = ["Used original / copy", "Nothing: the work is correct",
             "Should subtract the sides", "k must be a whole number",
             "Should add the sides"]
    return build("What went wrong?", right, [t for t in traps if t != right], info(story))


# ==========================================
# 4. TOPIC 3 - Similar Triangles  (W12L3)
# ==========================================
def _tri_pair():
    """Two similar triangles: whole-number sides, a nice k, the copy turned (and maybe flipped)."""
    for _ in range(300):
        sides, angs = rand_triangle(4, 14)
        k = random.choice([F(2), F(3), F(1, 2), F(3, 2), F(5, 2), F(2, 3), F(4, 3), F(3, 4)])
        copy = [s * k for s in sides]
        if all(half(c) and c <= 40 for c in copy):
            return sides, angs, k, copy
    return None


def _tri_figs(L1, names2, sides, angs, k, o_show, c_show, need_third):
    """o_show / c_show: {opposite vertex: label}.  need_third: the copy shows a different pair of angles."""
    pts = tri_from_sides(*sides)
    oa = random.sample(range(3), 2)
    ca = oa if not need_third else [oa[0], 3 - oa[0] - oa[1]]
    o_ang = [angs[i] if i in oa else "" for i in range(3)]
    c_ang = [angs[i] if i in ca else "" for i in range(3)]
    return {"figs": [fig(pts, L1, sides=tri_sides_labels(sides, o_show), angles=o_ang),
                     fig(place(pts, float(k)), names2, sides=tri_sides_labels(sides, c_show), angles=c_ang)]}


def t3_diagram():                                    # Solve for Side, Similar Triangles (match by angles)
    made = _tri_pair()
    if made is None:
        return None
    sides, angs, k, copy = made
    L1, L2 = letter_pair(3)
    p = random.sample(range(3), 3)
    names2 = [L2[p[i]] for i in range(3)]
    g, t = random.sample(range(3), 2)                # g: the known matching pair, t: the side to find
    other = 3 - g - t
    if random.random() < 0.7:                        # x on the copy
        ans = copy[t]
        o_show, c_show = {g: sides[g], t: sides[t]}, {g: fnum(copy[g]), t: "x"}
        traps = [F(sides[t] * sides[g], copy[g]), sides[t] + (copy[g] - sides[g]), sides[other] * k,
                 F(copy[g] * sides[g], sides[t]), copy[g]]
    else:                                            # x on the original
        ans = sides[t]
        o_show, c_show = {g: sides[g], t: "x"}, {g: fnum(copy[g]), t: fnum(copy[t])}
        traps = [copy[t] * k, copy[t] - (copy[g] - sides[g]), F(copy[other], k), F(copy[t] * copy[g], sides[g]),
                 sides[g]]
    vis = _tri_figs(L1, names2, sides, angs, k, o_show, c_show, random.random() < 0.4)
    return build_num("The triangles are similar. Find x.", ans, traps, ok=half, visual=vis)


def t3_perimeter():                                  # Solve for ... Perimeter, Similar Triangles
    made = _tri_pair()
    if made is None:
        return None
    sides, angs, k, copy = made
    L1, L2 = letter_pair(3)
    p = random.sample(range(3), 3)
    names2 = [L2[p[i]] for i in range(3)]
    g = random.randrange(3)
    P, Pc = sum(sides), sum(copy)
    vis = _tri_figs(L1, names2, sides, angs, k, {i: sides[i] for i in range(3)}, {g: fnum(copy[g])},
                    random.random() < 0.4)
    traps = [P, P + 3 * (copy[g] - sides[g]), F(P, k), sum(sides) - sides[g] + copy[g], Pc + copy[g]]
    return build_num(f"The triangles are similar. Find the perimeter of {''.join(sorted(names2))}.", Pc, traps,
                     ok=half, visual=vis)


def t3_statement():                                  # Similar Figures / Proportion (Level 1): no diagram
    n = random.choice([3, 3, 4])
    L1, L2 = letter_pair(n)
    if n == 3:
        p = random.sample(range(3), 3)
        sides, _ = rand_triangle(3, 15)
        sides = {(0, 1): sides[2], (1, 2): sides[0], (0, 2): sides[1]}
    else:
        p = dihedral(4)
        _, labels = rand_quad()
        sides = {(i, (i + 1) % 4): labels[i] for i in range(4)}
    names2 = [L2[p[i]] for i in range(n)]
    k = random.choice([F(2), F(3), F(3, 2), F(5, 2), F(1, 2), F(4, 3), F(2, 3), F(5, 4)])
    if not all(half(v * k) for v in sides.values()):
        return None
    (e1, s1), (e2, s2) = random.sample(list(sides.items()), 2)
    (a, b), (c, d) = random.sample(e1, 2), random.sample(e2, 2)     # each side written AB or BA
    nm = lambda i, j, L: L[i] + L[j]                 # matching sides keep the same order: BA <-> ED
    given = f"{nm(a, b, L1)} = {s1},  {nm(c, d, L1)} = {s2},  {nm(a, b, names2)} = {fnum(s1 * k)}"
    ans = s2 * k
    traps = [F(s2, k), s2 + (s1 * k - s1), F(s1 * s1 * k, s2), s1 * k, s2, ans + s1]
    q = say_order(n)
    return build_num(f"{renamed(L1, q)} ~ {renamed(names2, q)}.  {given}.  Find {nm(c, d, names2)}.", ans,
                     traps, ok=half)


def t3_angles():                                     # Crossnumber 1 Down: match by angles in words
    made = _tri_pair()
    if made is None:
        return None
    sides, angs, k, copy = made
    L1, L2 = letter_pair(3)
    p = random.sample(range(3), 3)
    names2 = [L2[p[i]] for i in range(3)]
    ang2 = {names2[i]: angs[i] for i in range(3)}        # the copy's angles by its own letters
    oa = random.sample(range(3), 2)
    ca = random.sample(L2, 2)
    g, t = random.sample(range(3), 2)
    vg = [v for v in range(3) if v != g]                 # the side opposite g joins the other two vertices
    vt = [v for v in range(3) if v != t]
    side = lambda L, v: L[v[0]] + L[v[1]]
    notes = [f"Triangle {L1}:  angle {L1[oa[0]]} = {angs[oa[0]]} degrees,  angle {L1[oa[1]]} = {angs[oa[1]]} degrees",
             f"Triangle {L2}:  angle {ca[0]} = {ang2[ca[0]]} degrees,  angle {ca[1]} = {ang2[ca[1]]} degrees",
             f"{side(L1, vg)} = {sides[g]},   {side(L1, vt)} = {sides[t]},   "
             f"{side(names2, vg)} = {fnum(copy[g])}"]
    other = 3 - g - t
    traps = [F(sides[t] * sides[g], copy[g]), sides[other] * k, sides[t] + (copy[g] - sides[g]), copy[g],
             F(copy[g] * sides[g], sides[t])]
    target = "".join(sorted(side(names2, vt), key=L2.index))
    return build_num(f"The triangles are similar. Find {target}.", copy[t], traps, ok=half, visual={"notes": notes})


SHADOW_THINGS = ["tree", "flagpole", "lamppost", "building", "totem pole", "cell tower"]


def t3_shadow():                                     # Word Problems, Similar Triangles (Shadow type)
    thing = random.choice(SHADOW_THINGS)
    who = random.choice(NAMES)
    if random.random() < 0.6:                        # two separate shadows (Crossnumber 3 Across)
        for _ in range(300):
            h = random.choice([150, 160, 170, 180, 120, 140])
            s = random.choice([60, 80, 90, 100, 120, 150, 200, 240])
            S = s * random.choice([2, 3, 4, 5, 6, 8, F(5, 2), F(7, 2), F(9, 2)])
            H = F(h * S, s)
            if H.denominator == 1 and S.denominator == 1 and H <= 3000:
                break
        else:
            return None
        story = (f"{who} is {h} cm tall and casts a {s} cm shadow. At the same time, "
                 f"a {thing} casts a {fnum(S)} cm shadow.")
        traps = [F(s * S, h), h + (S - s), S, F(h * s, S), H + h]
        return build_num(f"How tall is the {thing}, in cm?", H, traps, fmt=CM, ok=lambda v: v > 0 and nice(v, 2),
                         visual=info(story))
    for _ in range(300):                             # standing in its shadow (worksheet Your Turn 3)
        h = random.choice([F(3, 2), F(8, 5), F(17, 10), F(9, 5), F(6, 5)])
        own = random.choice([1, 2, 3, 4])
        d = random.choice([4, 5, 6, 8, 9, 10, 12, 14])
        T = own + d
        H = h * T / own
        if nice(H, 10) and H <= 40:
            break
    else:
        return None
    story = (f"{who} ({fnum(h)} m tall) stands {d} m from a {thing}, in its shadow, so the tips of their shadows "
             f"meet. The tips are {T} m from the {thing}.")
    traps = [h * T / d, h * d / own, h * d, h + T - own, h * T]
    return build_num(f"How tall is the {thing}?", H, traps, fmt=M, ok=lambda v: v > 0 and nice(v, 100) and v < 200,
                     visual=info(story))


def t3_mistake():                                    # Check Your Thinking: the flipped ratio
    L1, L2 = letter_pair(3)
    p = random.sample(range(3), 3)
    names2 = [L2[p[i]] for i in range(3)]
    for _ in range(100):
        a, b = random.sample(range(4, 16), 2)
        k = random.choice([F(3, 2), F(2), F(5, 2), F(4, 3), F(3)])
        if half(a * k) and half(b * k):
            break
    A = a * k
    s1, s2, s1c, s2c = L1[0] + L1[1], L1[1] + L1[2], names2[0] + names2[1], names2[1] + names2[2]
    who = random.choice(NAMES)
    kind = random.choice(["flip", "flip", "add", "ok"])
    if kind == "flip":                               # copy/original on one side, original/copy on the other
        wrong = F(a * b, A)
        shown = fnum(wrong) if nice(wrong, 10) else "about " + fnum(F(round(float(wrong) * 10), 10))
        work = f"{a}/{fnum(A)} = {s2c}/{b},   {fnum(A)} x {s2c} = {a * b},   {s2c} = {shown}"
        right = "Ratios not in the same order"
    elif kind == "add":                              # added the difference instead of multiplying by k
        work = f"{fnum(A)} - {a} = {fnum(A - a)},   {s2c} = {b} + {fnum(A - a)} = {fnum(b + A - a)}"
        right = "Should multiply by k, not add"
    else:
        work = f"{fnum(A)}/{a} = {s2c}/{b},   {a} x {s2c} = {fnum(A * b)},   {s2c} = {fnum(b * k)}"
        right = "Nothing: the work is correct"
    notes = [f"{L1} ~ {''.join(names2)}.   {s1} = {a},  {s2} = {b},  {s1c} = {fnum(A)}.  Find {s2c}.",
             "", f"{who}'s work:   {work}"]
    traps = ["Ratios not in the same order", "Nothing: the work is correct",
             "Should multiply by k, not add", f"{s1} does not match {s1c}",
             "Should not cross-multiply"]
    return build("What went wrong?", right, [t for t in traps if t != right], {"notes": notes})


# ==========================================
# 5. TOPIC 4 - Scale Diagrams  (W12L4)
# ==========================================
SCALES_M = [2, 4, 5, 10, 20, 25, 50]
SCALES_KM = [2, 5, 10, 20, 25, 50]
THINGS = ["path", "fence", "trail", "dock", "bridge", "garden", "track", "wall"]


def t4_actual():                                     # drawing -> actual  (Actual = drawing x scale)
    s = random.choice(SCALES_M)
    d = F(random.randint(3, 19), 2)
    thing = random.choice(THINGS)
    A = d * s
    traps = [F(d, s), d + s, A / 10, A * 10, s, A + s]
    return build_num(f"Scale 1 cm : {s} m.  A {thing} is drawn {fnum(d)} cm.  Real length?", A, traps,
                     fmt=M, ok=tenth)


def t4_drawing():                                    # actual -> drawing  (Drawing = actual / scale)
    for _ in range(100):
        s = random.choice(SCALES_KM)
        A = s * F(random.randint(3, 30), 2)
        if A.denominator == 1:
            break
    thing = random.choice(["bike trail", "river", "road", "ferry route", "ski run", "canal"])
    d = A / s
    traps = [A * s, A - s, d * 10, F(s, A), d + 1, A]
    return build_num(f"Scale 1 cm : {s} km.  A {thing} is {fnum(A)} km long.  Map length?", d, traps,
                     fmt=CM, ok=lambda v: v > 0 and nice(v, 10) and v < 2000)


PLACES = ["park", "soccer field", "schoolyard", "parking lot", "garden", "playground", "skate park"]


def _park():
    s = random.choice([2, 5, 10, 20, 25, 50])
    a = F(random.randint(4, 16), 2)
    b = F(random.randint(3, 12), 2)
    if a == b:
        return None
    place_ = random.choice(PLACES)
    vis = info(f"A drawing of a rectangular {place_} is {fnum(a)} cm by {fnum(b)} cm. The scale is 1 cm : {s} m.")
    return place_, s, a, b, vis


def t4_perimeter():                                  # Scale Word Problems (L1): Park - perimeter of rectangle
    made = _park()
    if made is None:
        return None
    place_, s, a, b, vis = made
    P = 2 * (a + b) * s
    traps = [2 * (a + b), (a + b) * s, a * b * s, 2 * (a + b) * s * s, a * s * b * s, P + 2 * s]
    return build_num(f"Find the real perimeter of the {place_}.", P, traps, fmt=M,
                     ok=lambda v: v > 0 and nice(v, 10), visual=vis)


def t4_area():                                       # Scale Word Problems (L1): Park - area of rectangle (Nia)
    made = _park()
    if made is None:
        return None
    place_, s, a, b, vis = made
    A = a * s * b * s
    traps = [a * b * s, a * b, 2 * (a + b) * s, a * b * s * 2, A / 10, A * 10]
    return build_num(f"Find the real area of the {place_}.", A, traps, fmt=M2,
                     ok=lambda v: v > 0 and nice(v, 10), visual=vis)


def t4_find_scale():                                 # which scale was used?
    s = random.choice(SCALES_M + [40, 100])
    d = F(random.randint(2, 12), 2)
    L = d * s
    if L.denominator != 1:
        return None
    thing = random.choice(["shed", "barn", "cabin", "pool", "dock", "gym"])
    sc = lambda v: f"1 cm : {fnum(v)} m"
    cands = [L * d, L - d, F(s, 2), s * 2, s + 5, s * 10, F(L, d + 1), s - 5]
    traps = [sc(v) for v in cands if v > 0 and v != s and nice(v, 10)]
    return build(f"{a_(L).capitalize()} {fnum(L)} m long {thing} is drawn {fnum(d)} cm long. Find the scale.", sc(s),
                 list(dict.fromkeys(traps)))


# ---- grid shapes (x right, y down, in squares) ----
def grid_shape(kind, w, h, c=1):
    if kind == "rect":
        return [(0, 0), (w, 0), (w, h), (0, h)]
    if kind == "tri":
        return [(0, 0), (0, h), (w, h)]
    if kind == "trap":                                 # right trapezoid: top c, bottom w
        return [(0, 0), (c, 0), (w, h), (0, h)]
    return [(0, 0), (c, 0), (c, h - c), (w, h - c), (w, h), (0, h)]      # L-shape (c thick)


def _shape_dims(kind, small):
    """(w, h, c) for shape P.  small: P will be enlarged (2 or 3/2), else reduced (1/2)."""
    if small:
        w, h = random.randint(2, 3), random.randint(2, 3)
        if random.random() < 0.5:
            w, h = random.choice([(2, 3), (3, 2), (2, 2), (3, 3)])
        c = 1
    else:
        w, h = random.choice([(4, 6), (6, 4), (6, 6), (4, 4), (2, 6), (6, 2)])
        c = 2
    if kind in ("trap", "L") and (w < 2 or h < 2 or w <= c or h <= c):
        kind = "rect"
    return kind, w, h, c


def _shift(pts, dx, dy):
    return [(x + dx, y + dy) for x, y in pts]


def t4_grid_copy():                                  # Create Scaled Drawings on a Grid (Level 1)
    kind = random.choice(["rect", "tri", "trap", "L"])
    small = random.random() < 0.7
    kind, w, h, c = _shape_dims(kind, small)
    k = F(2) if small else F(1, 2)
    good = (w * k, h * k, c * k)
    t = random.choice([1, 2])
    cands = [(w + t, h + t, c) if small else (w - 2, h - 2, c),           # Ivy: added (or took away) instead
             (w * k, h, c * k), (w, h * k, c), (w * k + 1, h * k, c * k),  # only one way / one side off
             (w * k, h * k + 1, c * k), (w * k - 1, h * k, c * k), (w * k, h * k - 1, c * k)]
    cands = [(a, b, cc) for a, b, cc in cands
             if 1 <= a <= 6 and 1 <= b <= 6 and (a, b, cc) != good and F(a, b) != F(w, h)]
    if kind in ("trap", "L"):
        cands = [(a, b, cc) for a, b, cc in cands if cc < a and cc < b]
    cands = list(dict.fromkeys(cands))
    random.shuffle(cands)
    none = random.random() < 0.15
    shapes = cands[:4] if none else [good] + cands[:3]
    if len(shapes) < 4:
        return None
    random.shuffle(shapes)
    names = ["A", "B", "C", "D"]
    cells = [(8, 1), (15, 1), (8, 8), (15, 8)]         # 2 x 2 boxes of 6 x 6 squares, P on the left
    out = [{"pts": _shift(grid_shape(kind, w, h, c), 1, 1 + (13 - h) // 2), "label": "P"}]
    for n, (a, b, cc), (x0, y0) in zip(names, shapes, cells):
        a, b, cc = int(a), int(b), int(cc)
        out.append({"pts": _shift(grid_shape(kind, a, b, cc), x0, y0), "label": n})
    right = "None of them" if none else f"Shape {names[shapes.index(good)]}"
    opts = [f"Shape {n}" for n in names] + ["None of them"]
    vis = {"notes": [f"Shape P is copied with k = {frac(k)}."], "sqgrid": {"w": 22, "h": 15, "shapes": out}}
    return build(f"Which shape is shape P copied with k = {frac(k)}?", right, [o for o in opts if o != right], vis)


def t4_grid_side():                                  # draw the copy: how long is a side?  (Level 1)
    kind = random.choice(["rect", "tri", "trap", "L"])
    k = random.choice([F(2), F(3), F(3, 2), F(1, 2), F(5, 2)])
    for _ in range(100):
        w, h = random.randint(2, 6), random.randint(2, 6)
        c = random.choice([1, 2])
        if kind in ("trap", "L") and (w <= c or h <= c):
            continue
        if all((v * k).denominator == 1 for v in (w, h, c)):
            break
    else:
        return None
    side = random.choice(["bottom", "left"] + (["top"] if kind in ("trap", "L", "rect") else []))
    length = {"bottom": w, "left": h, "top": (w if kind == "rect" else c)}[side]
    if kind == "tri" and side == "bottom":
        length = w
    ans = length * k
    pts = _shift(grid_shape(kind, w, h, c), 2, 2)
    vis = {"sqgrid": {"w": 12, "h": 10, "shapes": [{"pts": pts, "label": "P"}]}}
    traps = [length + k.numerator, length * k.numerator, F(length, k), length, ans + 1, ans - 1]
    return build_num(f"P is copied with k = {frac(k)}. How long is the copy's {side} side?", ans, traps, fmt=SQ,
                     ok=lambda v: v.denominator == 1 and v > 1, visual=vis)


CAMP = ["Tent", "Ranger station", "Fire pit", "Dock", "Cabin", "Picnic table", "Flagpole", "Outhouse"]


def t4_map_distance():                               # Camp Map: count squares, then scale
    s = random.choice([5, 10, 20, 25, 50])
    for _ in range(200):
        names = random.sample(CAMP, 3)
        a = (random.randint(1, 17), random.randint(1, 10))
        if random.random() < 0.5:
            b = (a[0] + random.choice([-1, 1]) * random.randint(3, 12), a[1])
        else:
            b = (a[0], a[1] + random.choice([-1, 1]) * random.randint(3, 8))
        c = (random.randint(1, 17), random.randint(1, 10))
        if all(1 <= p[0] <= 18 and 1 <= p[1] <= 11 for p in (a, b)) and c not in (a, b) and \
                c[0] not in (a[0], b[0]) and c[1] not in (a[1], b[1]):
            break
    else:
        return None
    n = abs(a[0] - b[0]) + abs(a[1] - b[1])
    ans = n * s
    vis = {"notes": [f"Each square is 1 cm.  Scale 1 cm : {s} m."],
           "sqgrid": {"w": 19, "h": 12, "shapes": [], "points": [(*a, names[0]), (*b, names[1]), (*c, names[2])]}}
    traps = [n, (n + 1) * s, (n - 1) * s, n * s * 100, F(n, s), n + s]
    return build_num(f"How far is it from the {names[0]} to the {names[1]}?", ans, traps, fmt=M,
                     ok=lambda v: v > 0 and nice(v, 10), visual=vis)


# ==========================================
# 6. QUESTION MIX
# ==========================================
GENERATORS = {     # topic: [(generator, question type), ...]
    1: [(t1_solve, "Solve a proportion"),
        (t1_word, "Proportion word problem"),
        (t1_pair, "Matching parts from a ~ statement"),
        (t1_pentagon, "Point, angle, side from a ~ statement"),
        (t1_tri_complete, "Match by angles: complete the ~ statement"),
        (t1_quad_complete, "Turned copy: complete the ~ statement")],
    2: [(t2_find_k, "Find the scale factor"),
        (t2_type, "k: enlargement or reduction?"),
        (t2_copy, "Copy = original x k"),
        (t2_original, "Original = copy / k"),
        (t2_diagram, "Similar figures: missing side or k"),
        (t2_which_similar, "Which rectangle is similar?"),
        (t2_mistake, "What went wrong? (Lee / Ivy)")],
    3: [(t3_diagram, "Similar triangles: find x"),
        (t3_perimeter, "Similar triangles: perimeter"),
        (t3_statement, "Missing side from a ~ statement"),
        (t3_angles, "Match by angles (no diagram)"),
        (t3_shadow, "Shadow problem"),
        (t3_mistake, "What went wrong? (ratio order)")],
    4: [(t4_actual, "Drawing -> actual length"),
        (t4_drawing, "Actual -> drawing length"),
        (t4_perimeter, "Park: real perimeter"),
        (t4_area, "Park: real area"),
        (t4_find_scale, "Find the scale"),
        (t4_grid_copy, "Which shape is the scaled copy?"),
        (t4_grid_side, "Scaled copy on a grid: side length"),
        (t4_map_distance, "Camp map distance")],
}
TOPIC_COUNT = 4
_picker = Picker(GENERATORS)


def make_question(n):
    """(text, correct, 5 choices, visual or None) for topic n (1-4)."""
    return _picker.make(n)[:4]


def make_question_typed(n):
    """Same, plus the question type's name and the worked solution."""
    return _picker.make(n)
