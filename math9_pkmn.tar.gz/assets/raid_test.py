# ==========================================
# raid_test.py  -  checks for Class Raid  (plain Python, no pygame needed)
#
#   python raid_test.py --check-files
#       Lists any missing sprite, faint sound, music or background file.
#       Run it in the game folder (next to main.py).
#
#   python raid_test.py --students 20 --mode medium
#       Fake students raid Mewtwo on the REAL database, in a hidden test room
#       (students never see it).  --speed 10 plays 10x faster (default) and reports
#       how long the raid would really take.  The test room is deleted at the end.
#
#   python raid_test.py --fake --students 20 --mode medium
#       The same, but on a pretend database inside this program (no internet, instant).
#       --runs 5 repeats it and shows the average.
#
#   Fake students take 15-45 s per question and get 55-85% right (change STUDENT_* below).
# ==========================================
import argparse
import json
import os
import random
import statistics
import sys
import time
from urllib.parse import urlparse

import pokedex
import raid_net as rn
import team_net as tn

STUDENT_SECONDS = (15, 45)       # time a fake student takes per question
STUDENT_ACCURACY = (0.55, 0.85)  # fraction right, per fake student
MSG_SECONDS = 1.5                # each battle message (raid_battle.py MSG_MS)
TEST_ROOM = 99                   # raid/r99: not one of the 8 review rooms


# ==========================================
# 1. A PRETEND FIREBASE (same answers as the real one, for what the raid uses)
# ==========================================
class FakeDB:
    def __init__(self, now, latency_ms=120):
        self.root, self.now, self.latency = {}, now, latency_ms

    def _resolve(self, v):
        if isinstance(v, dict):
            if v == {".sv": "timestamp"}:
                return int(self.now())
            return {k: self._resolve(x) for k, x in v.items()}
        return v

    def _parts(self, url):
        p = urlparse(url).path
        p = p[:-5] if p.endswith(".json") else p
        return [s for s in p.split("/") if s]

    def get(self, parts):
        node = self.root
        for k in parts:
            if not isinstance(node, dict) or k not in node:
                return None
            node = node[k]
        return node

    def put(self, parts, value):
        value = self._resolve(value)
        if value in (None, {}):
            self._delete(self.root, parts)
            return None
        node = self.root
        for k in parts[:-1]:
            if not isinstance(node.get(k), dict):
                node[k] = {}
            node = node[k]
        node[parts[-1]] = value
        return value

    def _delete(self, node, parts):
        if not isinstance(node, dict) or not parts:
            return
        k = parts[0]
        if len(parts) == 1:
            node.pop(k, None)
        elif k in node:
            self._delete(node[k], parts[1:])
            if node[k] in ({}, None):
                node.pop(k)

    def handle(self, method, url, body):
        parts = self._parts(url)
        if method == "GET":
            out = self.get(parts)
        elif method == "PUT":
            out = self.put(parts, json.loads(body) if body else None)
        elif method == "DELETE":
            self._delete(self.root, parts)
            out = None
        else:
            raise ValueError(method)
        return 200, json.dumps(out)


class FakeTransport:
    """One browser's connection to the pretend database (answers arrive after a short delay)."""
    def __init__(self, db):
        self.db, self.res = db, {}

    def start(self, rid, method, url, body):
        status, text = self.db.handle(method, url, body)
        self.res[rid] = (self.db.now() + self.db.latency * random.uniform(0.5, 1.5), status, text)

    def take(self, rid):
        v = self.res.get(rid)
        if v is None or v[0] > self.db.now():
            return None
        del self.res[rid]
        return v[1], v[2]


# ==========================================
# 2. A FAKE STUDENT (uses the same rules as the game: raid_net.Fighter and raid_net.Room)
# ==========================================
class Bot:
    def __init__(self, net, clock, room_no, mon, speed):
        self.clock, self.speed, self.mon = clock, speed, mon
        self.me = tn.new_id() + mon[:3]
        self.room = rn.Room(net, clock, room_no, self.me)
        self.room.pick(mon)
        self.acc = random.uniform(*STUDENT_ACCURACY)
        self.fighter, self.gid, self.next_t = None, None, 0
        self.get_up_at = random.randint(1, 4)     # how patient this student is when fainted
        self.faints = 0

    def think(self):
        return random.uniform(*STUDENT_SECONDS) * 1000 / self.speed

    def step(self, mode):
        r = self.room
        r.update()
        now = self.clock.now()
        if self.fighter is None:
            g = r.game()
            if g is not None and r.my_pick():
                self.fighter, self.gid = rn.Fighter(self.mon, g["mode"]), g["id"]
                self.next_t = now + self.think()
            return
        g = r.game_by_id(self.gid)
        if g is None or g.get("over") or now < self.next_t:
            return
        hp, full = rn.boss_numbers(g, self.me, r.mine())
        if hp <= 0:
            r.end(self.gid, "win")
            return
        if rn.time_left_ms(g, now) <= 0:
            return
        f = self.fighter
        if rn.all_fainted(g, now, self.me, r.mine()):
            r.end(self.gid, "lose")
            return
        if f.resting(now):
            return
        if f.can_get_up() and f.revive >= self.get_up_at:
            ev = f.get_up()
        else:
            ok = random.random() < self.acc
            was_fainted = f.fainted
            ev = f.answer(ok, hp, full, now)
            if f.fainted and not was_fainted:
                self.faints += 1
            if f.rest_until > now:
                f.rest_until = now + rn.REST_MS / self.speed
            ev = ev + [("Correct!" if ok else "Incorrect!",)] + ([] if ok else [("answer",)])
        r.send(self.gid, f)
        hp2, _ = rn.boss_numbers(g, self.me, r.mine())
        if hp2 <= 0:
            r.end(self.gid, "win")
        elif rn.all_fainted(g, now, self.me, r.mine()):
            r.end(self.gid, "lose")
        self.next_t = now + len(ev) * MSG_SECONDS * 1000 / self.speed + self.think()


def run(students, mode, speed, fake, verbose=True):
    """One raid with fake students.  Returns (minutes it would really take or None, faints per student)."""
    random.seed()
    if fake:
        vt = [1.8e12]
        clock = tn.Clock(local=lambda: vt[0])
        clock.offset = 0
        db = FakeDB(lambda: vt[0])
        make_net = lambda: tn.Net("https://fake.firebaseio.com", FakeTransport(db))
        speed = 1
    else:
        clock = tn.Clock()
        net0 = tn.Net(tn.FIREBASE_URL, tn.ThreadTransport())
        sync = tn.ClockSync(net0, clock, "rtest" + tn.new_id())
        while not sync.update():
            net0.update()
            time.sleep(0.05)
        make_net = lambda: tn.Net(tn.FIREBASE_URL, tn.ThreadTransport())
        net0.delete(f"raid/{rn.room_key(TEST_ROOM)}")
        time.sleep(1)

    mons = rn.roster()
    mons = [m for m in mons if m not in rn.NO_DAMAGE][:students]
    nets, bots = [], []
    for i, m in enumerate(mons):
        n = make_net()
        nets.append(n)
        bots.append(Bot(n, clock, TEST_ROOM, m, speed))

    def tick(ms):
        if fake:
            vt[0] += ms
        else:
            time.sleep(ms / 1000)
        for n in nets:
            n.update()

    # lobby: wait until everyone's pick is confirmed, then the leader starts
    t0 = clock.local()
    started = False
    while True:
        tick(100)
        for b in bots:
            b.step(mode)
        if not started and all(b.room.my_pick() for b in bots):
            lead = next((b for b in bots if b.room.is_leader()), None)
            if lead and lead.room.start(mode):
                started = True
        if started and all(b.fighter for b in bots):
            break
        if clock.local() - t0 > 60000:
            print("  Lobby never filled: check the internet connection.")
            return None, 0
    gid = bots[0].gid
    start_real = clock.now()
    marks, next_mark = [], 0
    limit = rn.RAID_MS / speed + 60000
    result = None
    while clock.now() - start_real < limit:
        tick(100)
        for b in bots:
            b.step(mode)
        g = bots[0].room.game_by_id(gid)
        if g is None:
            continue
        hp, full = rn.boss_numbers(g)
        mins = (clock.now() - start_real) * speed / 60000
        if mins >= next_mark:
            marks.append((next_mark, hp, full))
            next_mark += 2
        if g.get("over") or hp <= 0:
            result = mins if (g.get("over") or "win") == "win" else -mins     # negative = everyone fainted
            break
    # settle, then the ranking
    for _ in range(30):
        tick(100)
        for b in bots:
            b.room.update()
    g = bots[0].room.game_by_id(gid) or {}
    faints = statistics.mean(b.faints for b in bots)
    if verbose:
        print(f"\n  {students} fake students, {rn.mode_info(mode)['name']}:")
        for m, hp, full in marks:
            bar = "#" * round(30 * hp / full)
            print(f"    {m:4.0f} min  {bar:<30} {hp:>6} / {full}")
        if result is not None and result < 0:
            print(f"  Everyone fainted after {-result:.1f} minutes.  The class loses.")
        elif result is not None:
            print(f"  Mewtwo fainted after {result:.1f} minutes  (limit {rn.RAID_MINUTES}).")
        else:
            print(f"  Time ran out: Mewtwo still had {marks[-1][1] if marks else '?'} HP.  The class loses.")
        print(f"  Faints per student: {faints:.1f}")
        print("  Top 10: " + ", ".join(rn.ranking(g)))
        if g.get("over"):
            print(f"  Result written to the database: {g['over']}")
    for b in bots:
        b.room.leave()
    if not fake:
        tick(1500)
        n = make_net()
        n.delete(f"raid/{rn.room_key(TEST_ROOM)}")
        for _ in range(30):
            n.update()
            time.sleep(0.1)
        print("  (Test room deleted.)")
    return result, faints


# ==========================================
# 3. FILE CHECK
# ==========================================
def check_files(folder):
    missing = []

    def need(path, what):
        if not os.path.exists(os.path.join(folder, path)):
            missing.append(f"{path}   ({what})")

    for name in rn.roster() + [rn.BOSS]:
        n = pokedex.info(name).get("folder")
        base = f"pokemon{n}/pokemon{n}"
        front = os.path.exists(os.path.join(folder, f"{base}_front (1).gif"))
        back = os.path.exists(os.path.join(folder, f"{base}_back (1).gif"))
        old = os.path.exists(os.path.join(folder, f"pokemon{n}/pokemon_{n} (1).gif"))
        if not (front or back or old):
            missing.append(f"{base}_front (1).gif   ({name}: no sprites at all)")
        elif name != rn.BOSS and not back:
            missing.append(f"{base}_back (1).gif   ({name}: no back sprite, the front one is used)")
        elif name == rn.BOSS and not front:
            missing.append(f"{base}_front (1).gif   ({name}: no front sprite, the back one is used)")
        need(f"{base}_faint.ogg", f"{name}'s faint sound")
    for f in rn.RAID_MUSIC:
        need(f, "raid music")
    need(rn.RAID_BACKGROUND, "raid background")
    need("caslon.ttf", "font")
    print(f"Pokemon to pick ({len(rn.roster())}): " + ", ".join(rn.roster()))
    if missing:
        print(f"\nMissing ({len(missing)}):")
        for m in missing:
            print("   " + m)
    else:
        print("\nAll raid files are there.")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--check-files", action="store_true")
    ap.add_argument("--dir", default=".")
    ap.add_argument("--students", type=int, default=20)
    ap.add_argument("--mode", default="medium", choices=rn.MODE_ORDER)
    ap.add_argument("--speed", type=float, default=10)
    ap.add_argument("--fake", action="store_true")
    ap.add_argument("--runs", type=int, default=1)
    a = ap.parse_args()
    if a.check_files:
        check_files(a.dir)
        sys.exit()
    times, faints = [], []
    for i in range(a.runs):
        t, fa = run(a.students, a.mode, a.speed, a.fake, verbose=(a.runs == 1))
        times.append(t)
        faints.append(fa)
    if a.runs > 1:
        won = [t for t in times if t is not None and t > 0]
        wiped = sum(1 for t in times if t is not None and t < 0)
        print(f"{a.students} students, {a.mode}: won {len(won)}/{a.runs}, everyone fainted {wiped}, time ran out {a.runs - len(won) - wiped}"
              + (f", average {statistics.mean(won):.1f} min (range {min(won):.1f}-{max(won):.1f})" if won else "")
              + f", {statistics.mean(faints):.1f} faints per student")
