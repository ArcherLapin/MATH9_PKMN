# ==========================================
# battles.py  -  the screens of Online Team Battle and Online Class Raid (Math 9).
#   Rules, numbers, database: online.py.   Topics, unit reviews and questions: main.py.
#   Where each Pokemon stands, its size and its animations: pokedex.py.
#   Team Battle (sections 2-4): unit tab -> topic -> wait for a partner -> battle -> Master / Trainee.
#   Class Raid (sections 5-8): unit review -> any Pokemon -> the first one in the room picks the difficulty
#   and presses Start -> the class vs Mewtwo -> top 10.  Teacher button + PIN: watch as Magikarp.
#   Same screens as the Precalculus 11 game, plus Math 9's unit tabs, its win / lose lines, and
#   tables / graphs shown over the battle area with a Show / Hide button (clicking an answer also hides it).
# ==========================================
import asyncio
import random
import re

import pygame

import pokedex
import online
from main_tool import (
    rx, ry, rs, curr_w, curr_h,
    resource_path, render_rich, fit_size, draw_center, draw_lines,
    Pokemon, Button, MessageSystem, TabBar, play_random_track, MUSIC_END_EVENT,
)

RAID_ON = True                    # False hides Online Class Raid


# ==========================================
# 1. SMALL HELPERS (both modes)
# ==========================================
async def frame(clock, fps):
    pygame.display.update()
    await asyncio.sleep(0)
    clock.tick(fps)


def click_sound(sounds):
    if sounds.get("click"):
        sounds["click"].play()


def play_sound(sounds, name):
    if name and sounds.get(name):
        sounds[name].play()


def draw_note(screen, net, text=""):
    if net is not None and net.errors >= 3:
        text = "Can't reach the game server. Check the internet connection (retrying...)."
    if text:
        draw_center(screen, text, 22, (150, 20, 20), 905)


def load_image(name, size):
    try:
        return pygame.transform.scale(pygame.image.load(resource_path(name)), size)
    except (pygame.error, FileNotFoundError, OSError):
        return None


def topic_buttons(rows, top=248, step=84, h=70):
    """One button per topic, in 2 columns (up to 8 = 4 rows).  rows = (level, title, open?, lock text, ...)."""
    out = []
    for i, row in enumerate(rows):
        level, title, is_open, lock = row[:4]
        b = Button(120 + (i % 2) * 440, top + (i // 2) * step, 400, h)
        b.level, b.title, b.is_open, b.lock = level, title, is_open, lock
        out.append(b)
    return out


def graph_label(q, is_open):
    """'Show Graph' / 'Hide Table' / 'Show Info'."""
    return ("Hide " if is_open else "Show ") + getattr(q.graph, "kind", "Graph")


async def message_screen(screen, clock, fps, lines):
    """A few lines of text. Click to go back."""
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return "quit"
            if event.type == pygame.MOUSEBUTTONDOWN:
                return None
        screen.fill((128, 128, 128))
        for i, line in enumerate(lines):
            draw_center(screen, line, 30 if i == 0 else 24, (0, 0, 0), 300 + i * 55)
        draw_center(screen, "Click anywhere to go back.", 22, (40, 40, 40), 800)
        await frame(clock, fps)


# ==========================================
# 2. TEAM BATTLE: SETTINGS, TOPIC SCREEN, WAITING ROOM
# ==========================================
TEAM_MUSIC = [1, 2, 3]            # Kanto music (music1-3): the opponents (Vaporeon, Flareon) are from Kanto
MSG_MS = 1500                     # each battle message shows this long (a click skips ahead)

TARGET_COLOR = (255, 90, 90)      # the glow on name plates you can click to attack
SIDE_COLORS = [(255, 225, 120), (255, 150, 140)]       # name text: your side, the other side

WIN_LINES = ["Both sides balanced: x = victory.",
             "Your win has a positive slope!",
             "One solution, and you found it.",
             "Checked and verified: you win!"]
LOSE_LINES = ["Every Master started as a Trainee.",
              "Rise over run: next time, you rise!",
              "No solution this time. There's always the next equation.",
              "Your line only goes up from here!"]


def short_topic(title):
    """'4.4 Factored Form' -> 'Factored Form',  'Unit Review (all lessons)' -> 'Unit Review'."""
    t = re.sub(r"^\d+\.\d+\s+", "", title)
    return re.sub(r"\s*\(.*?\)", "", t).strip()


def join_names(names):
    return names[0] if len(names) == 1 else ", ".join(names[:-1]) + " and " + names[-1]


async def topic_screen(screen, clock, fps, sounds, net, sync, lobby, api, note=""):
    """Returns a topic level, None for Back, or 'quit'."""
    units = api.units                                   # (key, tab name, heading, ready?)
    keys = [u[0] for u in units]
    tabs = TabBar([u[1] for u in units], y=130)         # same unit tabs as the single-player menu
    ready = [u[3] for u in units]

    def make_buttons(unit_key):
        return topic_buttons([t for t in api.topics if t[4] == unit_key], top=240, step=80, h=66)

    buttons = make_buttons(api.ui["unit"])
    back = Button(40, 860, 160, 60)
    back.text = "Back"
    humans = [online.slot_name(i) for i in online.HUMAN_SLOTS]
    subtitle = f"You and your partner: {join_names(humans)}" if len(humans) == 2 \
        else f"{online.ROOM_SIZE} students per battle"
    while True:
        net.update()
        if sync.update():
            lobby.update()
        for b in buttons:
            st = (lobby.status or {}).get(b.level)
            b.open = b.is_open and st is not None and st[0] == "open" and st[1] < online.ROOM_SIZE
            if not b.is_open:
                b.text = b.title + b.lock
            elif st is None:
                b.text = f"{b.title}   ..."
            elif st[0] == "busy":
                b.text = f"{b.title}   (battle in progress)"
            else:
                b.text = f"{b.title}   {min(st[1], online.ROOM_SIZE)}/{online.ROOM_SIZE}"
            b.color, b.text_color = ((150, 200, 200), (0, 0, 0)) if b.open else ((170, 170, 170), (100, 100, 100))

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return "quit"
            if event.type == pygame.MOUSEBUTTONDOWN:
                if back.clicked(event.pos):
                    click_sound(sounds)
                    return None
                t = tabs.clicked(event.pos)
                if t is not None:
                    if ready[t]:                        # a grey "coming soon" tab does nothing
                        click_sound(sounds)
                        api.ui["unit"] = keys[t]
                        buttons = make_buttons(api.ui["unit"])
                    break
                for b in buttons:
                    if b.clicked(event.pos) and b.open:
                        click_sound(sounds)
                        return b.level

        screen.fill((128, 128, 128))
        draw_center(screen, "Online Team Battle: pick a topic", 46, (0, 0, 0), 50)
        draw_center(screen, subtitle, 26, (20, 40, 90), 100)
        active = keys.index(api.ui["unit"])
        tabs.draw(screen, active, ready)
        draw_center(screen, units[active][2], 26, (20, 40, 90), 212)
        for b in buttons:
            b.draw(screen)
        draw_center(screen, f"A battle starts as soon as {online.ROOM_SIZE} students pick the same topic.",
                    22, (40, 40, 40), 600)
        back.draw(screen)
        draw_note(screen, net, note)
        await frame(clock, fps)


async def waiting_screen(screen, clock, fps, sounds, net, waiter, title):
    """Returns ('start', game), ('full', None), ('exit', None) or ('quit', None)."""
    exit_btn = Button(390, 640, 300, 70)
    exit_btn.text = "Exit"
    while True:
        net.update()
        waiter.update()
        if waiter.result:
            return waiter.result
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                waiter.leave()
                return "quit", None
            if event.type == pygame.MOUSEBUTTONDOWN and exit_btn.clicked(event.pos):
                click_sound(sounds)
                waiter.leave()
                return "exit", None
        screen.fill((128, 128, 128))
        dots = "." * (1 + (pygame.time.get_ticks() // 500) % 3)
        draw_center(screen, title, 44, (0, 0, 0), 170)
        draw_center(screen, f"Waiting for players{dots}", 36, (0, 0, 0), 320)
        draw_center(screen, f"{min(waiter.count, online.ROOM_SIZE)} / {online.ROOM_SIZE} players", 44, (20, 40, 90), 420)
        draw_center(screen, "The battle starts by itself when everyone is here.", 24, (40, 40, 40), 520)
        exit_btn.draw(screen)
        draw_note(screen, net)
        await frame(clock, fps)


# ==========================================
# 3. TEAM BATTLE: THE BATTLE
# ==========================================
async def battle_screen(screen, clock, fps, sounds, vfx, api, net, clk, battle, level):
    """Plays one battle. Returns True (my side won), False (lost), None (reset), or 'quit'."""
    me = battle.slot
    my_side = online.slot_team(me)
    partners = [i for i in online.teammates(me) if i != me]
    foes = online.foes(me)
    nm = online.slot_name

    # Pokemon on screen: same spot for each Pokemon on every screen ("(you)" marks yours).
    fighters = {}
    mine = online.teammates(me)
    places = list(zip(mine[:2], ["mine1", "mine2"])) + list(zip(foes[:2], ["foe1", "foe2"]))
    for i, place in places:
        hp = online.TEAM_SETUP[i]["hp"]
        mon = Pokemon(nm(i), hp, hp, 100, 100, vfx, view="back" if online.slot_team(i) == my_side else "front",
                      spot=pokedex.spot(f"team_{place}", nm(i)), fx=pokedex.fx(f"team_{place}"))
        mon.label = nm(i) + ("  (you)" if i == me else "")
        mon.label_color = SIDE_COLORS[0 if online.slot_team(i) == my_side else 1]
        fighters[i] = mon
    draw_order = [i for i, place in places if place in ("foe2", "foe1", "mine2")] + \
                 [i for i, place in places if place == "mine1"]

    ms = MessageSystem()
    msg_since = [0]
    title = api.topic_title(level)
    if battle.state.entries:                                # joined part-way (should be rare)
        battle.skip_old()
    else:
        ms.add(f"Team Battle: {title}!")
        ms.add(f"You are {nm(me)}!" + (f"  Your partner is {join_names([nm(i) for i in partners])}." if partners else ""))
    for i, mon in fighters.items():
        mon.hp = battle.state.hp[i]
        if mon.hp <= 0:
            mon.fainted = True

    buttons = [Button(80, 795, 290, 60), Button(395, 795, 290, 60), Button(710, 795, 290, 60),
               Button(80, 865, 290, 60), Button(395, 865, 290, 60), Button(710, 865, 290, 60)]
    graph_button = Button(850, 744, 140, 42, color=(250, 215, 90))
    turn = {"q": None, "key": None, "panel": None, "graph_open": False, "pick": False}

    bg = load_image("background.jpg", (curr_w, ry(720)))
    tb = load_image("textbox.png", (curr_w, curr_h - ry(720)))

    sounds["music_pool"] = TEAM_MUSIC
    play_random_track(TEAM_MUSIC)

    def new_question():
        q = api.next_question(level)
        turn["q"], turn["key"] = q, battle.state.next_key
        turn["panel"] = api.build_graph_panel(q.graph) if q.graph else None
        turn["graph_open"], turn["pick"] = False, False
        for k in range(5):
            buttons[k].text = q.options[k]
        buttons[5].text = f"Sitrus Berry x{battle.state.berries[me]}"

    def asking():
        """True while I'm looking at my question."""
        return (battle.my_turn() and not ms.has_active_message() and not battle.state.over
                and turn["key"] == battle.state.next_key and turn["q"] is not None)

    def targets():
        """Opponents I can attack (still standing)."""
        return [i for i in foes if battle.state.hp[i] > 0]

    def attack(target):
        """Send my correct answer with the opponent I picked."""
        d, x = battle.damage_now()
        battle.send("ok", d, x, target=target)
        turn["q"], turn["pick"] = None, False

    def click(pos):
        if turn["graph_open"]:                        # a click hides the table/graph...
            turn["graph_open"] = False
            if not any(b.clicked(pos) for b in buttons):
                return None                           # ...and a click on an answer also answers
        if ms.has_active_message():
            ms.clear()
            return None
        if battle.state.over:
            return "done"
        if not asking():
            return None
        if turn["pick"]:                              # correct answer: click a name plate
            for i in targets():
                if fighters[i].box_rect().collidepoint(pos):
                    click_sound(sounds)
                    attack(i)
                    return None
            return None
        if turn["panel"] is not None and graph_button.clicked(pos):
            click_sound(sounds)
            turn["graph_open"] = True
            return None
        for btn in buttons:
            if not btn.clicked(pos):
                continue
            click_sound(sounds)
            if btn is buttons[5]:
                if battle.state.berries[me] <= 0:
                    ms.add("You are out of Berries!")
                elif battle.state.hp[me] >= battle.state.max_hp[me]:
                    ms.add("Your HP is already full!")
                else:
                    battle.send("be")
                return None
            q = turn["q"]
            if btn.text == q.correct:
                if sounds.get("correct"):
                    sounds["correct"].play()
                if len(targets()) == 1:               # only one opponent left: no need to pick
                    attack(targets()[0])
                else:
                    turn["pick"] = True
                    turn["graph_open"] = False
            else:
                battle.send("no", correct_text=q.correct)
                turn["q"] = None
            return None
        return None

    def draw_clock(s, compact=False):
        """Whose turn (and the clock)."""
        if s.over or s.active is None:
            return
        if online.is_ai(s.active):
            label, col = f"{nm(s.active)}'s turn", (0, 0, 0)
        else:
            secs = online.time_left(s, clk.now())
            who = "Your turn" if s.active == me else f"{nm(s.active)}'s turn"
            label = f"{who}   {secs // 60}:{secs % 60:02d}"
            col = (200, 20, 20) if secs <= 10 else (0, 0, 0)
        box = pygame.Rect(rx(875), ry(6), rx(198), ry(44)) if compact else pygame.Rect(rx(760), ry(10), rx(310), ry(62))
        pygame.draw.rect(screen, (255, 255, 255), box)
        pygame.draw.rect(screen, (0, 0, 0), box, max(1, rs(3)))
        t = render_rich(label, fit_size(label, 22 if compact else 28, 180 if compact else 290), col)
        screen.blit(t, t.get_rect(center=box.center))

    while True:
        net.update()
        battle.update()
        if battle.gone:
            pygame.mixer.music.stop()
            await message_screen(screen, clock, fps, ["This battle was reset.", "Pick a topic to play again."])
            return None
        s = battle.state

        for text, target, change, effect in battle.new_messages():
            mon = fighters.get(target)
            if change < 0:
                anims, snd = pokedex.EFFECTS.get(effect, pokedex.EFFECTS["hit"])
                ms.add(text, target=mon, hp_change=change, vfx=anims, sound=sounds.get(snd))
            else:
                ms.add(text, target=mon, hp_change=change)

        # messages move on by themselves (a click skips ahead)
        had = bool(ms.current)
        ms.update()
        if ms.current and not had:
            msg_since[0] = pygame.time.get_ticks()
        if ms.current and pygame.time.get_ticks() - msg_since[0] > MSG_MS:
            ms.clear()
        if not ms.has_active_message():
            for i, mon in fighters.items():
                mon.hp = s.hp[i]                      # stay exactly in step with the turn log
        for mon in fighters.values():
            if mon.hp <= 0:
                mon.play_faint_sound()

        if battle.my_turn() and not s.over and turn["key"] != s.next_key and not ms.has_active_message():
            new_question()
        # Picked the right answer but not a target, and time is nearly up: attack the usual one.
        if turn["pick"] and battle.my_turn() and clk.now() >= s.deadline - 1500:
            attack(online.target_for(me, s.hp))

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return "quit"
            if event.type == MUSIC_END_EVENT:
                play_random_track(sounds.get("music_pool") or [])
            if event.type == pygame.MOUSEBUTTONDOWN:
                if click(event.pos) == "done":
                    pygame.mixer.music.stop()
                    return s.winner == my_side
            elif event.type == pygame.KEYDOWN and turn["graph_open"]:
                turn["graph_open"] = False

        # ---------- draw ----------
        screen.fill((0, 0, 0))
        if bg: screen.blit(bg, (0, 0))
        pygame.draw.rect(screen, (75, 117, 155), (0, ry(720), curr_w, curr_h - ry(720)))
        if tb: screen.blit(tb, (0, ry(720)))
        for i in draw_order:
            fighters[i].draw(screen, active=(i == s.active and not s.over))

        showing = turn["graph_open"] and turn["panel"] is not None and asking()
        if showing:                                      # table/graph over the battle area
            api.draw_graph_overlay(screen, turn["panel"])
        draw_clock(s, compact=showing)

        if ms.has_active_message():
            ms.draw(screen)
        elif s.over:
            draw_lines(screen, "Click anywhere to continue.", (0, 0, 0), 80, 765, 920)
        elif asking() and turn["pick"]:
            draw_lines(screen, "Correct!  Click the name of the Pokemon you want to attack.",
                       (255, 255, 255), 85, 768, 905)
            if (pygame.time.get_ticks() // 300) % 2 == 0:          # blinking glow on the plates
                for i in targets():
                    pygame.draw.rect(screen, TARGET_COLOR, fighters[i].box_rect(), max(3, rs(5)))
        elif asking():
            has_graph = turn["panel"] is not None
            draw_lines(screen, turn["q"].text, (255, 255, 255), 85, 760, 755 if has_graph else 905)
            for btn in buttons:
                btn.draw(screen)
            if has_graph:
                graph_button.text = graph_label(turn["q"], turn["graph_open"])
                graph_button.draw(screen)
        elif s.active == me:
            draw_lines(screen, "Sending your answer...", (255, 255, 255), 85, 768, 905)
        elif s.active is not None:
            wait = "is getting ready..." if online.is_ai(s.active) else "is answering..."
            draw_lines(screen, f"{nm(s.active)} {wait}", (255, 255, 255), 85, 768, 905)

        draw_note(screen, net)
        await frame(clock, fps)


async def title_screen(screen, clock, fps, sounds, won, topic, partner_names):
    """Master of ... / Trainee of ...  Click (after a short delay) to continue."""
    start = pygame.time.get_ticks()
    line = random.choice(WIN_LINES if won else LOSE_LINES)
    who = f"You and {join_names(partner_names)} are now" if partner_names else "You are now"
    if won and sounds.get("correct"):
        sounds["correct"].play()
    while True:
        ready = pygame.time.get_ticks() - start > 1500
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return "quit"
            if event.type == pygame.MOUSEBUTTONDOWN and ready:
                click_sound(sounds)
                return None
        screen.fill((150, 115, 20) if won else (40, 70, 120))
        draw_center(screen, "YOUR TEAM WON!" if won else "Your team lost this time.", 40, (255, 255, 255), 170)
        draw_center(screen, who, 28, (255, 255, 255), 270)
        box = pygame.Rect(rx(90), ry(330), rx(900), ry(170))
        pygame.draw.rect(screen, (255, 255, 255), box)
        pygame.draw.rect(screen, (0, 0, 0), box, max(1, rs(4)))
        title = ("Master of " if won else "Trainee of ") + topic
        draw_center(screen, title, fit_size(title, 60, 860), (120, 80, 0) if won else (20, 40, 90), 415)
        draw_center(screen, line, fit_size(line, 28, 980), (255, 255, 255), 580)
        if ready:
            draw_center(screen, "Click anywhere to go back to the topics.", 24, (230, 230, 230), 800)
        await frame(clock, fps)


# ==========================================
# 4. TEAM BATTLE: THE WHOLE MODE  (called from main.py)
# ==========================================
async def team_mode(screen, clock, fps, sounds, vfx, api):
    """Returns None (back to the start screen) or 'quit'."""
    if not online.FIREBASE_URL:
        return await message_screen(screen, clock, fps, [
            "Team Battle isn't set up yet.", "Add the Firebase database URL at the top of online.py."])
    try:
        net = online.Net(online.FIREBASE_URL, online.make_transport())
    except Exception:
        return await message_screen(screen, clock, fps, ["Team Battle can't connect from this browser."])
    clk = online.Clock()
    me = online.new_id()
    sync = online.ClockSync(net, clk, me)
    lobby = online.Lobby(net, clk, [t[0] for t in api.topics])

    note = ""
    while True:
        level = await topic_screen(screen, clock, fps, sounds, net, sync, lobby, api, note)
        if level in (None, "quit"):
            return level
        note = ""
        title = api.topic_title(level)
        waiter = online.Waiter(net, clk, level, me)
        kind, game = await waiting_screen(screen, clock, fps, sounds, net, waiter, title)
        if kind == "quit":
            return "quit"
        if kind == "full":
            note = f"{title} just started without you. Pick it again in a moment, or another topic."
            continue
        if kind != "start":
            continue
        battle = online.Battle(net, clk, level, me, game)
        won = await battle_screen(screen, clock, fps, sounds, vfx, api, net, clk, battle, level)
        if won == "quit":
            return "quit"
        if won is None:
            continue
        partners = [online.slot_name(i) for i in online.teammates(battle.slot) if i != battle.slot]
        if await title_screen(screen, clock, fps, sounds, won, short_topic(title), partners) == "quit":
            return "quit"
        lobby.status = None                  # refresh the topics


# ==========================================
# 5. CLASS RAID: SETTINGS AND HELPERS  (positions and sizes: pokedex.py)
# ==========================================
BOSS_BAR = (40, 14, 1000, 92)                  # Mewtwo's long HP bar with the clock: x, y, width, height
MY_NAME_COLOR = (255, 255, 255)                # your name in your HP box (white, like single player)


def play_raid_music():
    """Usually a raid track, sometimes one of the other battle tracks.  A missing file is skipped."""
    first = online.RAID_MUSIC if random.randint(1, 100) <= online.RAID_MUSIC_CHANCE else online.OTHER_MUSIC
    rest = online.OTHER_MUSIC if first is online.RAID_MUSIC else online.RAID_MUSIC
    for f in random.sample(first, len(first)) + random.sample(rest, len(rest)):
        try:
            pygame.mixer.music.load(resource_path(f))
            pygame.mixer.music.set_volume(0.15)
            pygame.mixer.music.play(0)
            return
        except (pygame.error, FileNotFoundError, OSError):
            continue
    try:
        pygame.mixer.music.stop()
    except pygame.error:
        pass


def stop_music(sounds):
    sounds["music_pool"] = []                 # the start screen doesn't restart raid music
    try:
        pygame.mixer.music.stop()
    except pygame.error:
        pass


class RaidMon(Pokemon):
    """A Pokemon drawn like in the other modes, with single player's style of name / HP box."""
    def draw_hp_box(self, surface, active=False):
        """Single player's name / HP bar (same sizes and colours), with the grey box around it if panel."""
        x, y, w = self.bx, self.by, 300
        grey = (170, 170, 170)
        if self.panel:
            r = pygame.Rect(rx(x - 12), ry(y - 8), rx(w + 24), ry(104))
            bg = pygame.Surface(r.size, pygame.SRCALPHA)
            bg.fill((0, 0, 0, 110))
            surface.blit(bg, r.topleft)
        s = render_rich(self.label, fit_size(self.label, 26, w), grey if self.fainted else self.label_color)
        surface.blit(s, (rx(x), ry(y)))
        if getattr(self, "watching", False):              # Magikarp (teacher): no HP, it only watches
            s = render_rich("Watching the raid", 26, (255, 255, 255))
            surface.blit(s, (rx(x), ry(y + 50)))
            return
        ratio = max(0, self.hp / self.max_hp)
        pygame.draw.rect(surface, (255, 0, 0), (rx(x), ry(y + 40), rx(w), ry(12)))
        pygame.draw.rect(surface, (0, 255, 0), (rx(x), ry(y + 40), rx(w * ratio), ry(12)))
        hp_text = "Fainted" if self.fainted else f"HP: {int(self.hp)} / {int(self.max_hp)}"
        s = render_rich(hp_text, 26, grey if self.fainted else (255, 255, 255))
        surface.blit(s, (rx(x), ry(y + 60)))


class BossMon(RaidMon):
    """Mewtwo: its HP is the long bar at the top (draw_boss_bar), not a box."""
    def draw_hp_box(self, surface, active=False):
        pass


def make_mon(name, place, vfx, view):
    """place = "boss" or "me": the spot and animation settings come from pokedex.py ("raid_boss" / "raid_me")."""
    cls = BossMon if place == "boss" else RaidMon
    return cls(name, online.RAID_PLAYER_HP, online.RAID_PLAYER_HP, 100, 100, vfx, view=view,
               spot=pokedex.spot(f"raid_{place}", name), fx=pokedex.fx(f"raid_{place}"))


def fmt_clock(ms):
    s = int((ms + 999) // 1000)
    return f"{s // 60}:{s % 60:02d}"


def draw_boss_bar(screen, hp, full, left_ms, mode_name, counts):
    """Mewtwo's name, the long HP bar, the clock, and how many students are in battle / fainted."""
    bx, by, bw, bh = BOSS_BAR
    r = pygame.Rect(rx(bx), ry(by), rx(bw), ry(bh))
    bg = pygame.Surface(r.size, pygame.SRCALPHA)
    bg.fill((0, 0, 0, 140))
    screen.blit(bg, r.topleft)
    x, y, w = bx + 18, by + 8, bw - 36
    s = render_rich(f"{online.BOSS}   ({mode_name})", 28, (255, 225, 120))
    screen.blit(s, (rx(x), ry(y)))
    t = render_rich(f"Time left  {fmt_clock(left_ms)}", 26, (255, 120, 120) if left_ms <= 60000 else (255, 255, 255))
    screen.blit(t, t.get_rect(topright=(rx(x + w), ry(y + 2))))
    ratio = 0 if full <= 0 else max(0, min(1, hp / full))
    col = (0, 210, 0) if ratio > 0.5 else (240, 200, 0) if ratio > 0.2 else (230, 40, 30)
    pygame.draw.rect(screen, (90, 0, 0), (rx(x), ry(y + 40), rx(w), ry(18)))
    pygame.draw.rect(screen, col, (rx(x), ry(y + 40), rx(w * ratio), ry(18)))
    pygame.draw.rect(screen, (0, 0, 0), (rx(x), ry(y + 40), rx(w), ry(18)), max(1, rs(2)))
    h = render_rich(f"HP: {int(hp):,} / {int(full):,}", 20, (255, 255, 255))
    screen.blit(h, (rx(x), ry(y + 61)))
    c = render_rich(f"In battle ({counts[0]})     Fainted ({counts[1]})", 20, (255, 255, 255))
    screen.blit(c, c.get_rect(topright=(rx(x + w), ry(y + 61))))


_icons = {}


def _load_icon(mon, size):
    """The first frame of its front sprite, cropped to the visible part and fitted into size x size."""
    n = pokedex.info(mon).get("folder")
    img = None
    for name in (f"pokemon{n}/pokemon{n}_front (1).gif", f"pokemon{n}/pokemon{n}_back (1).gif",
                 f"pokemon{n}/pokemon_{n} (1).gif"):
        try:
            img = pygame.image.load(resource_path(name))
            break
        except (pygame.error, FileNotFoundError, OSError):
            continue
    if img is None:
        return False
    bb = img.get_bounding_rect()
    if bb.w < 4 or bb.h < 4:
        bb = img.get_rect()
    img = img.subsurface(bb).copy()
    try:
        img = img.convert_alpha()
    except pygame.error:
        pass
    k = min(size / bb.w, size / bb.h)
    return pygame.transform.scale(img, (max(1, int(bb.w * k)), max(1, int(bb.h * k))))


def icon(mon, size, budget):
    """A Pokemon's picture for the pick screen (None until loaded: budget[0] = how many may load this frame)."""
    key = (mon, size)
    if key not in _icons:
        if budget[0] <= 0:
            return None
        budget[0] -= 1
        _icons[key] = _load_icon(mon, rs(size))
    return _icons[key] or None


# ==========================================
# 6. CLASS RAID: TOPIC SCREEN, PIN, LOBBY
# ==========================================
async def pin_screen(screen, clock, fps, sounds):
    """Mr. Chung's PIN (observe mode as Magikarp).  Returns True (right PIN), False (Back) or 'quit'."""
    keys = []
    for i, label in enumerate(["1", "2", "3", "4", "5", "6", "7", "8", "9", "Clear", "0", "OK"]):
        b = Button(375 + (i % 3) * 115, 300 + (i // 3) * 95, 100, 80)
        b.text = label
        keys.append(b)
    back = Button(40, 860, 160, 60)
    back.text = "Back"
    typed, wrong_at = "", -99999

    def press(label):
        nonlocal typed, wrong_at
        if label == "Clear":
            typed = ""
        elif label == "OK":
            if online.check_pin(typed):
                return True
            typed, wrong_at = "", pygame.time.get_ticks()
        elif len(typed) < 8:
            typed += label
        return None

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return "quit"
            if event.type == pygame.KEYDOWN:
                if event.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
                    if press("OK"):
                        return True
                elif event.key == pygame.K_BACKSPACE:
                    typed = typed[:-1]
                elif event.key == pygame.K_ESCAPE:
                    return False
                elif event.unicode and event.unicode.isdigit():
                    press(event.unicode)
            if event.type == pygame.MOUSEBUTTONDOWN:
                if back.clicked(event.pos):
                    click_sound(sounds)
                    return False
                for b in keys:
                    if b.clicked(event.pos):
                        click_sound(sounds)
                        if press(b.text):
                            return True
        screen.fill((128, 128, 128))
        draw_center(screen, "Teacher: watch the raid as Magikarp", 40, (0, 0, 0), 90)
        draw_center(screen, "Enter the PIN", 28, (20, 40, 90), 160)
        box = pygame.Rect(rx(390), ry(205), rx(300), ry(70))
        pygame.draw.rect(screen, (255, 255, 255), box)
        pygame.draw.rect(screen, (0, 0, 0), box, max(1, rs(3)))
        draw_center(screen, " ".join("*" * len(typed)) or " ", 40, (0, 0, 0), 242)
        for b in keys:
            b.draw(screen, size=30)
        if pygame.time.get_ticks() - wrong_at < 2500:
            draw_center(screen, "Wrong PIN. Try again.", 26, (150, 20, 20), 700)
        back.draw(screen)
        await frame(clock, fps)


LIVE_RED = (205, 30, 30)


def draw_live(screen, b, st):
    """A topic with a raid or a lobby going on: a bold red border and a red LIVE badge on its top edge."""
    r = b.rect()
    pygame.draw.rect(screen, LIVE_RED, r, max(3, rs(5)))
    if st["s"] == "raid":
        who = f"{st['n']} in the raid"
    else:
        who = f"{st['n']} in the lobby" if st["n"] else "Mr. Chung is waiting"
    white = (255, 255, 255)
    live, more = render_rich("LIVE", 18, white), render_rich(who, 18, white)
    pad, dot, gap = rs(9), rs(5), rs(8)
    h = max(live.get_height(), more.get_height()) + rs(4)
    w = pad + 2 * dot + gap + live.get_width() + 1 + gap + more.get_width() + pad
    pill = pygame.Rect(r.right - w - rs(14), r.top - h // 2, w, h)
    pygame.draw.rect(screen, LIVE_RED, pill, border_radius=h // 2)
    pygame.draw.rect(screen, white, pill, max(1, rs(2)), border_radius=h // 2)
    x = pill.x + pad
    if (pygame.time.get_ticks() // 600) % 2 == 0:                       # a blinking dot, like live TV
        pygame.draw.circle(screen, white, (x + dot, pill.centery), dot)
    x += 2 * dot + gap
    for dx in (0, 1):                                                   # drawn twice = bold
        screen.blit(live, live.get_rect(midleft=(x + dx, pill.centery)))
    x += live.get_width() + 1 + gap
    screen.blit(more, more.get_rect(midleft=(x, pill.centery)))


async def raid_topic_screen(screen, clock, fps, sounds, net, sync, board, api, note="", teacher=False):
    """Pick a unit review (one raid room each; LIVE ones have people in them now).
    Returns a room number, None (Back), 'teacher' or 'quit'."""
    buttons = topic_buttons(api.raid_topics)
    back = Button(40, 860, 160, 60)
    back.text = "Back"
    teach = Button(840, 860, 200, 60, color=(250, 215, 90) if teacher else (138, 138, 138))
    teach.text = "Teacher: ON" if teacher else "Teacher"
    if not teacher:
        teach.text_color = (105, 105, 105)        # faint: barely stands out from the grey screen
        teach.border_color = (112, 112, 112)      # a soft grey outline instead of black
    while True:
        net.update()
        connected = sync.update()                       # the clock is lined up with the server
        board.update()                                  # which topics are LIVE
        for b in buttons:
            b.open = b.is_open and connected
            b.live = board.status(b.level) if b.open else None
            b.text = b.title if b.is_open else b.title + b.lock
            b.color, b.text_color = ((150, 200, 200), (0, 0, 0)) if b.open else ((170, 170, 170), (100, 100, 100))

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return "quit"
            if event.type == pygame.MOUSEBUTTONDOWN:
                if back.clicked(event.pos):
                    click_sound(sounds)
                    return None
                if teach.clicked(event.pos):
                    click_sound(sounds)
                    return "teacher"
                for b in buttons:
                    if b.clicked(event.pos) and b.open:
                        click_sound(sounds)
                        return b.level

        screen.fill((128, 128, 128))
        draw_center(screen, "Online Class Raid: pick a topic", 50, (0, 0, 0), 62)
        draw_center(screen, "Unit reviews: each one mixes every topic of its unit.", 26, (0, 0, 0), 150)
        draw_center(screen, f"The whole class battles {online.BOSS} together. Each right answer is a hit!",
                    24, (20, 40, 90), 212)
        for b in buttons:
            b.draw(screen)
        for b in buttons:                                # badges last: they sit over the gap between rows
            if b.live:
                draw_live(screen, b, b.live)
        draw_center(screen, f"Beat {online.BOSS} within {online.RAID_MINUTES} minutes. "
                            "If everyone faints at once, the class loses!", 22, (20, 40, 90), 612)
        draw_center(screen, "Join a topic, pick your Pokemon, and wait for the first one in the room to press Start.",
                    20, (40, 40, 40), 650)
        if teacher:
            draw_center(screen, f"Teacher mode: you will watch as {online.OBSERVER}.", 24, (120, 70, 0), 700)
        back.draw(screen)
        teach.draw(screen, size=24)
        draw_note(screen, net, note)
        await frame(clock, fps)


TILE_TOP, TILE_H, TILE_GAP = 120, 128, 10


def tile_rects(n):
    cols = 8 if n <= 24 else 10
    w = (1000 - TILE_GAP * (cols - 1)) / cols
    return [pygame.Rect(40 + (i % cols) * (w + TILE_GAP), TILE_TOP + (i // cols) * (TILE_H + TILE_GAP), w, TILE_H)
            for i in range(n)]


def who_text(mon):
    """How the lobby names the leader."""
    if mon == online.OBSERVER:
        return f"Mr. Chung ({online.OBSERVER})"
    return mon or "the first one in the room"


async def lobby_screen(screen, clock, fps, sounds, net, room, title):
    """Pick a Pokemon (any one: several students may pick the same).  The first one in the room
    picks the difficulty and starts.  Returns the raid to join, None (Back) or 'quit'."""
    mons = [] if room.observer else online.pool()
    rects = tile_rects(len(mons))
    mode = online.DEFAULT_MODE
    mode_btns = []
    for i, m in enumerate(online.MODE_ORDER):
        b = Button(255 + i * 195, 640, 180, 60)
        b.mode, b.text = m, online.MODES[m]["name"]
        mode_btns.append(b)
    start = Button(390, 725, 300, 70)
    back = Button(40, 860, 160, 60)
    back.text = "Back"
    status_y = TILE_TOP + 3 * (TILE_H + TILE_GAP) + 20
    while True:
        net.update()
        room.update()
        mine = room.my_pick()
        game = room.game()
        if game is not None and mine:
            return game
        lead = room.is_leader()                         # (False while "Reconnecting...")
        starting = room.starting()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                room.leave()
                return "quit"
            if event.type != pygame.MOUSEBUTTONDOWN:
                continue
            if back.clicked(event.pos):
                click_sound(sounds)
                room.leave()
                return None
            for m, r in zip(mons, rects):
                if pygame.Rect(rx(r.x), ry(r.y), rx(r.w), ry(r.h)).collidepoint(event.pos):
                    click_sound(sounds)
                    room.pick(m)
            if lead and game is None and not starting:
                for b in mode_btns:
                    if b.clicked(event.pos):
                        click_sound(sounds)
                        mode = b.mode
                if start.clicked(event.pos) and mine:
                    click_sound(sounds)
                    room.start(mode)                    # (a second click does nothing: "Starting...")

        # ---------- draw ----------
        screen.fill((128, 128, 128))
        draw_center(screen, f"Online Class Raid  -  {title}", 40, (0, 0, 0), 40)
        budget = [3]                                    # load a few icons per frame (no freeze)
        if room.observer:
            draw_center(screen, f"Teacher mode: you are watching as {online.OBSERVER}.", 28, (120, 70, 0), 110)
            img = icon(online.OBSERVER, 200, budget)
            if img is not None:
                screen.blit(img, img.get_rect(center=(rx(540), ry(270))))
        else:
            draw_center(screen, "Pick your Pokemon (friends can pick the same one):", 26, (20, 40, 90), 92)
            for m, r in zip(mons, rects):
                box = pygame.Rect(rx(r.x), ry(r.y), rx(r.w), ry(r.h))
                pygame.draw.rect(screen, (250, 225, 120) if m == mine else (230, 235, 240), box)
                pygame.draw.rect(screen, (0, 0, 0), box, max(1, rs(4 if m == mine else 2)))
                img = icon(m, 82, budget)
                if img is not None:
                    screen.blit(img, img.get_rect(center=(box.centerx, box.y + ry(52))))
                s = render_rich(m, fit_size(m, 18, int(r.w) - 8), (0, 0, 0))
                screen.blit(s, s.get_rect(center=(box.centerx, box.bottom - ry(14))))

        here = len(room.who())
        if not room.loaded:
            draw_center(screen, "Connecting...", 26, (0, 0, 0), status_y)
        elif room.observer:
            draw_center(screen, f"{here} in this room", 28, (0, 0, 0), status_y)
        elif mine:
            draw_center(screen, f"You are {mine}!   ({here} in this room)", 28, (0, 0, 0), status_y)
        else:
            draw_center(screen, f"Click a Pokemon to pick it.   ({here} in this room)", 26, (0, 0, 0), status_y)

        if not room.loaded:
            pass                                        # still connecting: nothing to show yet
        elif room.slow():
            draw_center(screen, "Slow connection: reconnecting to the raid server...", 26, (150, 20, 20), 680)
        elif not room.fresh():
            draw_center(screen, "Connecting...", 26, (20, 40, 90), 680)
        elif game is not None:
            draw_center(screen, "A raid is going on! Pick a Pokemon to jump in.", 28, (20, 40, 90), 680)
        elif starting:
            draw_center(screen, "Starting the raid...", 32, (20, 40, 90), 680)
        elif lead:
            draw_center(screen, "You are first in the room: choose the difficulty, then press Start", 24,
                        (20, 40, 90), 612)
            for b in mode_btns:
                on = b.mode == mode
                b.color, b.text_color = ((250, 215, 90), (0, 0, 0)) if on else ((200, 210, 215), (0, 0, 0))
                b.draw(screen, size=26)
            start.text = "Start the raid!"
            start.color, start.text_color = ((150, 200, 200), (0, 0, 0)) if mine else ((170, 170, 170), (100, 100, 100))
            start.draw(screen, size=30)
            if not mine:
                draw_center(screen, "(pick your Pokemon first)", 20, (40, 40, 40), 812)
            else:
                draw_center(screen, "Students can still join after the raid starts.", 20, (40, 40, 40), 812)
        else:
            draw_center(screen, f"Waiting for {who_text(room.leader_mon())} to start the raid...", 28,
                        (20, 40, 90), 680)
            draw_center(screen, f"(If they leave, the next one in line takes over after {online.LEADER_SECONDS} seconds.)",
                        20, (40, 40, 40), 725)
        back.draw(screen)
        draw_note(screen, net)
        await frame(clock, fps)


# ==========================================
# 7. CLASS RAID: THE RAID
# ==========================================
async def raid_screen(screen, clock, fps, sounds, vfx, net, clk, room, api, level, game):
    """Plays one raid (Magikarp: watches it).
    Returns 'win', 'lose', 'reset' (the raid is really gone or was closed), 'left' (stopped watching) or 'quit'."""
    gid, me = game["id"], room.me
    mon = room.my_pick()
    watch = room.observer
    mode_name = online.mode_info(game.get("mode"))["name"]
    fighter = online.Fighter(mon, game.get("mode"))
    player = make_mon(mon, "me", vfx, "back")
    boss = make_mon(online.BOSS, "boss", vfx, "front")
    player.label_color = MY_NAME_COLOR
    player.watching = watch
    if watch:
        player.label = f"{online.OBSERVER} (Mr. Chung)"
    bg = load_image(online.RAID_BACKGROUND, (curr_w, ry(720)))
    tb = load_image("textbox.png", (curr_w, curr_h - ry(720)))
    grey = pygame.Surface((curr_w, ry(720)), pygame.SRCALPHA)
    grey.fill((140, 140, 140, 120))

    buttons = [Button(80, 795, 290, 60), Button(395, 795, 290, 60), Button(710, 795, 290, 60),
               Button(80, 865, 290, 60), Button(395, 865, 290, 60), Button(710, 865, 290, 60)]
    get_up_btn = berry_btn = buttons[5]          # 6th button: Sitrus Berry, or "Get up now" while fainted
    stop_btn = Button(850, 744, 140, 42, color=(200, 210, 215))     # where "Show Graph" sits for students
    stop_btn.text = "Stop watching"
    graph_button = Button(850, 744, 140, 42, color=(250, 215, 90))
    st = {"q": None, "panel": None, "graph_open": False, "result": None, "wipe": False, "told": False,
          "done_at": None, "game": game, "killed": False, "wipe_since": None}   # st["game"]: the raid as last read
    shown = {"d": 0, "h": 0}                     # my damage / Recover already shown in a message
    queue, cur = [], {"text": "", "since": 0}

    def add(text, fn=None):
        queue.append((text, fn))

    def busy():
        return bool(cur["text"]) or bool(queue)

    def effect_fn(target, effect):
        anims, snd = pokedex.EFFECTS.get(effect, pokedex.EFFECTS["hit"])
        return lambda: (target.trigger_vfx(anims), play_sound(sounds, snd))

    def show(events):
        """online.py's (text, kind, amount, effect) messages -> the message queue (animations run as each shows)."""
        for text, kind, amount, effect in events:
            fn = None
            if kind == "boss_hit":
                hit = effect_fn(boss, effect) if effect else (lambda: None)
                fn = (lambda a=amount, h=hit: (shown.__setitem__("d", shown["d"] + a), h()))
            elif kind == "boss_heal":
                fn = (lambda a=amount: (shown.__setitem__("h", shown["h"] + a), boss.trigger_vfx("heal"),
                                        play_sound(sounds, "heal")))
            elif kind == "boss_faint":
                st["killed"] = True                # my hit finished Mewtwo: no need to wait for a read
                fn = boss.play_faint_sound
            elif kind == "me_hit":
                hit = effect_fn(player, effect)
                fn = (lambda a=amount, h=hit: (setattr(player, "hp", max(0, player.hp - a)), h()))
            elif kind == "me_heal":
                fn = (lambda a=amount: (setattr(player, "hp", a), setattr(player, "fainted", False),
                                        player.trigger_vfx("heal"), play_sound(sounds, "heal")))
            elif kind == "faint":
                fn = player.play_faint_sound
            add(text, fn)

    def numbers(true=True):
        """(Mewtwo's HP, full HP).  true: with all my damage; else only what my messages have shown."""
        g = st["game"]
        mine = room.mine() or {"m": mon, "d": 0, "h": 0, "a": 0, "t": clk.now()}
        if not true:
            mine = dict(mine, d=shown["d"], h=shown["h"])
        return online.boss_numbers(g, me, mine)

    def new_question():
        q = api.raid_question(level)
        st["q"], st["graph_open"] = q, False
        st["panel"] = api.build_graph_panel(q.graph) if q.graph else None
        for i in range(5):
            buttons[i].text = q.options[i]

    def asking():
        return st["q"] is not None and not busy() and st["result"] is None

    def answer(btn):
        q = st["q"]
        ok = btn.text == q.correct
        hp, full = numbers()
        if ok:
            play_sound(sounds, "correct")
            add("Correct!")
        else:
            add("Incorrect!")
            add(f"The answer was:  {q.correct}")
        show(fighter.answer(ok, hp, full, clk.now()))
        room.send(gid, fighter)
        st["q"] = None

    def click(pos):
        if st["graph_open"]:                       # a click hides the table/graph...
            st["graph_open"] = False
            if not any(b.clicked(pos) for b in buttons[:5]):
                return None                        # ...and a click on an answer also answers
        if busy():
            cur["text"] = ""
            return None
        if st["result"] is not None and st["done_at"] is not None:
            return "done"
        if watch:
            if st["result"] is None and stop_btn.clicked(pos):
                click_sound(sounds)
                return "stop"
            return None
        if not asking():
            return None
        if st["panel"] is not None and graph_button.clicked(pos):
            click_sound(sounds)
            st["graph_open"] = True
            return None
        if fighter.can_get_up() and get_up_btn.clicked(pos):
            click_sound(sounds)
            show(fighter.get_up())
            room.send(gid, fighter)
            return None
        if not fighter.fainted and berry_btn.clicked(pos):         # Sitrus Berry (uses this question)
            click_sound(sounds)
            if fighter.berries <= 0:
                add("You are out of Berries!")
            elif fighter.hp >= fighter.max_hp:
                add("Your HP is already full!")
            else:
                show(fighter.eat_berry())
                room.send(gid, fighter)
                st["q"] = None                     # a new question after Mewtwo's turn
            return None
        for btn in buttons[:5]:
            if btn.clicked(pos):
                click_sound(sounds)
                answer(btn)
                return None
        return None

    room.send(gid, fighter)                        # in the raid right away (Magikarp too: it keeps the raid open)
    sounds["music_pool"] = []
    play_raid_music()
    if watch:
        add(f"You are watching the raid as {online.OBSERVER}.")
    elif clk.now() - game["start"] > 20000:
        add(f"You joined the raid! The class is battling {online.BOSS}!")
    else:
        add(f"The raid begins! Everyone is battling {online.BOSS}!")
    if not watch:
        add(f"Go, {mon}!")

    while True:
        net.update()
        room.update()
        now = clk.now()
        g = room.game_by_id(gid)
        if g is None and room.gone(gid) and st["result"] is None:
            stop_music(sounds)                     # really gone (missing from several good reads in a row)
            return "reset"
        g = st["game"] = g or st["game"]
        hp_true, full = numbers()
        left = online.time_left_ms(g, now)
        fresh = room.fresh()

        # ----- won or lost? (decisions that depend on everyone's numbers need a fresh read) -----
        if st["result"] is None:
            over = g.get("over")
            res = None
            if over in ("win", "lose"):
                res = over
            elif over in ("left", "dup"):          # closed (nobody was in it for a while, or an extra Start)
                stop_music(sounds)
                return "reset"
            elif st["killed"] or (hp_true <= 0 and fresh):
                res = "win"
            elif left <= 0:
                res = "lose"
            if fresh and online.all_fainted(g, now, me, room.mine()):
                st["wipe_since"] = st["wipe_since"] if st["wipe_since"] is not None else now
            else:
                st["wipe_since"] = None
            if res is None and st["wipe_since"] is not None and now - st["wipe_since"] >= online.WIPE_MS:
                res = "lose"                       # everyone is fainted at the same time (and it held)
            if res in ("win", "lose"):
                st["result"] = res
                st["wipe"] = res == "lose" and left > 0
                st["q"], st["graph_open"] = None, False
                room.end(gid, res)
        if st["result"] is not None and not busy() and not st["told"]:
            st["told"] = True
            if st["result"] == "win":
                if not boss.fainted:
                    boss.play_faint_sound()
                    add(f"{online.BOSS} fainted!")
                add("Your class won the raid!")
            elif st["wipe"]:
                add(f"Everyone has fainted! {online.BOSS} wins this time.")
                add("The class lost the raid.")
            else:
                add(f"Time's up! {online.BOSS} is still standing.")
                add("The class lost the raid.")
        if st["told"] and not busy() and st["done_at"] is None:
            st["done_at"] = pygame.time.get_ticks()

        # ----- messages move on by themselves (a click skips ahead) -----
        if not cur["text"] and queue:
            text, fn = queue.pop(0)
            cur["text"], cur["since"] = text, pygame.time.get_ticks()
            if fn:
                fn()
        elif cur["text"] and pygame.time.get_ticks() - cur["since"] > MSG_MS:
            cur["text"] = ""

        if not watch and st["result"] is None and not busy() and st["q"] is None and not fighter.resting(now):
            new_question()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return "quit"
            if event.type == MUSIC_END_EVENT:
                play_raid_music()
            if event.type == pygame.MOUSEBUTTONDOWN:
                c = click(event.pos)
                if c == "done":
                    stop_music(sounds)
                    return st["result"]
                if c == "stop":
                    stop_music(sounds)
                    return "left"
            elif event.type == pygame.KEYDOWN and st["graph_open"]:
                st["graph_open"] = False

        # ---------- draw ----------
        screen.fill((0, 0, 0))
        if bg:
            screen.blit(bg, (0, 0))
        pygame.draw.rect(screen, (75, 117, 155), (0, ry(720), curr_w, curr_h - ry(720)))
        if tb:
            screen.blit(tb, (0, ry(720)))
        boss.draw(screen)
        player.draw(screen)
        if player.fainted:                         # fainted: a slightly grey screen
            screen.blit(grey, (0, 0))
            draw_center(screen, f"{mon} fainted!", 44, (255, 255, 255), 300)
            if fighter.resting(now):
                draw_center(screen, f"Catch your breath: a new question in {fmt_clock(fighter.rest_until - now)}",
                            28, (255, 255, 255), 360)
            elif fighter.fainted:
                draw_center(screen, f"Each right answer = 20% HP when you get up.   Now: {fighter.revive * 20}%",
                            26, (255, 255, 255), 360)
                draw_center(screen, "5 right = back to 100%.   A wrong answer now gets you up right away."
                            if fighter.revive else "5 right = back to 100%.   A wrong answer now = 1 minute rest.",
                            22, (235, 235, 235), 400)
        shown_hp, _ = numbers(true=False)
        draw_boss_bar(screen, 0 if st["result"] == "win" else (hp_true if watch else shown_hp), full, left,
                      mode_name, online.team_counts(g, now, me, room.mine()))
        if st["graph_open"] and st["panel"] is not None and asking():
            api.draw_graph_overlay(screen, st["panel"])           # the table / graph over the battle area

        if cur["text"]:
            draw_lines(screen, cur["text"], (255, 255, 255), 85, 768, 905)
        elif st["done_at"] is not None:
            draw_lines(screen, "Click anywhere to see the ranking.", (0, 0, 0), 80, 765, 920)
        elif watch:
            top = online.ranking(g, me, room.mine(), n=6)
            if top:
                cells = [f"{i + 1}. {name}" for i, (name, _) in enumerate(top)]
                draw_lines(screen, "Top raiders right now:   " + "    ".join(cells[:3]) +
                           ("\n" + "    ".join(cells[3:]) if len(cells) > 3 else ""),
                           (255, 255, 255), 85, 768, 755)          # the usual message spot
            else:
                draw_lines(screen, "Waiting for the first hit...", (255, 255, 255), 85, 768, 755)
            stop_btn.draw(screen, size=20)
        elif asking():
            q = st["q"]
            has_graph = st["panel"] is not None
            draw_lines(screen, q.text, (255, 255, 255), 85, 760, 755 if has_graph else 905)
            for btn in buttons[:5]:
                btn.draw(screen)
            if fighter.can_get_up():
                get_up_btn.text = f"Get up now ({fighter.revive * 20}% HP)"
                get_up_btn.color = (250, 215, 90)
                get_up_btn.draw(screen)
            elif not fighter.fainted:
                berry_btn.text = f"Sitrus Berry x{fighter.berries}"
                berry_btn.color = (150, 200, 200)
                berry_btn.draw(screen)
            if has_graph:
                graph_button.text = graph_label(q, st["graph_open"])
                graph_button.draw(screen)
        elif fighter.resting(now):
            draw_lines(screen, f"New question in {fmt_clock(fighter.rest_until - now)}...", (255, 255, 255),
                       85, 768, 905)
        note = "Slow connection: reconnecting... (your hits are saved and will be sent)" if room.slow() else ""
        draw_note(screen, net, note)
        await frame(clock, fps)


async def end_screen(screen, clock, fps, sounds, net, room, gid, result):
    """Top 10 (net damage, Pokemon only, "#2" when two or more picked the same one).
    Click (after a short delay) to go back."""
    start = pygame.time.get_ticks()
    mon = room.my_pick()
    won = result == "win"
    last = {"id": gid, "mode": online.DEFAULT_MODE, "start": 0}
    if won:
        play_sound(sounds, "correct")
    while True:
        net.update()
        room.update()                              # the last few totals still come in
        ready = pygame.time.get_ticks() - start > 2000
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return "quit"
            if event.type == pygame.MOUSEBUTTONDOWN and ready:
                click_sound(sounds)
                return None
        g = room.game_by_id(gid) or last
        last = g
        top = online.ranking(g, room.me, room.mine())
        my_label = online.labels(g, room.me, room.mine()).get(room.me, mon)
        screen.fill((150, 115, 20) if won else (40, 70, 120))
        draw_center(screen, f"{online.BOSS} was defeated!" if won else f"{online.BOSS} was too strong this time.",
                    44, (255, 255, 255), 70)
        draw_center(screen, "Top 10 raiders", 30, (255, 255, 255), 135)
        box = pygame.Rect(rx(190), ry(170), rx(700), ry(560))
        pygame.draw.rect(screen, (255, 255, 255), box)
        pygame.draw.rect(screen, (0, 0, 0), box, max(1, rs(4)))
        for i, (name, pid) in enumerate(top):
            x = 330 + (i // 5) * 340
            y = 225 + (i % 5) * 100
            me_row = pid == room.me
            if me_row:
                pygame.draw.rect(screen, (255, 225, 120), (rx(x - 120), ry(y - 32), rx(320), ry(64)))
            text = f"{i + 1}.  {name}"
            draw_center(screen, text, fit_size(text, 34 if i < 3 else 30, 300),
                        (120, 80, 0) if me_row else (0, 0, 0), y, base_x=x + 40)
        if not top:
            draw_center(screen, "Nobody landed a hit this time.", 28, (0, 0, 0), 450)
        if room.observer:
            line = "Thanks for watching!"
        elif any(pid == room.me for _, pid in top):
            line = f"{my_label} made the top 10. Great raiding!"
        else:
            line = f"{my_label} wasn't in the top 10 this time. Every hit helped!"
        draw_center(screen, line, 26, (255, 255, 255), 780)
        if ready:
            draw_center(screen, "Click anywhere to go back to the topics.", 24, (230, 230, 230), 860)
        await frame(clock, fps)


# ==========================================
# 8. CLASS RAID: THE WHOLE MODE  (called from main.py)
# ==========================================
async def raid_mode(screen, clock, fps, sounds, vfx, api):
    """Returns None (back to the start screen) or 'quit'."""
    if not online.FIREBASE_URL:
        return await message_screen(screen, clock, fps, ["Class Raid isn't set up yet.",
                                                         "Add the Firebase database URL at the top of online.py."])
    try:
        net = online.Net(online.FIREBASE_URL, online.make_transport())
    except Exception:
        return await message_screen(screen, clock, fps, ["Class Raid can't connect from this browser."])
    clk = online.Clock()
    me = online.new_id()
    sync = online.ClockSync(net, clk, me)
    board = online.LiveBoard(net, clk)             # which topics are LIVE
    note = ""
    teacher = False                                # Mr. Chung's PIN: watch as Magikarp (until the game is closed)
    while True:
        k = await raid_topic_screen(screen, clock, fps, sounds, net, sync, board, api, note, teacher)
        if k in (None, "quit"):
            stop_music(sounds)
            return k
        note = ""
        if k == "teacher":
            if teacher:
                teacher = False                    # the button turns teacher mode off again
                continue
            ok = await pin_screen(screen, clock, fps, sounds)
            if ok == "quit":
                return "quit"
            teacher = ok is True
            continue
        room = online.Room(net, clk, k, me, observer=teacher)          # review k's room (r1 ... r6)
        game = await lobby_screen(screen, clock, fps, sounds, net, room, api.raid_title(k))
        if game == "quit":
            return "quit"
        if game is None:
            continue
        result = await raid_screen(screen, clock, fps, sounds, vfx, net, clk, room, api, k, game)
        if result == "quit":
            room.leave()
            return "quit"
        if result in ("reset", "left"):
            room.leave()
            if result == "reset":
                note = "That raid was closed. Pick a topic to play again."
            continue
        r = await end_screen(screen, clock, fps, sounds, net, room, game["id"], result)
        room.leave()
        if r == "quit":
            return "quit"
