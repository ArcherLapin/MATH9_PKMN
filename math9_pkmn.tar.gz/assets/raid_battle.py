# ==========================================
# raid_battle.py  -  Class Raid screens for Mr. Chung's Pokemon Math Battle (Math 9).
#   Pick a unit review (6 rooms, one each) -> pick a Pokemon -> the first student in the room
#   picks Easy / Medium / Hard and presses Start -> everyone battles the same Mewtwo
#   -> the class wins (Mewtwo faints) or loses (30 minutes run out, or everyone fainted) -> top 10.
#   No completion code.
#
#   The rules, numbers and the database part: raid_net.py.   Which Pokemon can be picked:
#   every pokedex.py entry with an "attack" (except Mewtwo).
#   This file: the unit reviews, and where things go on screen.
#   Nothing in single player or Team Battle uses this file.  To take Class Raid out of
#   the game, delete raid_battle.py, raid_net.py and raid_test.py.
# ==========================================
import asyncio
import random

import pygame

import pokedex
import raid_net as rn
import team_net as tn
import q_rational
import q_exponents
import q_polynomials
import q_basiceq
import q_equations
import q_linear
from main_tool import (
    rx, ry, rs, curr_w, curr_h,
    resource_path, render_rich, fit_size, draw_center, draw_lines,
    Pokemon, Button, MUSIC_END_EVENT, build_visual_surface, draw_visual_overlay,
)

# ---------- The unit reviews: one room each ----------
#   (room number, button text, (question file, its topic numbers))  -  or None instead = "Coming soon"
#   A review question is a random topic of that file (never the same question twice in a visit).
#   Never give a review a room number another review used before (rooms remember old raids).
REVIEWS = [
    (1, "Rational Numbers",     (q_rational, [1, 2, 3, 4])),             # Week 1
    (2, "Exponents",            (q_exponents, [1, 2, 3, 4])),            # Weeks 2-3
    (3, "Polynomials",          (q_polynomials, [1, 2, 3, 4])),          # Weeks 4-5
    (4, "Equations",            (q_basiceq, [1, 2, 3])),                 # Week 6
    (5, "Multistep Equations",  (q_equations, [1, 2, 3, 4])),            # Week 7
    (6, "Linear Equations",     (q_linear, [1, 2, 3, 4, 5, 6, 7])),      # Week 8
]

# ---------- Where things go  (ALL raid sizes and positions are here) ----------
# Screen = 1080 x 950 base pixels; the battle area is y = 0 to 720 (the text box is below).
# x goes right, y goes DOWN.  These spots are the raid's own: changing them never moves
# anything in single player or Team Battle.
#
#   anchor = (x, y) of the point under the Pokemon's feet   (bigger y = lower on the screen)
#   size   = (height, width): Mewtwo is fitted into this box (smaller numbers = smaller Mewtwo)
#   scale  = zoom on the student's GIF (0.6 = 60% of its real size)
#   box    = (x, y) of the top-left corner of your name / HP box (single player's style; Mewtwo uses BOSS_BAR)
#   panel  = True: a see-through grey box around your name and HP;  False: no box (exactly like single player)
SPOTS = {
    "boss": dict(anchor=(825, 500), size=(330, 330), box=(36, 24), panel=True),
    "me":   dict(anchor=(250, 682), scale=0.62, box=(720, 592), panel=True),
}
# One Pokemon only (raid only): bigger/smaller and moved.  The "scale" and "shift" in pokedex.py
# are for the other modes; the raid keeps pokedex's "scale" but ignores its "shift".
#   e.g.  "Magikarp": {"scale": 0.8, "shift": (20, -10)},     shift = (right, down) in pixels
TWEAKS = {
}
# Hit animations (the effect played ON a Pokemon when it is hit or heals):
#   scale = size of the animations (1.0 = same as single player)
#   shift = (right, down) in pixels from where they normally play
#     (lightning / leaf effects come down onto the feet; the others play on the middle of the Pokemon)
FX = {
    "boss": dict(scale=1.0, shift=(0, 0)),     # on Mewtwo (your attacks, its Recover)
    "me":   dict(scale=0.8, shift=(0, 0)),     # on your Pokemon (Mewtwo's attacks, getting up)
}
# One animation only, moved (right, down) on every Pokemon.  Names: "hit", "heal", "firepunch" (fire:
# Flamethrower, Fire Punch...), "hydropump" (water), "thunderbolt" (bolt), "thunder", "leaftornado".
FX_SHIFT_BY_EFFECT = {
    "firepunch": (0, -50),                     # fire effects 50 higher
}
BOSS_BAR = (40, 14, 1000, 92)                  # Mewtwo's long HP bar with the clock: x, y, width, height
MY_NAME_COLOR = (255, 255, 255)                # your name in your HP box (white, like single player)
MSG_MS = 1500                                  # each message shows this long (a click skips ahead)


# ==========================================
# 1. SMALL HELPERS
# ==========================================
async def frame(clock, fps):
    pygame.display.update()
    await asyncio.sleep(0)
    clock.tick(fps)


def click_sound(sounds):
    if sounds.get("click"):
        sounds["click"].play()


def play_sound(sounds, name):
    if name and sounds.get(name):
        sounds[name].play()


def draw_note(screen, net, text=""):
    if net is not None and net.errors >= 3:
        text = "Can't reach the raid server. Check the internet connection (retrying...)."
    if text:
        draw_center(screen, text, 22, (150, 20, 20), 905)


def load_image(name, size):
    try:
        return pygame.transform.scale(pygame.image.load(resource_path(name)), size)
    except (pygame.error, FileNotFoundError, OSError):
        return None


def play_raid_music():
    """Usually a raid track, sometimes one of the other battle tracks.  A missing file is skipped."""
    first = rn.RAID_MUSIC if random.randint(1, 100) <= rn.RAID_MUSIC_CHANCE else rn.OTHER_MUSIC
    rest = rn.OTHER_MUSIC if first is rn.RAID_MUSIC else rn.RAID_MUSIC
    for f in random.sample(first, len(first)) + random.sample(rest, len(rest)):
        try:
            pygame.mixer.music.load(resource_path(f))
            pygame.mixer.music.set_volume(0.15)
            pygame.mixer.music.play(0)
            return
        except (pygame.error, FileNotFoundError, OSError):
            continue
    try:
        pygame.mixer.music.stop()
    except pygame.error:
        pass


def stop_music(sounds):
    sounds["music_pool"] = []                 # the start screen doesn't restart raid music
    try:
        pygame.mixer.music.stop()
    except pygame.error:
        pass


def raid_spot(name, base):
    """The raid's spot for one Pokemon: cancels its Team Battle "shift", adds TWEAKS."""
    e, tw = pokedex.info(name), TWEAKS.get(name, {})
    dx, dy = e.get("shift", (0, 0))
    tx, ty = tw.get("shift", (0, 0))
    spot = dict(base, anchor=(base["anchor"][0] - dx + tx, base["anchor"][1] - dy + ty))
    k = tw.get("scale", 1)
    if "scale" in spot:
        spot["scale"] = spot["scale"] * k
    else:
        spot["size"] = (int(spot["size"][0] * k), int(spot["size"][1] * k))
    return spot


class RaidMon(Pokemon):
    """A Pokemon drawn like in the other modes, with its hit animations moved by FX[...]["shift"]."""
    fx_shift = (0, 0)

    def draw(self, surface, active=False):
        if not self.fainted:
            self.idle.draw(surface, self.img_x, self.img_y)
        dx, dy = self.fx_shift
        for key, anim in self.animations.items():
            if not anim.is_playing or not anim.original_frames:
                continue
            w, h = anim.original_frames[0].get_size()
            ex, ey = FX_SHIFT_BY_EFFECT.get(key, (0, 0))
            if key in self.FX_FROM_SKY:                       # comes down onto the feet
                anim.draw(surface, self.ax - w / 2 + dx + ex, self.ay - h + dy + ey)
            else:                                             # on the middle of the Pokemon
                anim.draw(surface, self.cx - w / 2 + dx + ex, self.cy - h / 2 + dy + ey)
        self.draw_hp_box(surface, active)

    def draw_hp_box(self, surface, active=False):
        """Single player's name / HP bar (same sizes and colours), with the grey box around it if panel."""
        x, y, w = self.bx, self.by, 300
        grey = (170, 170, 170)
        if self.panel:
            r = pygame.Rect(rx(x - 12), ry(y - 8), rx(w + 24), ry(104))
            bg = pygame.Surface(r.size, pygame.SRCALPHA)
            bg.fill((0, 0, 0, 110))
            surface.blit(bg, r.topleft)
        s = render_rich(self.label, fit_size(self.label, 26, w), grey if self.fainted else self.label_color)
        surface.blit(s, (rx(x), ry(y)))
        ratio = max(0, self.hp / self.max_hp)
        pygame.draw.rect(surface, (255, 0, 0), (rx(x), ry(y + 40), rx(w), ry(12)))
        pygame.draw.rect(surface, (0, 255, 0), (rx(x), ry(y + 40), rx(w * ratio), ry(12)))
        hp_text = "Fainted" if self.fainted else f"HP: {int(self.hp)} / {int(self.max_hp)}"
        s = render_rich(hp_text, 26, grey if self.fainted else (255, 255, 255))
        surface.blit(s, (rx(x), ry(y + 60)))


class BossMon(RaidMon):
    """Mewtwo: its HP is the long bar at the top (draw_boss_bar), not a box."""
    def draw_hp_box(self, surface, active=False):
        pass


def make_mon(name, place, vfx, view):
    mon = (BossMon if place == "boss" else RaidMon)(name, rn.PLAYER_HP, rn.PLAYER_HP, 100, 100, vfx, view=view,
                                                    spot=raid_spot(name, SPOTS[place]), vfx_scale=FX[place]["scale"])
    mon.fx_shift = FX[place]["shift"]
    return mon


def fmt_clock(ms):
    s = int((ms + 999) // 1000)
    return f"{s // 60}:{s % 60:02d}"


def draw_boss_bar(screen, hp, full, left_ms, mode_name):
    """Mewtwo's name, the long HP bar and the clock, across the top."""
    bx, by, bw, bh = BOSS_BAR
    r = pygame.Rect(rx(bx), ry(by), rx(bw), ry(bh))
    bg = pygame.Surface(r.size, pygame.SRCALPHA)
    bg.fill((0, 0, 0, 140))
    screen.blit(bg, r.topleft)
    x, y, w = bx + 18, by + 8, bw - 36
    s = render_rich(f"{rn.BOSS}   ({mode_name})", 28, (255, 225, 120))
    screen.blit(s, (rx(x), ry(y)))
    t = render_rich(f"Time left  {fmt_clock(left_ms)}", 26, (255, 120, 120) if left_ms <= 60000 else (255, 255, 255))
    screen.blit(t, t.get_rect(topright=(rx(x + w), ry(y + 2))))
    ratio = 0 if full <= 0 else max(0, min(1, hp / full))
    col = (0, 210, 0) if ratio > 0.5 else (240, 200, 0) if ratio > 0.2 else (230, 40, 30)
    pygame.draw.rect(screen, (90, 0, 0), (rx(x), ry(y + 40), rx(w), ry(18)))
    pygame.draw.rect(screen, col, (rx(x), ry(y + 40), rx(w * ratio), ry(18)))
    pygame.draw.rect(screen, (0, 0, 0), (rx(x), ry(y + 40), rx(w), ry(18)), max(1, rs(2)))
    h = render_rich(f"HP: {int(hp):,} / {int(full):,}", 20, (255, 255, 255))
    screen.blit(h, (rx(x), ry(y + 61)))


# ---------- Pokemon icons for the pick screen (first frame of the front sprite, cropped) ----------
_icons = {}


def _load_icon(mon, size):
    n = pokedex.info(mon).get("folder")
    img = None
    for name in (f"pokemon{n}/pokemon{n}_front (1).gif", f"pokemon{n}/pokemon{n}_back (1).gif",
                 f"pokemon{n}/pokemon_{n} (1).gif"):
        try:
            img = pygame.image.load(resource_path(name))
            break
        except (pygame.error, FileNotFoundError, OSError):
            continue
    if img is None:
        return False
    bb = img.get_bounding_rect()
    if bb.w < 4 or bb.h < 4:
        bb = img.get_rect()
    img = img.subsurface(bb).copy()
    try:
        img = img.convert_alpha()
    except pygame.error:
        pass
    k = min(size / bb.w, size / bb.h)
    img = pygame.transform.scale(img, (max(1, int(bb.w * k)), max(1, int(bb.h * k))))
    dim = img.copy()                                   # the greyed-out one, for a Pokemon already taken
    try:
        dim.fill((110, 110, 110, 255), special_flags=pygame.BLEND_RGBA_MULT)
    except pygame.error:
        pass
    return img, dim


def icon(mon, size, budget, taken=False):
    """The icon (or None while it isn't loaded yet; budget[0] = how many may load this frame)."""
    key = (mon, size)
    if key not in _icons:
        if budget[0] <= 0:
            return None
        budget[0] -= 1
        _icons[key] = _load_icon(mon, rs(size))
    v = _icons[key]
    return (v[1] if taken else v[0]) if v else None


# ==========================================
# 2. QUESTIONS (a random topic of the review; no repeats during this visit)
# ==========================================
class RaidQuestion:
    def __init__(self, text, correct, options, visual):
        self.text, self.correct, self.options, self.visual = text, correct, options, visual
        self.kind = ("Graph" if visual and any(k in visual for k in ("graph", "grid", "bars", "lgraph", "pics"))
                     else "Table" if visual and "table" in visual else "Info")


_seen = {}


def next_question(k):
    source = next(r[2] for r in REVIEWS if r[0] == k)
    maker, topics = source
    seen = _seen.setdefault(k, set())
    q = None
    for _ in range(300):
        try:
            text, correct, options, visual = maker.make_question(random.choice(topics))
        except RuntimeError:
            continue
        options = list(options)
        if correct not in options or len(options) != 5 or len(set(options)) != 5:
            continue
        q = RaidQuestion(text, correct, options, visual or None)
        key = (text, correct, repr(visual))
        if key not in seen:
            seen.add(key)
            return q
    seen.clear()
    return q


def review_title(k):
    return next((r[1] for r in REVIEWS if r[0] == k), "Class Raid")


# ==========================================
# 3. SCREENS: pick a review, the lobby
# ==========================================
async def message_screen(screen, clock, fps, lines):
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return "quit"
            if event.type == pygame.MOUSEBUTTONDOWN:
                return None
        screen.fill((128, 128, 128))
        for i, line in enumerate(lines):
            draw_center(screen, line, 30 if i == 0 else 24, (0, 0, 0), 300 + i * 55)
        draw_center(screen, "Click anywhere to go back.", 22, (40, 40, 40), 800)
        await frame(clock, fps)


async def review_screen(screen, clock, fps, sounds, net, sync, note=""):
    """Returns a room number, None (Back) or 'quit'."""
    buttons = []
    for i, (k, title, source) in enumerate(REVIEWS):
        b = Button(120 + (i % 2) * 440, 200 + (i // 2) * 95, 400, 75)
        b.k, b.title, b.ready = k, title, source is not None
        buttons.append(b)
    back = Button(40, 860, 160, 60)
    back.text = "Back"
    while True:
        net.update()
        connected = sync.update()                       # the clock is lined up with the server
        for b in buttons:
            b.open = b.ready and connected
            b.text = b.title if b.ready else f"{b.title}  (Coming soon)"
            b.color, b.text_color = ((150, 200, 200), (0, 0, 0)) if b.open else ((170, 170, 170), (100, 100, 100))

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return "quit"
            if event.type == pygame.MOUSEBUTTONDOWN:
                if back.clicked(event.pos):
                    click_sound(sounds)
                    return None
                for b in buttons:
                    if b.clicked(event.pos) and b.open:
                        click_sound(sounds)
                        return b.k

        screen.fill((128, 128, 128))
        draw_center(screen, "Class Raid: pick a unit review", 46, (0, 0, 0), 50)
        draw_center(screen, f"The whole class battles {rn.BOSS} together. Each right answer is a hit!",
                    26, (20, 40, 90), 105)
        draw_center(screen, f"Beat {rn.BOSS} within {rn.RAID_MINUTES} minutes. If everyone faints at once, the class loses!",
                    22, (20, 40, 90), 145)
        for b in buttons:
            b.draw(screen)
        draw_center(screen, "Join a room, pick your Pokemon, and wait for the first student to press Start.",
                    22, (40, 40, 40), 590)
        back.draw(screen)
        draw_note(screen, net, note)
        await frame(clock, fps)


TILE_TOP, TILE_H, TILE_GAP = 120, 128, 10


def tile_rects(n):
    cols = 8 if n <= 24 else 10
    w = (1000 - TILE_GAP * (cols - 1)) / cols
    return [pygame.Rect(40 + (i % cols) * (w + TILE_GAP), TILE_TOP + (i // cols) * (TILE_H + TILE_GAP), w, TILE_H)
            for i in range(n)]


async def lobby_screen(screen, clock, fps, sounds, net, room, k):
    """Pick a Pokemon; the first student picks the difficulty and starts.
    Returns the game (a raid to join), None (Back) or 'quit'."""
    mons = rn.roster()
    rects = tile_rects(len(mons))
    mode = rn.DEFAULT_MODE
    mode_btns = []
    for i, m in enumerate(rn.MODE_ORDER):
        b = Button(255 + i * 195, 640, 180, 60)
        b.mode, b.text = m, rn.MODES[m]["name"]
        mode_btns.append(b)
    start = Button(390, 725, 300, 70)
    start.text = "Start the raid!"
    back = Button(40, 860, 160, 60)
    back.text = "Back"
    lost_since, lost_name = 0, ""
    title = review_title(k)
    while True:
        net.update()
        room.update()
        if room.lost:
            lost_since, lost_name, room.lost = pygame.time.get_ticks(), room.lost, None
        mine = room.my_pick()
        game = room.game()
        if game is not None and mine:
            return game
        lead = room.is_leader()
        owners = room.taken()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                room.leave()
                return "quit"
            if event.type != pygame.MOUSEBUTTONDOWN:
                continue
            if back.clicked(event.pos):
                click_sound(sounds)
                room.leave()
                return None
            if not room.loaded:
                continue
            for m, r in zip(mons, rects):
                if pygame.Rect(rx(r.x), ry(r.y), rx(r.w), ry(r.h)).collidepoint(event.pos):
                    if owners.get(m) in (None, room.me):
                        click_sound(sounds)
                        room.pick(m)
            if lead and game is None:
                for b in mode_btns:
                    if b.clicked(event.pos):
                        click_sound(sounds)
                        mode = b.mode
                if start.clicked(event.pos) and mine:
                    click_sound(sounds)
                    room.start(mode)

        # ---------- draw ----------
        screen.fill((128, 128, 128))
        draw_center(screen, f"Class Raid  -  {title}", 40, (0, 0, 0), 40)
        draw_center(screen, "Pick your Pokemon (one student each):", 26, (20, 40, 90), 92)
        budget = [3]                                    # load a few icons per frame (no freeze)
        for m, r in zip(mons, rects):
            box = pygame.Rect(rx(r.x), ry(r.y), rx(r.w), ry(r.h))
            owner = owners.get(m)
            if m == room.mon:
                fill = (250, 225, 120) if mine else (225, 225, 200)
            else:
                fill = (230, 235, 240) if owner is None else (150, 150, 150)
            pygame.draw.rect(screen, fill, box)
            pygame.draw.rect(screen, (0, 0, 0), box, max(1, rs(4 if m == room.mon else 2)))
            img = icon(m, 82, budget, taken=owner not in (None, room.me))
            if img is not None:
                screen.blit(img, img.get_rect(center=(box.centerx, box.y + ry(52))))
            label = m if owner in (None, room.me) else "Taken"
            col = (0, 0, 0) if owner in (None, room.me) else (60, 60, 60)
            s = render_rich(label, fit_size(label, 18, int(r.w) - 8), col)
            screen.blit(s, s.get_rect(center=(box.centerx, box.bottom - ry(14))))

        here = len(room.who())
        y = TILE_TOP + 3 * (TILE_H + TILE_GAP) + 20
        if not room.loaded:
            draw_center(screen, "Connecting...", 26, (0, 0, 0), y)
        elif room.mon and not mine:
            draw_center(screen, f"Checking {room.mon}...", 26, (0, 0, 0), y)
        elif mine:
            draw_center(screen, f"You are {mine}!   ({here} in this room)", 28, (0, 0, 0), y)
        else:
            draw_center(screen, f"Click a Pokemon to pick it.   ({here} in this room)", 26, (0, 0, 0), y)
        if pygame.time.get_ticks() - lost_since < 4000 and lost_name:
            draw_center(screen, f"Someone picked {lost_name} first. Pick another one!", 24, (150, 20, 20), y + 38)

        if not room.loaded:
            pass                                        # still connecting: nothing to show yet
        elif game is not None:
            draw_center(screen, "A raid is going on! Pick a Pokemon to jump in.", 28, (20, 40, 90), 680)
        elif lead:
            draw_center(screen, "You are first in the room: choose the difficulty, then press Start", 24,
                        (20, 40, 90), 612)
            for b in mode_btns:
                on = b.mode == mode
                b.color, b.text_color = ((250, 215, 90), (0, 0, 0)) if on else ((200, 210, 215), (0, 0, 0))
                b.draw(screen, size=26)
            start.color, start.text_color = ((150, 200, 200), (0, 0, 0)) if mine else ((170, 170, 170), (100, 100, 100))
            start.draw(screen, size=30)
            if not mine:
                draw_center(screen, "(pick your Pokemon first)", 20, (40, 40, 40), 812)
            else:
                draw_center(screen, "Students can still join after the raid starts.", 20, (40, 40, 40), 812)
        else:
            who = room.leader_mon()
            draw_center(screen, f"Waiting for {who or 'the first student'} to start the raid...", 28,
                        (20, 40, 90), 680)
        back.draw(screen)
        draw_note(screen, net)
        await frame(clock, fps)


# ==========================================
# 4. THE RAID
# ==========================================
async def raid_screen(screen, clock, fps, sounds, vfx, net, clk, room, k, game):
    """Plays one raid.  Returns 'win', 'lose', 'reset' (the raid vanished) or 'quit'."""
    gid, me = game["id"], room.me
    mon = room.my_pick()
    mode_name = rn.mode_info(game.get("mode"))["name"]
    fighter = rn.Fighter(mon, game.get("mode"))
    player = make_mon(mon, "me", vfx, "back")
    boss = make_mon(rn.BOSS, "boss", vfx, "front")
    player.label_color = MY_NAME_COLOR
    bg = load_image(rn.RAID_BACKGROUND, (curr_w, ry(720)))
    tb = load_image("textbox.png", (curr_w, curr_h - ry(720)))
    grey = pygame.Surface((curr_w, ry(720)), pygame.SRCALPHA)
    grey.fill((140, 140, 140, 120))

    buttons = [Button(80, 795, 290, 60), Button(395, 795, 290, 60), Button(710, 795, 290, 60),
               Button(80, 865, 290, 60), Button(395, 865, 290, 60), Button(710, 865, 290, 60)]
    get_up_btn = buttons[5]
    graph_button = Button(850, 744, 140, 42, color=(250, 215, 90))
    st = {"q": None, "panel": None, "graph_open": False, "result": None, "wipe": False, "told": False,
          "done_at": None, "game": game}             # st["game"]: the raid as last read
    shown = {"d": 0, "h": 0}                     # my damage / Recover already shown in a message
    queue, cur = [], {"text": "", "since": 0}

    def add(text, fn=None):
        queue.append((text, fn))

    def busy():
        return bool(cur["text"]) or bool(queue)

    def effect_fn(target, effect):
        anims, snd = pokedex.EFFECTS.get(effect, pokedex.EFFECTS["hit"])
        return lambda: (target.trigger_vfx(anims), play_sound(sounds, snd))

    def show(events):
        """raid_net's (text, kind, amount, effect) messages -> the message queue (animations run as each shows)."""
        for text, kind, amount, effect in events:
            fn = None
            if kind == "boss_hit":
                hit = effect_fn(boss, effect) if effect else (lambda: None)
                fn = (lambda a=amount, h=hit: (shown.__setitem__("d", shown["d"] + a), h()))
            elif kind == "boss_heal":
                fn = (lambda a=amount: (shown.__setitem__("h", shown["h"] + a), boss.trigger_vfx("heal"),
                                        play_sound(sounds, "heal")))
            elif kind == "boss_faint":
                fn = boss.play_faint_sound
            elif kind == "me_hit":
                hit = effect_fn(player, effect)
                fn = (lambda a=amount, h=hit: (setattr(player, "hp", max(0, player.hp - a)), h()))
            elif kind == "me_heal":
                fn = (lambda a=amount: (setattr(player, "hp", a), setattr(player, "fainted", False),
                                        player.trigger_vfx("heal"), play_sound(sounds, "heal")))
            elif kind == "faint":
                fn = player.play_faint_sound
            add(text, fn)

    def numbers(true=True):
        """(Mewtwo's HP, full HP).  true: with all my damage; else only what my messages have shown."""
        g = st["game"]
        mine = room.mine() or {"m": mon, "g": gid, "d": 0, "h": 0, "a": 0, "t": clk.now()}
        if not true:
            mine = dict(mine, d=shown["d"], h=shown["h"])
        return rn.boss_numbers(g, me, mine)

    def new_question():
        q = next_question(k)
        st["q"], st["graph_open"] = q, False
        st["panel"] = build_visual_surface(q.visual) if q.visual else None
        for i in range(5):
            buttons[i].text = q.options[i]

    def asking():
        return st["q"] is not None and not busy() and st["result"] is None

    def answer(btn):
        q = st["q"]
        ok = btn.text == q.correct
        hp, full = numbers()
        if ok:
            play_sound(sounds, "correct")
            add("Correct!")
        else:
            add("Incorrect!")
            add(f"The answer was:  {q.correct}")
        show(fighter.answer(ok, hp, full, clk.now()))
        room.send(gid, fighter)
        st["q"] = None

    def click(pos):
        if st["graph_open"]:                       # a click hides the table/graph...
            st["graph_open"] = False
            if not any(b.clicked(pos) for b in buttons[:5]):
                return None                        # ...and a click on an answer also answers
        if busy():
            cur["text"] = ""
            return None
        if st["result"] is not None and st["done_at"] is not None:
            return "done"
        if not asking():
            return None
        if st["panel"] is not None and graph_button.clicked(pos):
            click_sound(sounds)
            st["graph_open"] = True
            return None
        if fighter.can_get_up() and get_up_btn.clicked(pos):
            click_sound(sounds)
            show(fighter.get_up())
            room.send(gid, fighter)
            return None
        for btn in buttons[:5]:
            if btn.clicked(pos):
                click_sound(sounds)
                answer(btn)
                return None
        return None

    sounds["music_pool"] = []
    play_raid_music()
    if clk.now() - game["start"] > 20000:
        add(f"You joined the raid! The class is battling {rn.BOSS}!")
    else:
        add(f"The raid begins! Everyone is battling {rn.BOSS}!")
    add(f"Go, {mon}!")

    while True:
        net.update()
        room.update()
        now = clk.now()
        g = room.game_by_id(gid)
        if g is None and room.loaded and st["result"] is None:
            stop_music(sounds)                     # the raid vanished (only if it isn't over: a new raid
            return "reset"                         # started after this one ended still shows the ranking)
        g = st["game"] = g or st["game"]
        hp_true, full = numbers()
        left = rn.time_left_ms(g, now)

        # ----- won or lost? -----
        if st["result"] is None:
            res = g.get("over") or ("win" if hp_true <= 0 else "lose" if left <= 0 else None)
            if res is None and rn.all_fainted(g, now, me, room.mine()):
                res = "lose"                       # everyone is fainted at the same time
            if res in ("win", "lose"):
                st["result"] = res
                st["wipe"] = res == "lose" and left > 0
                st["q"], st["graph_open"] = None, False
                room.end(gid, res)
        if st["result"] is not None and not busy() and not st["told"]:
            st["told"] = True
            if st["result"] == "win":
                if not boss.fainted:
                    boss.play_faint_sound()
                    add(f"{rn.BOSS} fainted!")
                add("Your class won the raid!")
            elif st["wipe"]:
                add(f"Everyone has fainted! {rn.BOSS} wins this time.")
                add("The class lost the raid.")
            else:
                add(f"Time's up! {rn.BOSS} is still standing.")
                add("The class lost the raid.")
        if st["told"] and not busy() and st["done_at"] is None:
            st["done_at"] = pygame.time.get_ticks()

        # ----- messages move on by themselves (a click skips ahead) -----
        if not cur["text"] and queue:
            text, fn = queue.pop(0)
            cur["text"], cur["since"] = text, pygame.time.get_ticks()
            if fn:
                fn()
        elif cur["text"] and pygame.time.get_ticks() - cur["since"] > MSG_MS:
            cur["text"] = ""

        if st["result"] is None and not busy() and st["q"] is None and not fighter.resting(now):
            new_question()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return "quit"
            if event.type == MUSIC_END_EVENT:
                play_raid_music()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if click(event.pos) == "done":
                    stop_music(sounds)
                    return st["result"]
            elif event.type == pygame.KEYDOWN and st["graph_open"]:
                st["graph_open"] = False

        # ---------- draw ----------
        screen.fill((0, 0, 0))
        if bg:
            screen.blit(bg, (0, 0))
        pygame.draw.rect(screen, (75, 117, 155), (0, ry(720), curr_w, curr_h - ry(720)))
        if tb:
            screen.blit(tb, (0, ry(720)))
        boss.draw(screen)
        player.draw(screen)
        if player.fainted:                         # fainted: a slightly grey screen
            screen.blit(grey, (0, 0))
            draw_center(screen, f"{mon} fainted!", 44, (255, 255, 255), 300)
            if fighter.resting(now):
                draw_center(screen, f"Catch your breath: a new question in {fmt_clock(fighter.rest_until - now)}",
                            28, (255, 255, 255), 360)
            elif fighter.fainted:
                draw_center(screen, f"Each right answer = 20% HP when you get up.   Now: {fighter.revive * 20}%",
                            26, (255, 255, 255), 360)
                draw_center(screen, "5 right = back to 100%.   A wrong answer now gets you up right away."
                            if fighter.revive else "5 right = back to 100%.   A wrong answer now = 1 minute rest.",
                            22, (235, 235, 235), 400)
        shown_hp, _ = numbers(true=False)
        draw_boss_bar(screen, 0 if st["result"] == "win" else shown_hp, full, left, mode_name)

        showing = st["graph_open"] and st["panel"] is not None and asking()
        if showing:
            draw_visual_overlay(screen, st["panel"])

        if cur["text"]:
            draw_lines(screen, cur["text"], (255, 255, 255), 85, 768, 905)
        elif st["done_at"] is not None:
            draw_lines(screen, "Click anywhere to see the ranking.", (0, 0, 0), 80, 765, 920)
        elif asking():
            q = st["q"]
            has_graph = st["panel"] is not None
            draw_lines(screen, q.text, (255, 255, 255), 85, 760, 755 if has_graph else 905)
            for btn in buttons[:5]:
                btn.draw(screen)
            if fighter.can_get_up():
                get_up_btn.text = f"Get up now ({fighter.revive * 20}% HP)"
                get_up_btn.color = (250, 215, 90)
                get_up_btn.draw(screen)
            if has_graph:
                graph_button.text = ("Hide " if st["graph_open"] else "Show ") + q.kind
                graph_button.draw(screen)
        elif fighter.resting(now):
            draw_lines(screen, f"New question in {fmt_clock(fighter.rest_until - now)}...", (255, 255, 255),
                       85, 768, 905)
        draw_note(screen, net)
        await frame(clock, fps)


async def end_screen(screen, clock, fps, sounds, net, room, gid, result):
    """Top 10 (net damage, names only).  Click (after a short delay) to go back."""
    start = pygame.time.get_ticks()
    mon = room.my_pick() or room.mon
    won = result == "win"
    last = {"id": gid, "mode": rn.DEFAULT_MODE}
    if won:
        play_sound(sounds, "correct")
    while True:
        net.update()
        room.update()                              # the last few totals still come in
        ready = pygame.time.get_ticks() - start > 2000
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return "quit"
            if event.type == pygame.MOUSEBUTTONDOWN and ready:
                click_sound(sounds)
                return None
        g = room.game_by_id(gid) or last          # (a new raid may already have replaced it)
        last = g
        top = rn.ranking(g, room.me, room.mine())
        screen.fill((150, 115, 20) if won else (40, 70, 120))
        draw_center(screen, f"{rn.BOSS} was defeated!" if won else f"{rn.BOSS} was too strong this time.",
                    44, (255, 255, 255), 70)
        draw_center(screen, "Top 10 raiders", 30, (255, 255, 255), 135)
        box = pygame.Rect(rx(190), ry(170), rx(700), ry(560))
        pygame.draw.rect(screen, (255, 255, 255), box)
        pygame.draw.rect(screen, (0, 0, 0), box, max(1, rs(4)))
        for i, name in enumerate(top):
            x = 330 + (i // 5) * 340
            y = 225 + (i % 5) * 100
            me_row = name == mon
            if me_row:
                pygame.draw.rect(screen, (255, 225, 120), (rx(x - 120), ry(y - 32), rx(320), ry(64)))
            draw_center(screen, f"{i + 1}.  {name}", 34 if i < 3 else 30,
                        (120, 80, 0) if me_row else (0, 0, 0), y, base_x=x + 40)
        if not top:
            draw_center(screen, "Nobody landed a hit this time.", 28, (0, 0, 0), 450)
        if mon in rn.NO_DAMAGE:
            line = f"{mon} isn't ranked: its attack does no damage!"
        elif mon in top:
            line = f"{mon} made the top 10. Great raiding!"
        else:
            line = f"{mon} wasn't in the top 10 this time. Every hit helped!"
        draw_center(screen, line, 26, (255, 255, 255), 780)
        if ready:
            draw_center(screen, "Click anywhere to go back to the reviews.", 24, (230, 230, 230), 860)
        await frame(clock, fps)


# ==========================================
# 5. THE WHOLE RAID MODE  (called from main.py)
# ==========================================
async def raid_mode(screen, clock, fps, sounds, vfx):
    """Returns None (back to the start screen) or 'quit'."""
    if not tn.FIREBASE_URL:
        return await message_screen(screen, clock, fps, ["Class Raid isn't set up yet.",
                                                         "Add the Firebase database URL at the top of team_net.py."])
    try:
        net = tn.Net(tn.FIREBASE_URL, tn.make_transport())
    except Exception:
        return await message_screen(screen, clock, fps, ["Class Raid can't connect from this browser."])
    clk = tn.Clock()
    me = tn.new_id()
    sync = tn.ClockSync(net, clk, me)
    note = ""
    while True:
        k = await review_screen(screen, clock, fps, sounds, net, sync, note)
        if k in (None, "quit"):
            stop_music(sounds)
            return k
        note = ""
        room = rn.Room(net, clk, k, me)
        game = await lobby_screen(screen, clock, fps, sounds, net, room, k)
        if game == "quit":
            return "quit"
        if game is None:
            continue
        result = await raid_screen(screen, clock, fps, sounds, vfx, net, clk, room, k, game)
        if result == "quit":
            room.leave()
            return "quit"
        if result == "reset":
            room.leave()
            note = "That raid was reset. Pick a review to play again."
            continue
        r = await end_screen(screen, clock, fps, sounds, net, room, game["id"], result)
        room.leave()
        if r == "quit":
            return "quit"
