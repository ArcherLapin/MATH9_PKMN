# ==========================================
# q_polynomials.py  -  Math 9 questions: Polynomials (Weeks 4-5)
#   (No pygame here: question making only.  Class Raid uses it; any mode can.)
#
#   n = 1  Vocabulary              (coefficient, constant, degree, terms, classify, like terms)  W4L1
#   n = 2  Like terms, add, subtract                                                            W4L1-L4
#   n = 3  Multiply by a monomial  (distribute, then combine like terms)                        W5L1-L2
#   n = 4  Divide by a monomial                                                                 W5L3
#
#   A polynomial is a dict {power: coefficient}.  Exponents in plain ASCII ("x^2"), drawn raised.
#   Integer coefficients only.  Wrong answers are real mistakes first (sign errors when
#   subtracting, distributing to the first term only, combining unlike terms...).
#   make_question(n) -> (text, correct, [5 choices], None)
# ==========================================
import random

from q_tools import build, build_num, build_fixed, ask, Picker

VARS = "xmanypbktwd"


def var():
    return random.choice(VARS)


def nz(lo, hi):
    return random.choice([i for i in range(lo, hi + 1) if i != 0])


def _term_body(c, k, v):
    a = abs(c)
    if k == 0:
        return str(a)
    vp = v if k == 1 else f"{v}^{k}"
    return vp if a == 1 else f"{a}{vp}"


def terms_text(terms, v):
    """[(coef, power), ...] in the given order -> '5m^2 - 2m + 3m^2 + 6' (nothing combined)."""
    out = ""
    for i, (c, k) in enumerate(terms):
        body = _term_body(c, k, v)
        if i == 0:
            out = ("-" if c < 0 else "") + body
        else:
            out += (" - " if c < 0 else " + ") + body
    return out or "0"


def ptext(p, v):
    """{2: -4, 1: 7, 0: -9} -> '-4x^2 + 7x - 9' (highest power first, zeros left out)."""
    return terms_text([(p[k], k) for k in sorted(p, reverse=True) if p[k]], v)


def clean(p):
    return {k: c for k, c in p.items() if c}


def add(p, q, s=1):
    out = dict(p)
    for k, c in q.items():
        out[k] = out.get(k, 0) + s * c
    return clean(out)


def scale(p, k, shift=0):
    return clean({e + shift: c * k for e, c in p.items()})


def variants(p, v, n=10):
    """Near misses of p: one sign flipped, or one coefficient off by 1."""
    out = []
    for k in p:
        q = dict(p)
        q[k] = -p[k]
        out.append(ptext(q, v))
        for d in (1, -1):
            if p[k] + d:
                q = dict(p)
                q[k] = p[k] + d
                out.append(ptext(q, v))
    random.shuffle(out)
    return out[:n]


def rand_poly(powers, lo=-9, hi=9):
    return {k: nz(lo, hi) for k in powers}


def bracket(p, v):
    return f"({ptext(p, v)})"


# ==========================================
# 1. VOCABULARY
# ==========================================
def q1_parts():
    v = var()
    powers = sorted(random.sample([0, 1, 2, 3, 4], random.randint(2, 4)), reverse=True)
    p = rand_poly(powers)
    order = [(p[k], k) for k in powers]
    if random.random() < 0.3:
        random.shuffle(order)                          # not in order: the degree is still the highest power
    text = terms_text(order, v)
    ask_what = random.choice(["coef", "coef", "const", "degree", "terms"])
    if ask_what == "const" and 0 not in p:
        ask_what = "coef"
    if ask_what == "coef":
        k = random.choice([e for e in powers if e > 0])
        vp = v if k == 1 else f"{v}^{k}"
        others = [p[e] for e in powers if e != k]
        return build_num(ask(f"In  {text},  what is the coefficient of {vp}?"), p[k],
                         [-p[k], k, -k] + others, ok=lambda x: x.denominator == 1, extra=[])
    if ask_what == "const":
        others = [p[e] for e in powers if e != 0]
        return build_num(ask(f"In  {text},  what is the constant term?"), p[0],
                         [-p[0], 0] + others, ok=lambda x: x.denominator == 1, extra=[])
    deg = max(powers)
    if ask_what == "degree":
        traps = [len(powers), max(abs(c) for c in p.values()), sum(powers), deg + 1, deg - 1 if deg > 1 else 5]
        return build_num(ask(f"What is the degree of  {text} ?"), deg, traps,
                         ok=lambda x: x.denominator == 1 and x >= 0, extra=[0, 1, 2, 3, 4, 5, 6])
    traps = [deg, len(powers) + 1, len(powers) - 1 if len(powers) > 1 else 5, sum(abs(c) for c in p.values())]
    return build_num(ask(f"How many terms does  {text}  have?"), len(powers), traps,
                     ok=lambda x: x.denominator == 1 and x > 0, extra=[1, 2, 3, 4, 5, 6])


CLASSES = ["Monomial", "Binomial", "Trinomial", "Polynomial with 4 terms", "Not a polynomial"]


def q1_classify():
    v = var()
    n = random.randint(0, 4)
    if n == 0:                                         # a letter in a denominator: not a polynomial
        k = random.randint(1, 3)
        vp = v if k == 1 else f"{v}^{k}"
        others = rand_poly(random.sample([0, 1, 2], random.randint(1, 2)))
        text = f"{nz(2, 9)}/{vp} {random.choice(['+', '-'])} {ptext({e: abs(c) for e, c in others.items()}, v)}"
        return build_fixed(ask(f"Classify:   {text}"), CLASSES[4], CLASSES)
    p = rand_poly(random.sample([0, 1, 2, 3], n))
    return build_fixed(ask(f"Classify:   {ptext(p, v)}"), CLASSES[n - 1], CLASSES)


def q1_like():
    v = var()
    w = random.choice([x for x in VARS if x != v])
    k, c = random.randint(1, 3), nz(-9, 9)
    vp = lambda e: v if e == 1 else f"{v}^{e}"
    given = f"{c if abs(c) != 1 else ('-' if c < 0 else '')}{vp(k)}"
    c2 = random.choice([x for x in range(-9, 10) if x not in (0, c)])
    ans = f"{c2 if abs(c2) != 1 else ('-' if c2 < 0 else '')}{vp(k)}"
    traps = [f"{c}{vp(k + 1)}", f"{c}{vp(k - 1)}" if k > 1 else str(c), f"{c}{w if k == 1 else w + '^' + str(k)}",
             str(c * random.randint(2, 4)), f"{c}{v}{w}" if k == 1 else f"{c}{vp(k)}{w}"]
    return build(ask(f"Which term is a LIKE TERM with  {given} ?"), ans, traps)


# ==========================================
# 2. LIKE TERMS, ADD, SUBTRACT
# ==========================================
def q2_like_terms():
    v = var()
    powers = random.choice([[2, 1, 0], [2, 1, 0], [2, 0], [1, 0], [3, 2, 1]])
    total = rand_poly(powers)
    terms = []
    for k in powers:
        if random.random() < 0.75:                     # split into two like terms
            a = nz(-9, 9)
            if total[k] - a == 0:
                a = total[k] + 1 if total[k] + 1 else total[k] - 1
                if a == total[k]:
                    continue
            terms += [(a, k), (total[k] - a, k)]
        else:
            terms.append((total[k], k))
    if len(terms) < 3 or len(terms) == len(powers):
        return None
    random.shuffle(terms)
    ans = ptext(total, v)
    merged = dict(total)                               # combined unlike terms (x^2 and x together)
    if len(powers) > 1:
        hi, lo = powers[0], powers[1]
        merged = clean({**total, hi: total[hi] + total[lo], lo: 0})
    added_exp = clean({(2 * k if k else 0): c for k, c in total.items()})
    traps = [ptext(merged, v), ptext(added_exp, v) if len(added_exp) == len(total) else None] + variants(total, v)
    return build(ask(f"Simplify:   {terms_text(terms, v)}"), ans, traps)


def q2_add_sub():
    v = var()
    a = rand_poly(random.choice([[2, 1, 0], [2, 1, 0], [2, 1], [2, 0], [1, 0]]))
    b = rand_poly(random.choice([[2, 1, 0], [2, 1, 0], [2, 1], [1, 0]]))
    s = random.choice([1, -1, -1])
    res = add(a, b, s)
    if len(res) < 2:
        return None
    ans = ptext(res, v)
    op = "+" if s == 1 else "-"
    if s == -1:
        lead = max(b)
        first_only = add(add(a, {lead: b[lead]}, -1), {k: c for k, c in b.items() if k != lead})
        traps = [ptext(first_only, v), ptext(add(a, b), v)]
    else:
        traps = [ptext(add(a, b, -1), v)]
    if len(res) > 1:                                   # combined unlike terms
        ks = sorted(res, reverse=True)
        traps.append(ptext(clean({**res, ks[0]: res[ks[0]] + res[ks[1]], ks[1]: 0}), v))
    return build(ask(f"Simplify:   {bracket(a, v)} {op} {bracket(b, v)}"), ans, traps + variants(res, v))


# ==========================================
# 3. MULTIPLY BY A MONOMIAL
# ==========================================
def q3_distribute():
    v = var()
    t = random.choice(["k", "k", "kv", "k3"])
    k = random.choice([x for x in range(-9, 10) if x not in (-1, 0, 1)])
    if t == "k":
        inner = rand_poly([1, 0])
        if random.random() < 0.5:
            inner[1] = 1
        res = scale(inner, k)
        mon = str(k)
        first_only = {1: k * inner[1], 0: inner[0]}
        traps = [ptext(clean(first_only), v), ptext({1: res[1], 0: -res[0]}, v), ptext(scale(inner, -k), v)]
    elif t == "kv":
        inner = rand_poly([1, 0])
        res = scale(inner, k, 1)
        mon = f"{'-' if k < 0 else ''}{abs(k)}{v}"
        traps = [ptext(clean({2: k * inner[1], 0: k * inner[0]}), v),            # forgot the letter on the 2nd term
                 terms_text([(k * inner[1], 1), (k * inner[0], 1)], v),             # didn't add exponents
                 ptext(clean({2: k * inner[1], 0: inner[0]}), v),                  # first term only
                 ptext({2: res[2], 1: -res[1]}, v)]
    else:
        inner = rand_poly([2, 1, 0])
        res = scale(inner, k)
        mon = str(k)
        traps = [ptext(clean({2: res[2], 1: inner[1], 0: inner[0]}), v), ptext(scale(inner, -k), v),
                 ptext(clean({2: res[2], 1: res[1], 0: inner[0]}), v)]
    text = f"{mon}({ptext(inner, v)})" if mon not in ("1",) else bracket(inner, v)
    return build(ask(f"Expand:   {text}"), ptext(res, v), traps + variants(res, v))


def q3_distribute_combine():
    v = var()
    t = random.choice("abcd")
    k = random.choice([x for x in range(-6, 7) if x not in (-1, 0, 1)])
    if t == "a":                                       # 2(x + 3) + 4x
        inner, extra = rand_poly([1, 0]), {1: nz(-9, 9)}
        if random.random() < 0.5:
            inner[1] = 1
        res = add(scale(inner, k), extra)
        text = f"{k}({ptext(inner, v)}) {'+' if extra[1] > 0 else '-'} {terms_text([(abs(extra[1]), 1)], v)}"
        traps = [ptext(add({1: k * inner[1], 0: inner[0]}, extra), v), ptext(add(scale(inner, k), extra, -1), v)]
    elif t == "b":                                     # 3(a^2 + a - 2) + (2a^2 - 4a + 5)
        a, b = rand_poly([2, 1, 0]), rand_poly([2, 1, 0])
        res = add(scale(a, k), b)
        text = f"{k}({ptext(a, v)}) + {bracket(b, v)}"
        traps = [ptext(add(a, b), v), ptext(add({2: k * a[2], 1: a[1], 0: a[0]}, b), v),
                 ptext(scale(add(a, b), k), v)]
    elif t == "c":                                     # 4(m^2 - m + 2) - (m^2 + 2m - 1)
        k = abs(k)
        a, b = rand_poly([2, 1, 0]), rand_poly([2, 1, 0])
        res = add(scale(a, k), b, -1)
        first_only = add(add(scale(a, k), {2: b[2]}, -1), {1: b[1], 0: b[0]})
        text = f"{k}({ptext(a, v)}) - {bracket(b, v)}"
        traps = [ptext(first_only, v), ptext(add(scale(a, k), b), v), ptext(add(a, b, -1), v)]
    else:                                              # -2a(a - 5) + 3a
        inner, extra = rand_poly([1, 0]), nz(-9, 9)
        inner[1] = 1
        res = add(scale(inner, k, 1), {1: extra})
        text = f"{k}{v}({ptext(inner, v)}) {'+' if extra > 0 else '-'} {terms_text([(abs(extra), 1)], v)}"
        traps = [ptext(add({2: k, 0: k * inner[0]}, {1: extra}), v), ptext(add(scale(inner, k, 1), {1: -extra}), v),
                 ptext(add({1: k + k * inner[0]}, {1: extra}), v) if k + k * inner[0] + extra else None]
    if len(res) < 2:
        return None
    return build(ask(f"Simplify:   {text}"), ptext(res, v), traps + variants(res, v))


# ==========================================
# 4. DIVIDE BY A MONOMIAL
# ==========================================
def q4_divide():
    v = var()
    d = random.choice([2, 3, 4, 5, 6, 7, 8, -2, -3, -4, -5, -6])
    by_letter = random.random() < 0.6
    q = rand_poly(random.choice([[2, 1, 0], [1, 0], [2, 1], [2, 0]]), -6, 6)
    lead = max(q)
    if by_letter:
        top = scale(q, d, 1)                            # (15x^2 - 10x) / (5x)
        div = f"({'-' if d < 0 else ''}{abs(d)}{v})"
        keep_exp = {k + 1: c for k, c in q.items()}                         # forgot to subtract the exponents
        first_only = [(q[lead], lead)] + [(top[k + 1], k + 1) for k in sorted(q, reverse=True) if k != lead]
        traps = [ptext(keep_exp, v)]
    else:
        top = scale(q, d)                               # (12x^2 - 18x + 6) / 6
        div = f"({d})" if d < 0 else str(d)
        first_only = [(q[lead], lead)] + [(top[k], k) for k in sorted(q, reverse=True) if k != lead]
        traps = []
    traps += [terms_text(first_only, v), ptext(scale(q, -1), v)]          # divided the first term only
    text = f"{bracket(top, v)} / {div}"
    return build(ask(f"Divide:   {text}" + ("   (the letter is not 0)" if by_letter else "")), ptext(q, v),
                 traps + variants(q, v))


# ==========================================
# 5. QUESTION MIX
# ==========================================
GENERATORS = {
    1: [(q1_parts, "Parts of a polynomial"), (q1_classify, "Classify"), (q1_like, "Like terms")],
    2: [(q2_like_terms, "Combine like terms"), (q2_add_sub, "Add and subtract")],
    3: [(q3_distribute, "Distribute a monomial"), (q3_distribute_combine, "Distribute and combine")],
    4: [(q4_divide, "Divide by a monomial")],
}
TOPIC_COUNT = 4
_picker = Picker(GENERATORS)


def make_question(n):
    """(text, correct, 5 choices, visual or None) for topic n (1-4)."""
    return _picker.make(n)[:4]


def make_question_typed(n):
    return _picker.make(n)
