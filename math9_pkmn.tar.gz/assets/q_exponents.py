# ==========================================
# q_exponents.py  -  Math 9 questions: Exponents (Weeks 2-3)
#   (No pygame here: question making only.  Class Raid uses it; any mode can.)
#
#   n = 1  Powers                 (evaluate, the base, repeated multiplication)       W2L1-L2
#   n = 2  Product and quotient   (same base: add / subtract the exponents)           W2L3-L4
#   n = 3  Zero, one, power laws  (x^0, x^1, (x^a)^b, (2a^3)^4, (x/3)^2)              W3L1-L2
#   n = 4  Combining laws         (several laws in one question)                      W3L3-L4
#
#   Exponents are written with "^" in plain ASCII ("x^5"); main_tool.py draws them raised.
#   Products are written side by side: (x^3)(x^4).  Division with "/".
#   Every number answer is a whole number.  Numbers and letters are random: repeats are rare.
#   make_question(n) -> (text, correct, [5 choices], None)
# ==========================================
import random

from q_tools import build, build_num, ask, Picker

VARS = "xmanypbktwcd"


def var():
    return random.choice(VARS)


def pw(base, e):
    """'x^5', 'x' (exponent 1), '(-2)^4'."""
    return base if e == 1 else f"{base}^{e}"


def mono(c, v, e):
    """'10a^7', 'a^7', '-a^7', '7' (exponent 0)."""
    if e == 0:
        return str(c)
    lead = "" if c == 1 else "-" if c == -1 else str(c)
    return lead + pw(v, e)


def ints(v):
    return v.denominator == 1 and abs(v) <= 5000


# ==========================================
# 1. POWERS
# ==========================================
def max_exp(b):
    return {2: 7, 3: 5, 4: 4, 5: 4, 6: 3, 7: 3, 8: 3, 9: 3, 10: 4}[b]


def q1_evaluate():
    b = random.choice([2, 2, 3, 3, 4, 5, 6, 7, 8, 9, 10])
    n = random.randint(2, max_exp(b))
    form = random.choice(["paren", "paren", "neg", "plain", "sum", "sum"])
    if form == "sum":                                  # (-2)^3 + 3^2   (two powers, signs matter)
        c, m = random.choice([2, 3, 4, 5]), random.randint(2, 3)
        sgn = random.choice(["+", "-"])
        first_ = random.choice([f"(-{b})^{n}", f"-{b}^{n}"])
        v1 = (-b) ** n if first_.startswith("(") else -(b ** n)
        v2 = c ** m
        ans = v1 + v2 if sgn == "+" else v1 - v2
        other = -v1 + v2 if sgn == "+" else -v1 - v2
        traps = [other, -ans, b * n + c * m if sgn == "+" else b * n - c * m, v1 + c * m if sgn == "+" else v1 - c * m]
        return build_num(ask(f"Evaluate:   {first_} {sgn} {c}^{m}"), ans, traps, ok=ints)
    if form == "paren":
        text, ans = f"(-{b})^{n}", (-b) ** n
        other = -(b ** n)
    elif form == "neg":
        text, ans = f"-{b}^{n}", -(b ** n)
        other = (-b) ** n
    else:
        text, ans = f"{b}^{n}", b ** n
        other = -(b ** n)
    sg = 1 if ans > 0 else -1
    traps = [other, -ans, b * n * sg, (b ** (n - 1)) * sg, (b ** (n + 1)) * sg, n ** b if n ** b < 5000 else None,
             -b * n * sg, (b + n) * sg, (b ** (n - 1)) * -sg]
    return build_num(ask(f"Evaluate:   {text}"), ans, traps, ok=ints, extra=[])


def q1_base():
    b, n = random.randint(2, 20), random.randint(2, 12)
    v = var()
    form = random.choice(["paren", "neg", "coef", "group"])
    if form in ("paren", "neg") and b ** n > 10 ** 6:
        n = 2
    if form == "paren":
        text, ans, traps = f"(-{b})^{n}", f"-{b}", [str(b), str(n), f"-{n}", f"{(-b) ** n}"]
    elif form == "neg":
        text, ans, traps = f"-{b}^{n}", str(b), [f"-{b}", str(n), f"-{n}", f"{-(b ** n)}"]
    elif form == "coef":
        text, ans, traps = f"{b}{v}^{n}", v, [f"{b}{v}", str(b), str(n), pw(v, n)]
    else:
        text, ans, traps = f"({b}{v})^{n}", f"{b}{v}", [v, str(b), str(n), pw(v, n)]
    return build(ask(f"What is the BASE of   {text} ?"), ans, traps)


def q1_repeated():
    n = random.randint(3, 7)
    kind = random.choice(["neg", "pos", "var"])
    if kind == "neg":
        b = random.randint(2, 12)
        text = "".join(f"(-{b})" for _ in range(n))
        ans, value = f"(-{b})^{n}", (-b) ** n
        cands = [(f"-{b}^{n}", -(b ** n)), (f"{b}^{n}", b ** n), (f"(-{n})^{b}", (-n) ** b), (f"{n}^{b}", n ** b),
                 (f"(-{b})^{n + 1}", (-b) ** (n + 1)), (f"(-{b})^{n - 1}", (-b) ** (n - 1)), (f"{-b * n}", -b * n)]
        traps = [t for t, val in cands if val != value]       # never a second right answer (4^2 = (-2)^4)
    elif kind == "pos":
        b = random.randint(2, 15)
        text = "".join(f"({b})" for _ in range(n))
        ans, value = f"{b}^{n}", b ** n
        cands = [(f"{n}^{b}", n ** b), (f"{b}^{n + 1}", b ** (n + 1)), (f"{b}^{n - 1}", b ** (n - 1)),
                 (f"{b * n}", b * n), (f"{n * b}^{n}", (n * b) ** n)]
        traps = [t for t, val in cands if val != value]
    else:
        v = var()
        text = "".join(f"({v})" for _ in range(n))
        ans = pw(v, n)
        traps = [f"{n}{v}", pw(v, n + 1), pw(v, n - 1), f"{n}^{v}", f"{v} + {n}"]
    return build(ask(f"Write as a power:   {text}"), ans, traps)


# ==========================================
# 2. PRODUCT AND QUOTIENT LAWS
# ==========================================
def coef():
    return random.choice([1, 1, 2, 3, 4, 5, 6, -2, -3])


def q2_product():
    v, a, b = var(), random.randint(2, 9), random.randint(2, 9)
    if random.random() < 0.3:                          # numbers: (2^5)(2^2)
        k = random.randint(2, 9)
        text, ans = f"({k}^{a})({k}^{b})", f"{k}^{a + b}"
        traps = [f"{k * k}^{a + b}", f"{k}^{a * b}", f"{k * k}^{a * b}", f"{k}^{abs(a - b)}" if a != b else None,
                 f"{2 * k}^{a + b}"]
        return build(ask(f"Simplify (write as one power):   {text}"), ans, traps)
    c1, c2 = coef(), coef()
    text = f"({mono(c1, v, a)})({mono(c2, v, b)})"
    ans = mono(c1 * c2, v, a + b)
    traps = [mono(c1 * c2, v, a * b), mono(c1 + c2, v, a + b), mono(c1 + c2, v, a * b),
             mono(c1 * c2, v, a + b + 1), mono(c1 * c2, v, a + b - 1), mono(-c1 * c2, v, a + b)]
    return build(ask(f"Simplify:   {text}"), ans, traps)


def q2_quotient():
    v = var()
    b = random.randint(2, 7)
    a = b + random.randint(1, 7)
    if random.random() < 0.3:                          # numbers: 7^9 / 7^4
        k = random.randint(2, 9)
        text, ans = f"{k}^{a} / {k}^{b}", f"{k}^{a - b}"
        traps = [f"{k}^{a + b}", f"1^{a - b}", f"{k}^{a * b}", f"{k}^{a - b + 1}", f"{k}^{a - b - 1}" if a - b > 1 else None]
        return build(ask(f"Simplify (write as one power):   {text}"), ans, traps)
    q, c2 = random.choice([1, 1, 2, 3, 4, 5, -2, -3]), random.choice([1, 2, 3, 4, 5, 6])
    c1 = q * c2
    text = f"{mono(c1, v, a)} / {mono(c2, v, b)}" if c2 == 1 else f"({mono(c1, v, a)}) / ({mono(c2, v, b)})"
    ans = mono(q, v, a - b)
    traps = [mono(q, v, a + b), mono(c1 - c2, v, a - b) if c1 != c2 else None, mono(q, v, a * b),
             mono(q, v, a - b + 1), mono(q, v, a - b - 1) if a - b > 1 else mono(-q, v, a - b), mono(-q, v, a - b)]
    return build(ask(f"Simplify:   {text}"), ans, traps)


# ==========================================
# 3. ZERO AND ONE EXPONENTS, POWER LAWS
# ==========================================
def q3_zero_one():
    v, k, c = var(), random.randint(2, 999), random.randint(2, 99)
    t = random.choice(["k0", "negk0", "minus_k0", "cv0", "c_v0", "negk1", "k1", "sum"])
    if t == "k0":
        text, ans = f"{k}^0", 1
    elif t == "negk0":
        text, ans = f"(-{k})^0", 1
    elif t == "minus_k0":
        text, ans = f"-{k}^0", -1
    elif t == "cv0":
        text, ans = f"({c}{v})^0", 1
    elif t == "c_v0":
        text, ans = f"{c}{v}^0", c
    elif t == "negk1":
        text, ans = f"(-{k})^1", -k
    elif t == "k1":
        text, ans = f"{k}^1", k
    else:
        m = random.randint(2, 99)
        text, ans = f"{k}^0 + {m}^1", 1 + m
    traps = [0, 1, -1, k, -k, c, -c, 1 + k, m if t == "sum" else None, 2]
    return build_num(ask(f"Evaluate:   {text}" + ("   (the letter is not 0)" if v in text else "")),
                     ans, traps, ok=ints, extra=[])


def q3_power_of_power():
    v, a, b = var(), random.randint(2, 12), random.randint(2, 9)
    text, ans = f"({pw(v, a)})^{b}", pw(v, a * b)
    traps = [pw(v, a + b), pw(v, a ** b) if a ** b < 100 else None, f"{b}{pw(v, a)}", pw(v, a * b + 1),
             pw(v, a * b - 1), pw(v, b ** a) if b ** a < 100 else None]
    return build(ask(f"Simplify:   {text}"), ans, traps)


def q3_power_of_product():
    v, a, n = var(), random.randint(1, 9), random.randint(2, 4)
    c = random.choice([2, 2, 3, 3, 4, 5, 6, 7, 8, 9, 10, -2, -3, -4, -5])
    if abs(c) ** n > 1000:
        n = 2
    text = f"({c}{pw(v, a)})^{n}"
    ans = mono(c ** n, v, a * n)
    traps = [mono(c * n, v, a * n), mono(c, v, a * n), mono(c ** n, v, a + n), mono(c * n, v, a + n),
             mono(-(c ** n), v, a * n), mono(c ** n, v, a)]
    return build(ask(f"Simplify:   {text}"), ans, traps)


def q3_power_of_quotient():
    v, k, n = var(), random.randint(2, 10), random.randint(2, 4)
    if k ** n > 1000:
        n = 2
    e = random.choice([1, 1, 2, 3])                     # (x/3)^2  or  (x^2/3)^4
    text = f"({pw(v, e)}/{k})^{n}"
    ans = f"{pw(v, e * n)}/{k ** n}"
    traps = [f"{pw(v, e * n)}/{k}", f"{pw(v, e)}/{k ** n}", f"{pw(v, e * n)}/{k * n}", f"{pw(v, e + n)}/{k ** n}",
             f"{n}{pw(v, e)}/{k * n}", f"{n}{pw(v, e)}/{k ** n}"]
    return build(ask(f"Simplify:   {text}"), ans, traps)


# ==========================================
# 4. COMBINING LAWS
# ==========================================
def q4_combine():
    v = var()
    t = random.choice("abcde")
    if t == "a":                                       # (x^2)^3 (x^4)
        a, b, c = random.randint(2, 7), random.randint(2, 5), random.randint(1, 9)
        text, e = f"({pw(v, a)})^{b} ({pw(v, c)})", a * b + c
        traps = [pw(v, a + b + c), pw(v, a * b * c), pw(v, a * (b + c)), pw(v, e + 1), pw(v, e - 1)]
        ans = pw(v, e)
    elif t == "b":                                     # (m^3)^2 / m
        a, b = random.randint(2, 7), random.randint(2, 5)
        c = random.randint(1, a * b - 2)
        text, e = f"({pw(v, a)})^{b} / {pw(v, c)}", a * b - c
        traps = [pw(v, a + b - c) if a + b - c > 1 else None, pw(v, a * b + c), pw(v, a * (b - c)) if b > c else None,
                 pw(v, e + 1), pw(v, e - 1) if e > 2 else pw(v, e + 2)]
        ans = pw(v, e)
    elif t == "c":                                     # (2a^2)^3 / (4a)
        for _ in range(100):
            c, n, a = random.choice([2, 3, 4, 5]), random.randint(2, 3), random.randint(1, 4)
            d = random.choice([x for x in range(1, c ** n + 1) if c ** n % x == 0 and x != c ** n])
            b = random.randint(1, a * n - 1)
            if c ** n <= 125:
                break
        text = f"({c}{pw(v, a)})^{n} / ({mono(d, v, b)})"
        ans = mono(c ** n // d, v, a * n - b)
        traps = [mono(c * n // d if c * n % d == 0 else c * n, v, a * n - b), mono(c ** n // d, v, a + n - b)
                 if a + n - b > 0 else None, mono(c ** n, v, a * n - b), mono(c ** n // d, v, a * n + b),
                 mono(c ** n - d, v, a * n - b) if c ** n != d else None]
    elif t == "d":                                     # 7m^0 (m^3)
        k, a = random.randint(2, 20), random.randint(2, 12)
        text = f"({k}{pw(v, 0)})({pw(v, a)})"
        ans = mono(k, v, a)
        traps = [pw(v, a), str(k), "0", mono(k, v, a + 1), mono(k + 1, v, a), mono(k, v, 0) + v]
        return build(ask(f"Simplify:   {text}   (the letter is not 0)"), ans, traps)
    else:                                              # (3^4)(3^2) / 3^5   -> a whole number
        k = random.choice([2, 2, 3, 3, 4, 5, 10])
        r = random.randint(0, 3 if k <= 3 else 2)
        a, c = random.randint(2, 7), random.randint(2, 6)
        d = a + c - r
        text, val = f"({k}^{a})({k}^{c}) / {k}^{d}", k ** r
        traps = [k ** (r + 1), k ** (r - 1) if r else 0, k * r, r, k ** (r + 2) if k ** (r + 2) < 5000 else 1]
        return build_num(ask(f"Evaluate:   {text}"), val, traps, ok=ints, extra=[])
    return build(ask(f"Simplify:   {text}"), ans, traps)


# ==========================================
# 5. QUESTION MIX
# ==========================================
GENERATORS = {
    1: [(q1_evaluate, "Evaluate a power"), (q1_base, "Find the base"), (q1_repeated, "Repeated multiplication")],
    2: [(q2_product, "Product law"), (q2_quotient, "Quotient law")],
    3: [(q3_zero_one, "Zero and one exponents"), (q3_power_of_power, "Power of a power"),
        (q3_power_of_product, "Power of a product"), (q3_power_of_quotient, "Power of a quotient")],
    4: [(q4_combine, "Combining laws")],
}
TOPIC_COUNT = 4
_picker = Picker(GENERATORS)


def make_question(n):
    """(text, correct, 5 choices, visual or None) for topic n (1-4)."""
    return _picker.make(n)[:4]


def make_question_typed(n):
    return _picker.make(n)
