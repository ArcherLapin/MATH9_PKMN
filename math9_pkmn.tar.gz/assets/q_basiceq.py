# ==========================================
# q_basiceq.py  -  Math 9 questions: Equations (Week 6)
#   (No pygame here: question making only.  Class Raid uses it; any mode can.)
#
#   n = 1  One-step equations            x + 9 = 16,  -4x = 24,  x/4 = -3          W6L1
#   n = 2  Two-step equations            3x + 8 = -7,  x/3 - 2 = -1                W6L2
#   n = 3  Simplify first, then solve    3(x - 2) = 18,  2x + 5 + x = 35,
#                                        2(x + 1) + 3x = 17,  -2(x - 3) = 14       W6L3
#
#   Every answer is a whole number (the answer is picked first, then the equation is built).
#   Wrong answers are the real mistakes first: the wrong inverse operation, a sign error,
#   undoing in the wrong order, distributing to the first term only.
#   make_question(n) -> (text, correct, [5 choices], None)
# ==========================================
import random
from fractions import Fraction as F

from q_tools import build_num, ask, Picker

VARS = "xxxymnakp"


def nz(lo, hi):
    return random.choice([i for i in range(lo, hi + 1) if i != 0])


def coef(a, v):
    """3, x -> '3x';  1 -> 'x';  -1 -> '-x'."""
    return v if a == 1 else f"-{v}" if a == -1 else f"{a}{v}"


def plus(b):
    """' + 8' or ' - 8'."""
    return f" + {b}" if b > 0 else f" - {-b}"


def whole(v):
    return v is not None and F(v).denominator == 1 and abs(F(v)) <= 60


def div(a, b):
    """a / b if it is a whole number, else None (a mistake that doesn't give a whole number isn't shown)."""
    if b == 0:
        return None
    q = F(a, b)
    return q if q.denominator == 1 else None


def solve_q(v, text, ans, traps):
    fmt = lambda vals: [f"{v} = {int(x)}" for x in vals]
    return build_num(ask(f"Solve:   {text}"), ans, traps, fmt=fmt, ok=whole)


# ==========================================
# 1. ONE-STEP
# ==========================================
def q1_one_step():
    v = random.choice(VARS)
    x = nz(-20, 20)
    t = random.choice(["add", "sub", "mul", "div"])
    if t == "add":                                     # x + a = b
        a = random.randint(1, 20)
        b = x + a
        return solve_q(v, f"{v} + {a} = {b}", x, [b + a, -x, a - b])
    if t == "sub":                                     # x - a = b
        a = random.randint(1, 20)
        b = x - a
        return solve_q(v, f"{v} - {a} = {b}", x, [b - a, -x, a - b])
    if t == "mul":                                     # ax = b
        a = random.choice([k for k in range(-9, 10) if k not in (-1, 0, 1)])
        x = nz(-12, 12)
        b = a * x
        return solve_q(v, f"{coef(a, v)} = {b}", x, [-x, b - a, b + a, a * b if abs(a * b) <= 60 else None])
    a = random.choice([k for k in range(-9, 10) if k not in (-1, 0, 1)])   # x / a = b
    b = nz(-9, 9)
    x = a * b
    return solve_q(v, f"{v}/{a} = {b}" if a > 0 else f"{v}/({a}) = {b}", x, [-x, div(b, a), b - a, b + a])


# ==========================================
# 2. TWO-STEP
# ==========================================
def q2_two_step():
    v = random.choice(VARS)
    x = nz(-12, 12)
    t = random.choice(["ab", "ab", "neg", "frac", "back"])
    if t in ("ab", "neg"):                             # 3x + 8 = -7   /   -4x - 7 = 29
        a = random.choice([k for k in range(2, 10)]) * (-1 if t == "neg" else random.choice([1, 1, -1]))
        b = nz(-15, 15)
        c = a * x + b
        text = f"{coef(a, v)}{plus(b)} = {c}"
        traps = [div(c + b, a), F(c, a) - b if div(c, a) is not None else None, (c - b) * a if abs((c - b) * a) <= 60 else None,
                 -x, div(c - b, -a)]
    elif t == "frac":                                  # x/3 - 2 = -1
        a = random.choice([2, 3, 4, 5, 6])
        x = a * nz(-6, 6)
        b = nz(-9, 9)
        c = F(x, a) + b
        text = f"{v}/{a}{plus(b)} = {c}"
        traps = [(c + b) * a, F(c, 1) * a - b, div(c - b, a), -x]
    else:                                              # 15 - 2x = 7
        a, b = random.randint(2, 9), nz(-15, 15)
        c = b - a * x
        text = f"{b} - {coef(a, v)} = {c}"
        traps = [div(c - b, a), div(c + b, -a), -x, div(b - c, -a) if div(b - c, -a) != x else None]
    return solve_q(v, text, x, traps)


# ==========================================
# 3. SIMPLIFY FIRST, THEN SOLVE
# ==========================================
def q3_simplify_first():
    v = random.choice(VARS)
    x = nz(-10, 10)
    t = random.choice("abcd")
    if t == "a":                                       # 3(x - 2) = 18
        a, b = random.choice([2, 3, 4, 5, 6, 7, -2, -3, -4, -5]), nz(-9, 9)
        c = a * (x + b)
        text = f"{a}({v}{plus(b)}) = {c}"
        traps = [div(c - b, a), F(c, a) + b if div(c, a) is not None else None, div(c + a * b, a), -x]
    elif t == "b":                                     # 2x + 5 + x = 35   (like terms on one side)
        a, c, b = random.randint(2, 8), nz(-6, 6), nz(-15, 15)
        if a + c == 0:
            return None
        d = (a + c) * x + b
        text = f"{coef(a, v)}{plus(b)}{' + ' + coef(c, v) if c > 0 else ' - ' + coef(-c, v)} = {d}"
        traps = [div(d - b, a - c), div(d + b, a + c), div(d - b, a), -x]
    elif t == "c":                                     # 2(x + 1) + 3x = 17
        a, b, c = random.randint(2, 6), nz(-9, 9), random.choice([k for k in range(-5, 6) if k != 0])
        if a + c == 0:
            return None
        d = a * (x + b) + c * x
        text = f"{a}({v}{plus(b)}){' + ' + coef(c, v) if c > 0 else ' - ' + coef(-c, v)} = {d}"
        traps = [div(d - b, a + c), div(d - a * b, a), div(d + a * b, a + c), -x]
    else:                                              # -2(x - 3) = 14
        a, b = random.randint(2, 6), nz(-9, 9)
        c = -a * (x + b)
        text = f"-{a}({v}{plus(b)}) = {c}"
        traps = [div(c + a * b, -a), div(c - b, -a), div(c - a * b, a), -x]
    return solve_q(v, text, x, traps)


# ==========================================
# 4. QUESTION MIX
# ==========================================
GENERATORS = {
    1: [(q1_one_step, "One-step equations")],
    2: [(q2_two_step, "Two-step equations")],
    3: [(q3_simplify_first, "Simplify first, then solve")],
}
TOPIC_COUNT = 3
_picker = Picker(GENERATORS)


def make_question(n):
    """(text, correct, 5 choices, visual or None) for topic n (1-3)."""
    return _picker.make(n)[:4]


def make_question_typed(n):
    return _picker.make(n)
