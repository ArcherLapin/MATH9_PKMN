# ==========================================
# main_tool.py  -  engine for Mr. Chung's Pokemon Math Battle (Math 9)
#   Scaling, fonts, math text, animations, Pokemon, moves, buttons, messages, music,
#   unit tabs, and the tables / grids / graphs that questions can show.
#   No game content lives here: main.py supplies the topics and battles, the q_*.py files
#   make the questions, and pokedex.py says which Pokemon uses which sprite, where it
#   stands and how big it is.
#   Sections 1-6 are the same engine as the Precalculus 11 game; 7-8 are Math 9's own:
#     - render_rich: "x^12" and "x^2" are drawn with a small raised number (section 2)
#     - every Pokemon's spot, size and animation settings come from pokedex.py (section 4)
#     - Button: a long answer wraps onto two lines (section 5)
#     - TabBar: the unit tabs on the topic screens (section 7)
#     - the visual panel: tables, coordinate grids, graphs (section 8)
# ==========================================
import pygame
import random
import os
import re
import sys

import pokedex


# ==========================================
# 1. PATHS & SCALING
# ==========================================
def resource_path(relative_path):
    base_path = getattr(sys, "_MEIPASS", os.path.abspath("."))
    return os.path.join(base_path, relative_path)


BASE_W, BASE_H = 1080, 950
curr_w, curr_h = 1080, 950


def rx(x): return int((x / BASE_W) * curr_w)
def ry(y): return int((y / BASE_H) * curr_h)
def rs(size): return max(2, int(size * min(curr_w / BASE_W, curr_h / BASE_H)))


# ==========================================
# 2. FONTS & TEXT
# ==========================================
FONT_PATH = "caslon.ttf"
_font_cache = {}


def get_font(size):
    scaled = rs(size)
    if scaled not in _font_cache:
        _font_cache[scaled] = pygame.font.Font(resource_path(FONT_PATH), scaled)
    return _font_cache[scaled]


def draw_text(surface, text, color, base_x, base_y, base_size=26):
    """Plain text (Pokemon names and HP)."""
    surface.blit(get_font(base_size).render(text, True, color), (rx(base_x), ry(base_y)))


# ---------- Math text: x^2, <=, infinity ... with safe fallbacks ----------
# "x^2" is always drawn as a small raised 2, so it works in any font.
# If caslon.ttf is missing one of the math symbols below, a plain-text
# version is used instead (e.g. "<=" for the one-character version), so nothing shows as a box.
_FALLBACK = {
    "\u2264": "<=", "\u2265": ">=", "\u221e": "inf", "\u2212": "-",
    "\u222a": "U", "\u211d": "R", "\u00b1": "+/-", "\u2208": "in",
}
_glyph_ok = {}


def _tobytes(surf):
    fn = getattr(pygame.image, "tobytes", None) or pygame.image.tostring
    return fn(surf, "RGB")


def _font_has(ch):
    """True if caslon.ttf really draws ch (not the 'missing character' box)."""
    if ch not in _glyph_ok:
        ok = False
        try:
            f = pygame.font.Font(resource_path(FONT_PATH), 40)
            m = f.metrics(ch)
            if m and m[0] is not None:
                ok = True
                s = _tobytes(f.render(ch, True, (0, 0, 0), (255, 255, 255)))
                for missing in ("\uffff", "\ufffe"):
                    try:
                        if s == _tobytes(f.render(missing, True, (0, 0, 0), (255, 255, 255))):
                            ok = False
                    except Exception:
                        pass
        except Exception:
            ok = False
        _glyph_ok[ch] = ok
    return _glyph_ok[ch]


def clean_text(t):
    for ch, alt in _FALLBACK.items():
        if ch in t and not _font_has(ch):
            t = t.replace(ch, alt)
    return t


_rich_cache = {}


_SUP = re.compile(r"\^(\d+)|\u00b2")


def render_rich(text, size, color):
    """Text surface with every '\u00b2' and every '^' + digits ('x^12') drawn as a small raised number (cached).
    (Plain ASCII in the question files: no special characters needed for exponents.)"""
    key = (text, size, tuple(color))
    surf = _rich_cache.get(key)
    if surf is None:
        if len(_rich_cache) > 3000:
            _rich_cache.clear()
        t = clean_text(text)
        font = get_font(size)
        small = get_font(max(8, int(size * 0.62)))
        pieces = []
        pos = 0
        for m in _SUP.finditer(t):
            if m.start() > pos:
                pieces.append((font.render(t[pos:m.start()], True, color), False))
            pieces.append((small.render(m.group(1) or "2", True, color), True))
            pos = m.end()
        if pos < len(t) or not pieces:
            pieces.append((font.render(t[pos:], True, color), False))
        h = font.get_height()
        w = sum(p.get_width() for p, _ in pieces)
        surf = pygame.Surface((max(1, w), h), pygame.SRCALPHA)
        x = 0
        for p, sup in pieces:
            surf.blit(p, (x, int(font.get_ascent() * 0.08) if sup else 0))
            x += p.get_width()
        _rich_cache[key] = surf
    return surf


def text_w(text, size):
    return render_rich(text, size, (0, 0, 0)).get_width()


def fit_size(text, size, max_w, min_size=10):
    """Largest font size (<= size) that keeps text within max_w base pixels."""
    while size > min_size and text_w(text, size) > rx(max_w):
        size -= 1
    return size


def draw_center(screen, text, size, color, base_y, base_x=BASE_W / 2):
    s = render_rich(text, size, color)
    screen.blit(s, s.get_rect(center=(rx(base_x), ry(base_y))))


def draw_lines(screen, text, color, base_x, base_y_center, max_w, size=26):
    """Draws text (one line, or two lines split at '\\n'), shrinking it to fit max_w."""
    lines = text.split("\n")
    if len(lines) > 1:
        size = min(size, 21)
    size = min(fit_size(l, size, max_w) for l in lines)
    surfs = [render_rich(l, size, color) for l in lines]
    lh = surfs[0].get_height()
    top = ry(base_y_center) - lh * len(lines) // 2
    for i, s in enumerate(surfs):
        screen.blit(s, (rx(base_x), top + i * lh))


# ==========================================
# 3. ANIMATION FRAMES
# ==========================================
def load_frames(path_template, target_size=None, scale_factor=1.0, max_frames=60):
    """Load 'name (1).gif', 'name (2).gif', ... until a file is missing."""
    frames = []
    for i in range(1, max_frames + 1):
        try:
            img = pygame.image.load(path_template.format(i=i))
        except (pygame.error, FileNotFoundError, OSError):
            break
        if target_size:
            img = pygame.transform.scale(img, target_size)
        elif scale_factor != 1.0:
            img = pygame.transform.scale(img, (int(img.get_width() * scale_factor),
                                               int(img.get_height() * scale_factor)))
        frames.append(img)
    return frames


class Later:
    """Frames that are only loaded (and scaled) the first time they are needed."""
    def __init__(self, make):
        self.make, self.frames = make, None

    def get(self):
        if self.frames is None:
            self.frames = self.make()
        return self.frames


class Animation:
    def __init__(self, original_frames, speed=4, loop=False):
        self._source = original_frames           # a list of frames, or Later (loaded on first play)
        self.frames = None                       # the frames at the current window size
        self.speed = speed
        self.loop = loop
        self.timer = 0
        self.is_playing = loop
        self.last_size = (BASE_W, BASE_H)

    @property
    def original_frames(self):
        if isinstance(self._source, Later):
            self._source = self._source.get()
        return self._source

    def play(self):
        self.timer = 0
        self.is_playing = True

    def draw(self, surface, base_x, base_y):
        if not self.is_playing or not self.original_frames:
            return
        if self.frames is None or self.last_size != (curr_w, curr_h):   # rescale only if the window changed
            same = (curr_w, curr_h) == (BASE_W, BASE_H)
            self.frames = self.original_frames if same else [
                pygame.transform.scale(img, (rx(img.get_width()), ry(img.get_height()))) for img in self.original_frames]
            self.last_size = (curr_w, curr_h)

        frame_idx = self.timer // self.speed
        if frame_idx >= len(self.frames):
            if not self.loop:
                self.is_playing = False
                return
            self.timer, frame_idx = 0, 0
        surface.blit(self.frames[frame_idx], (rx(base_x), ry(base_y)))
        self.timer += 1


def load_vfx():
    """The attack/heal animations.  Each one is loaded the first time it plays (not at startup)."""
    spec = {
        "hit":         ("hit",           (400, 400)),
        "heal":        ("heal",          (400, 400)),
        "firepunch":   ("firepunch",     (500, 500)),
        "thunderbolt": ("lightning",     (200, 500)),
        "hydropump":   ("water",         (600, 600)),
        "thunder":     ("green_thunder", (500, 600)),
        "leaftornado": ("leaf_tornado",  (400, 600)),
    }
    return {key: Later(lambda f=fname, s=size: load_frames(resource_path(f"vfx/{f} ({{i}}).gif"), target_size=s))
            for key, (fname, size) in spec.items()}


# ==========================================
# 4. POKEMON SPRITES AND PLACES ON SCREEN
# ==========================================
# Which Pokemon uses which folder, and its moves: pokedex.py.
# Sprite files: pokemonN/pokemonN_front (1).gif ...  and  pokemonN/pokemonN_back (1).gif ...
# (pokemonN/pokemon_N (1).gif also works.)
#
# A "spot" is a place on screen for one Pokemon.  ALL spots, sizes and animation settings live in
# pokedex.py (section 2): pass  spot=pokedex.spot("team_foe1", name)  and  fx=pokedex.fx("team_foe1"),
# so each Pokemon's "scale", "shift" and per-mode nudges are already applied.
SPOTS = pokedex.SPOTS

_raw_cache, _fit_cache, _vfx_cache = {}, {}, {}


def _raw_frames(folder, view):
    """Frames for one view ('front' or 'back'); falls back to the other view, then pokemon_N."""
    key = (folder, view)
    if key not in _raw_cache:
        frames = []
        if folder is not None:
            other = "back" if view == "front" else "front"
            for name in (f"pokemon{folder}_{view}", f"pokemon{folder}_{other}", f"pokemon_{folder}"):
                frames = load_frames(resource_path(f"pokemon{folder}/{name} ({{i}}).gif"))
                if frames:
                    break
        _raw_cache[key] = frames
    return _raw_cache[key]


def fitted_frames(folder, view, size):
    """Frames scaled so the visible Pokemon fits size = (height, width), and its visible box."""
    key = (folder, view, size)
    if key not in _fit_cache:
        raw = _raw_frames(folder, view)
        if not raw:
            _fit_cache[key] = ([], pygame.Rect(0, 0, size[1], size[0]))
        else:
            bb = raw[0].get_bounding_rect()            # the visible part (skips empty margins)
            if bb.w < 4 or bb.h < 4:
                bb = raw[0].get_rect()
            k = min(size[0] / bb.h, size[1] / bb.w)
            frames = [pygame.transform.scale(f, (max(1, int(f.get_width() * k)), max(1, int(f.get_height() * k))))
                      for f in raw]
            _fit_cache[key] = (frames, pygame.Rect(int(bb.x * k), int(bb.y * k), int(bb.w * k), int(bb.h * k)))
    return _fit_cache[key]


def zoomed_frames(folder, view, k):
    """Frames at k x their real size, and the visible part of the Pokemon (for placing it)."""
    key = (folder, view, round(k, 4))
    if key not in _fit_cache:
        raw = _raw_frames(folder, view)
        if not raw:
            _fit_cache[key] = ([], pygame.Rect(0, 0, 200, 200))
        else:
            bb = raw[0].get_bounding_rect()            # the visible part (skips empty margins)
            if bb.w < 4 or bb.h < 4:
                bb = raw[0].get_rect()
            frames = [pygame.transform.scale(f, (max(1, int(f.get_width() * k)), max(1, int(f.get_height() * k))))
                      for f in raw]
            _fit_cache[key] = (frames, pygame.Rect(int(bb.x * k), int(bb.y * k), int(bb.w * k), int(bb.h * k)))
    return _fit_cache[key]


def _frames_of(v):
    return v.get() if isinstance(v, Later) else v


def scaled_vfx(vfx, scale):
    """The animations at another size (Team Battle, Class Raid), each one also made only when first played."""
    if scale == 1:
        return vfx
    if scale not in _vfx_cache:
        _vfx_cache[scale] = {
            k: Later(lambda v=v: [pygame.transform.scale(f, (int(f.get_width() * scale), int(f.get_height() * scale)))
                                  for f in _frames_of(v)])
            for k, v in vfx.items()}
    return _vfx_cache[scale]


class Pokemon:
    FX_SPEED = {"hit": 3, "heal": 3, "thunderbolt": 3, "firepunch": 4,
                "hydropump": 4, "thunder": 3, "leaftornado": 3}
    FX_FROM_SKY = {"thunderbolt", "thunder", "leaftornado"}      # these come down onto the Pokemon

    # Effect positions in the original single-player layout (from the sprite's top-left x, y)
    LAYOUT_FX = {"hit": (0, 25), "heal": (0, 0), "firepunch": (-20, -150),
                 "hydropump": (-50, -50), "thunder": (-50, -220), "leaftornado": (-50, -220)}

    def __init__(self, name, hp, max_hp, attack, defense, vfx_frames, view="front", spot=None, vfx_scale=1,
                 layout=None, fx=None):
        """spot   = place on screen (pokedex.spot(...): the Pokemon's own nudges already applied).
           layout = the original hand-tuned single-player numbers from pokedex.py ("single").
           fx     = animation settings (pokedex.fx(...)): scale, shift, by_effect."""
        entry = pokedex.info(name)
        spot = spot or pokedex.spot("single_enemy", name)
        fx = fx or {"scale": vfx_scale}
        self.fx_shift = fx.get("shift", (0, 0))
        self.fx_by_effect = fx.get("by_effect", {})
        self.name, self.hp, self.max_hp = name, hp, max_hp
        self.attack, self.defense = attack, defense
        self.moves = []
        self.fainted = False
        self.label, self.label_color = name, (255, 255, 255)     # text in the HP box
        self.layout = layout
        self.ax, self.ay = spot["anchor"]
        self.bx, self.by = spot["box"]
        self.panel = spot.get("panel", False)
        if layout:                                                # original single-player spot
            self.bx, self.by, self.img_x, self.img_y, tdx, tdy, k = layout
            self.tb_shift = (tdx, tdy)
            frames, box = zoomed_frames(entry.get("folder"), view, k)
            self.ax, self.ay = self.img_x + box.x + box.w / 2, self.img_y + box.y + box.h
            self.cx, self.cy = self.ax, self.ay - box.h / 2
        elif "scale" in spot:                                       # real size x zoom (natural sizes)
            frames, box = zoomed_frames(entry.get("folder"), view, spot["scale"])
        else:                                                     # fitted into a box (Class Raid's Mewtwo)
            frames, box = fitted_frames(entry.get("folder"), view, tuple(spot["size"]))
        if not layout:
            self.img_x = self.ax - (box.x + box.w / 2)
            self.img_y = self.ay - (box.y + box.h)
            self.cx, self.cy = self.ax, self.ay - box.h / 2       # middle of the visible sprite
        self.idle = Animation(frames, speed=4, loop=True)
        frames_fx = scaled_vfx(vfx_frames, fx.get("scale", 1))
        self.animations = {k: Animation(frames_fx.get(k, []), speed=sp) for k, sp in self.FX_SPEED.items()}
        folder = entry.get("folder")
        try:
            self.faint_sound = pygame.mixer.Sound(resource_path(f"pokemon{folder}/pokemon{folder}_faint.ogg"))
            self.faint_sound.set_volume(0.4)
        except (pygame.error, FileNotFoundError, OSError, TypeError):
            self.faint_sound = None

    def play_faint_sound(self):
        """Faints: plays the sound once and stops drawing the sprite."""
        if not self.fainted:
            self.fainted = True
            if self.faint_sound:
                self.faint_sound.play()

    def revive(self):
        self.hp, self.fainted = self.max_hp, False

    def trigger_vfx(self, effect_data):
        effects = effect_data if isinstance(effect_data, (list, tuple)) else [effect_data]
        for effect in effects:
            if effect in self.animations:
                self.animations[effect].play()

    def draw(self, surface, active=False):
        if not self.fainted:
            self.idle.draw(surface, self.img_x, self.img_y)
        for key, anim in self.animations.items():
            if not anim.is_playing or not anim.original_frames:
                continue
            w, h = anim.original_frames[0].get_size()
            if self.layout:                                       # original fixed offsets
                dx, dy = self.tb_shift if key == "thunderbolt" else self.LAYOUT_FX.get(key, (0, 0))
                anim.draw(surface, self.img_x + dx, self.img_y + dy)
            else:                                                 # fx shift (+ this effect's own nudge)
                ex, ey = self.fx_by_effect.get(key, (0, 0))
                dx, dy = self.fx_shift[0] + ex, self.fx_shift[1] + ey
                if key in self.FX_FROM_SKY:                       # comes down onto the feet
                    anim.draw(surface, self.ax - w / 2 + dx, self.ay - h + dy)
                else:                                             # on the middle of the Pokemon
                    anim.draw(surface, self.cx - w / 2 + dx, self.cy - h / 2 + dy)
        self.draw_hp_box(surface, active)

    def box_rect(self):
        """The name/HP plate on screen (for clicking it)."""
        w = 270 if self.panel else 300
        return pygame.Rect(rx(self.bx - 12), ry(self.by - 8), rx(w + 24), ry(98))

    def draw_hp_box(self, surface, active=False):
        x, y = self.bx, self.by
        w = 270 if self.panel else 300
        grey = (170, 170, 170)
        if self.panel:
            r = pygame.Rect(rx(x - 12), ry(y - 8), rx(w + 24), ry(98))
            bg = pygame.Surface(r.size, pygame.SRCALPHA)
            bg.fill((0, 0, 0, 110))
            surface.blit(bg, r.topleft)
            if active:
                pygame.draw.rect(surface, (255, 220, 60), r, max(2, rs(4)))
        s = render_rich(self.label, fit_size(self.label, 26 if not self.panel else 24, w),
                        grey if self.fainted else self.label_color)
        surface.blit(s, (rx(x), ry(y)))
        ratio = max(0, self.hp / self.max_hp)
        bar_y, txt_y, txt_size = (y + 40, y + 60, 26) if self.layout else (y + 38, y + 56, 22 if not self.panel else 20)
        red, green = ((255, 0, 0), (0, 255, 0)) if self.layout else ((220, 0, 0), (0, 220, 0))
        pygame.draw.rect(surface, red, (rx(x), ry(bar_y), rx(w), ry(12)))
        pygame.draw.rect(surface, green, (rx(x), ry(bar_y), rx(w * ratio), ry(12)))
        hp_text = "Fainted" if self.fainted else f"HP: {int(self.hp)} / {int(self.max_hp)}"
        s = render_rich(hp_text, txt_size, grey if self.fainted else (255, 255, 255))
        surface.blit(s, (rx(x), ry(txt_y)))


# ==========================================
# 5. MESSAGES, MOVES, BUTTONS
# ==========================================
class MessageSystem:
    def __init__(self):
        self.queue, self.current = [], ""

    def draw(self, surface):
        draw_lines(surface, self.current, (255, 255, 255), 85, 768, 905)

    def add(self, text, target=None, hp_change=0, vfx=None, sound=None):
        self.queue.append({"text": text, "target": target, "hp_change": hp_change, "vfx": vfx, "sound": sound})

    def clear(self):
        self.current = ""

    def has_active_message(self):
        return bool(self.current) or bool(self.queue)

    def update(self):
        if self.current or not self.queue:
            return
        msg = self.queue.pop(0)
        self.current = msg["text"]
        t = msg["target"]
        if t is None:
            return
        t.hp += msg["hp_change"]
        if msg["hp_change"] < 0:
            if msg["vfx"]:   t.trigger_vfx(msg["vfx"])
            if msg["sound"]: msg["sound"].play()
        elif msg["hp_change"] > 0:
            t.trigger_vfx("heal")
        t.hp = max(0, min(t.hp, t.max_hp))


class Move:
    def __init__(self, name, power, miss_chance, crit_chance, category, vfx, sound):
        self.name, self.power = name, power
        self.miss_chance, self.crit_chance = miss_chance, crit_chance
        self.category, self.vfx, self.sound = category, vfx, sound

    def execute(self, attacker, defender, msg_sys, heal_sound_ref):
        msg_sys.add(f"{attacker.name} used {self.name}!")
        if self.category == "heal":
            msg_sys.add(f"{attacker.name} recovered HP!", target=attacker, hp_change=self.power)
            if heal_sound_ref: heal_sound_ref.play()
        elif self.category == "buff":
            attacker.attack *= self.power
            msg_sys.add(f"{attacker.name}'s Attack sharply rose!")
        else:
            damage = int(self.power * (attacker.attack / 100))
            if random.randint(1, 100) <= self.miss_chance:
                msg_sys.add(f"{attacker.name}'s Attack missed!")
            elif random.randint(1, 100) <= self.crit_chance:
                msg_sys.add(f"A critical hit! It dealt {int(damage * 1.5)} damage!",
                            target=defender, hp_change=-int(damage * 1.5), vfx=self.vfx, sound=self.sound)
            else:
                msg_sys.add(f"It dealt {damage} damage!", target=defender, hp_change=-damage,
                            vfx=self.vfx, sound=self.sound)


def make_moves(name, sounds):
    """A Pokemon's moves from pokedex.py, ready to use in battle."""
    out = []
    for move_name, power, miss, crit, effect in pokedex.moves(name):
        anims, sound = pokedex.EFFECTS.get(effect, pokedex.EFFECTS["hit"])
        out.append(Move(move_name, power, miss, crit, "damage", anims, sounds.get(sound)))
    return out


class Button:
    """Button that can show x^2, <= etc. and shrinks long answers to fit.
    A very long answer (like "The months until the total cost is $150") wraps onto two lines."""
    WRAP_BELOW = 17          # if one line would need a font smaller than this, try two lines

    def __init__(self, base_x, base_y, base_w, base_h, color=(150, 200, 200)):
        self.text = ""
        self.color = color
        self.text_color = (0, 0, 0)
        self.border_color = (0, 0, 0)       # the outline (a faint button can use a grey one)
        self.bx, self.by, self.bw, self.bh = base_x, base_y, base_w, base_h
        self._fit = {}       # (text, size) -> (font size, [lines])   so it is worked out once

    def rect(self):
        return pygame.Rect(rx(self.bx), ry(self.by), rx(self.bw), ry(self.bh))

    def _layout(self, size):
        key = (self.text, size)
        if key not in self._fit:
            if len(self._fit) > 200:
                self._fit.clear()
            room = self.bw - 14
            one = fit_size(self.text, size, room)
            best = (one, [self.text])
            words = self.text.split()
            if one < self.WRAP_BELOW and len(words) > 2:
                for k in range(1, len(words)):
                    a, b = " ".join(words[:k]), " ".join(words[k:])
                    sz = min(fit_size(a, min(size, 22), room), fit_size(b, min(size, 22), room))
                    if sz > best[0]:
                        best = (sz, [a, b])
            self._fit[key] = best
        return self._fit[key]

    def draw(self, surface, size=24):
        rect = self.rect()
        pygame.draw.rect(surface, self.color, rect)
        pygame.draw.rect(surface, self.border_color, rect, max(1, rs(2)))
        sz, lines = self._layout(size)
        if len(lines) == 1:
            s = render_rich(lines[0], sz, self.text_color)
            surface.blit(s, s.get_rect(center=rect.center))
            return
        for line, dy in zip(lines, (-0.25, 0.25)):
            s = render_rich(line, sz, self.text_color)
            surface.blit(s, s.get_rect(center=(rect.centerx, rect.centery + int(dy * rect.h))))

    def clicked(self, mousepos):
        return self.rect().collidepoint(mousepos)


# ==========================================
# 6. MUSIC
# ==========================================
MUSIC_END_EVENT = pygame.USEREVENT + 1


def play_random_track(music_pool):
    """Plays a random track from the pool (music5.ogg ...). If a file is missing or won't load,
    another track from the same pool is tried. If none load, the music stops, so the last
    battle's music never keeps playing in the wrong battle."""
    if not music_pool:
        return
    for n in random.sample(list(music_pool), len(music_pool)):
        try:
            pygame.mixer.music.load(resource_path(f"music{n}.ogg"))      # pygbag needs OGG
            pygame.mixer.music.set_volume(0.15)
            pygame.mixer.music.play(0)
            return
        except (pygame.error, FileNotFoundError, OSError):
            continue
    try:
        pygame.mixer.music.stop()
    except pygame.error:
        pass


# ==========================================
# 7. UNIT TABS  (topic screens: one tab per unit, its topics below)
# ==========================================
class TabBar:
    """A row of tabs across the screen.  clicked(pos) -> tab index or None."""
    ON, OFF, SOON = (250, 215, 90), (200, 210, 215), (175, 175, 175)

    def __init__(self, labels, y, h=52, left=40, width=1000, gap=8):
        n = max(1, len(labels))
        w = (width - gap * (n - 1)) / n
        self.tabs = []
        for i, label in enumerate(labels):
            b = Button(left + i * (w + gap), y, w, h)
            b.text = label
            self.tabs.append(b)

    def clicked(self, pos):
        return next((i for i, b in enumerate(self.tabs) if b.clicked(pos)), None)

    def draw(self, surface, active, ready=None):
        """ready = list of True/False per tab (False = a 'coming soon' unit, drawn grey)."""
        for i, b in enumerate(self.tabs):
            if i == active:
                b.color, b.text_color = self.ON, (0, 0, 0)
            elif ready is not None and not ready[i]:
                b.color, b.text_color = self.SOON, (90, 90, 90)
            else:
                b.color, b.text_color = self.OFF, (0, 0, 0)
            b.draw(surface, size=22)
        if 0 <= active < len(self.tabs):                        # a line joining the tab to the page
            r = self.tabs[active].rect()
            pygame.draw.line(surface, self.ON, (r.left, r.bottom + rs(3)), (r.right, r.bottom + rs(3)), max(2, rs(5)))


# ==========================================
# 8. VISUAL PANEL  (tables, coordinate grids, context graphs)
# ==========================================
# Same drawing code as the Linear Relations game.  It is drawn over the battle area
# (above the text box), so the question and the answer buttons stay visible.
# A "visual" is a dict.  Any of these keys may be present (drawn top to bottom):
#   "notes":  ["line of text", ...]                  extra info / situation text
#   "table":  {"rows": [("x", [1, 2, 3]), ("y", [4, "?", 10])], "vertical": False}
#   "grid":   {"r": 8, "lines": [(m, b[, "A"]) | ("h", b[, "A"]) | ("v", a[, "A"])],
#              "points": [(x, y, "label"), ...]}     standard -r..r coordinate grid
#   "graph":  {"title", "xlabel", "ylabel", "xmax", "xstep", "ymax", "ystep",
#              "line": (m, b) or None, "pts": [(x, y), ...],          dots on the line
#              "labels": [(x, y, "text"), ...],                       labelled points on the line
#              "scatter": [(x, y), ...],                              data (line of best fit)
#              "highlight": [(x, y, "text"), ...]}                    a green data point
#   "bars":   {"title", "ylabel", "cats": ["A", "B"], "vals": [12, 15],
#              "ymin", "ymax", "ystep"}               bar graph; ymin can be above 0 (misleading graphs)
#   "pics":   {"title", "items": [("Last year\n100 boxes", 1), ("This year\n200 boxes", 2)]}
#              pictures; the number = how many times as wide AND as tall (grows two ways)
#   "lgraph": {"title", "ylabel", "xs": ["Sep", "Oct", ...], "ys": [values],
#              "ymin", "ymax", "ticks": [tick heights],
#              "ypos": [heights to plot at] (optional, else ys),
#              "ticklabels": ["0", "10", "20", "50", "100"] (optional: uneven scale steps)}
PANEL = pygame.Rect(40, 15, 1000, 695)      # base coords; battle area is y < 720
INK, GRID_C, AXIS_C, LINE_C = (20, 20, 20), (200, 205, 215), (40, 40, 40), (25, 95, 190)


def _P(x, y):
    return (rx(x), ry(y))


def _txt(surface, text, size, center, color=INK):
    s = get_font(size).render(str(text), True, color)
    surface.blit(s, s.get_rect(center=center))


def _table_size(table, max_w=900):
    rows = table["rows"]
    n = max(len(vals) for _, vals in rows)
    head_w = max(70, max(get_font(26).size(str(h))[0] for h, _ in rows) + 30)
    cell_w = min(110, (max_w - head_w) // n)
    return n, head_w, cell_w, head_w + n * cell_w


def draw_table(surface, table, cx, top, max_w=900):
    rows = table["rows"]
    n, head_w, cell_w, total_w = _table_size(table, max_w)
    cell_h = 56
    left = cx - total_w // 2
    for r, (head, vals) in enumerate(rows):
        y = top + r * cell_h
        hdr = pygame.Rect(*_P(left, y), rx(head_w), ry(cell_h))
        pygame.draw.rect(surface, (225, 232, 240), hdr)
        pygame.draw.rect(surface, INK, hdr, max(1, rs(2)))
        _txt(surface, head, 26, hdr.center)
        for c in range(n):
            cell = pygame.Rect(*_P(left + head_w + c * cell_w, y), rx(cell_w), ry(cell_h))
            pygame.draw.rect(surface, INK, cell, max(1, rs(2)))
            v = vals[c] if c < len(vals) else ""
            _txt(surface, v, 28, cell.center, (200, 30, 30) if v == "?" else INK)
    return top + len(rows) * cell_h


def _line_ends(m, b, lo, hi):
    """Clip y = mx + b to the box [lo, hi] x [lo, hi]."""
    pts = []
    for x in (lo, hi):
        y = m * x + b
        if lo <= y <= hi:
            pts.append((x, y))
    if m != 0:
        for y in (lo, hi):
            x = (y - b) / m
            if lo <= x <= hi:
                pts.append((x, y))
    pts = sorted(set(pts))
    return (pts[0], pts[-1]) if len(pts) >= 2 else None


def draw_grid(surface, grid, cx, top, size_px):
    r = grid.get("r", 8)
    unit = size_px / (2 * r)
    left = cx - size_px / 2

    def to_px(x, y):
        return _P(left + (x + r) * unit, top + (r - y) * unit)

    for k in range(-r, r + 1):
        w = max(1, rs(3)) if k == 0 else 1
        col = AXIS_C if k == 0 else GRID_C
        pygame.draw.line(surface, col, to_px(k, -r), to_px(k, r), w)
        pygame.draw.line(surface, col, to_px(-r, k), to_px(r, k), w)
        if k != 0 and k % 2 == 0:
            px, py = to_px(k, 0)
            _txt(surface, k, 16, (px, py + rs(12)))
            px, py = to_px(0, k)
            _txt(surface, k, 16, (px - rs(14), py))
    px, py = to_px(r, 0)
    _txt(surface, "x", 22, (px + rs(14), py))
    px, py = to_px(0, r)
    _txt(surface, "y", 22, (px + rs(16), py - rs(4)))

    colors = [LINE_C, (200, 60, 40), (30, 140, 70), (150, 70, 190)]
    for i, ln in enumerate(grid.get("lines", [])):
        col = colors[i % len(colors)] if len(grid["lines"]) > 1 else LINE_C
        if ln[0] == "h":
            ends = ((-r, ln[1]), (r, ln[1]))
        elif ln[0] == "v":
            ends = ((ln[1], -r), (ln[1], r))
        else:
            ends = _line_ends(ln[0], ln[1], -r, r)
        if not ends:
            continue
        pygame.draw.line(surface, col, to_px(*ends[0]), to_px(*ends[1]), max(2, rs(4)))
        if len(ln) > 2:                                    # line name near its upper end
            a, b = ends if ends[1][1] >= ends[0][1] else (ends[1], ends[0])
            f = (0.9, 0.72, 0.54, 0.36)[i % 4]               # stagger names so they don't overlap
            px, py = to_px(a[0] + f * (b[0] - a[0]), a[1] + f * (b[1] - a[1]))
            pygame.draw.circle(surface, (255, 255, 255), (px + rs(18), py), rs(16))
            _txt(surface, ln[2], 26, (px + rs(18), py), col)
    for x, y, label in grid.get("points", []):
        p = to_px(x, y)
        pygame.draw.circle(surface, (210, 40, 40), p, max(3, rs(7)))
        if label:
            _txt(surface, label, 24, (p[0] + rs(16), p[1] - rs(16)), (170, 20, 20))


def draw_context_graph(surface, g, area):
    """First-quadrant graph with a title, labelled axes and scales (area = base Rect)."""
    ax_left, ax_bottom = area.x + 110, area.bottom - 70
    ax_w, ax_h = area.w - 150, area.h - 130
    xmax, ymax = g["xmax"], g["ymax"]

    def to_px(x, y):
        return _P(ax_left + x / xmax * ax_w, ax_bottom - y / ymax * ax_h)

    _txt(surface, g["title"], 28, _P(area.centerx, area.y + 20))
    for k in range(0, xmax + 1, g["xstep"]):
        pygame.draw.line(surface, GRID_C, to_px(k, 0), to_px(k, ymax), 1)
        px, py = to_px(k, 0)
        _txt(surface, k, 20, (px, py + rs(16)))
    for k in range(0, ymax + 1, g["ystep"]):
        pygame.draw.line(surface, GRID_C, to_px(0, k), to_px(xmax, k), 1)
        px, py = to_px(0, k)
        _txt(surface, k, 20, (px - rs(10) - get_font(20).size(str(k))[0] // 2, py))
    pygame.draw.line(surface, AXIS_C, to_px(0, 0), to_px(xmax, 0), max(1, rs(3)))
    pygame.draw.line(surface, AXIS_C, to_px(0, 0), to_px(0, ymax), max(1, rs(3)))
    _txt(surface, g["xlabel"], 22, _P(ax_left + ax_w / 2, ax_bottom + 50))
    lab = get_font(22).render(g["ylabel"], True, INK)
    lab = pygame.transform.rotate(lab, 90)
    surface.blit(lab, lab.get_rect(center=_P(area.x + 22, ax_bottom - ax_h / 2)))

    if g.get("line"):
        m, b = g["line"]
        x_end = xmax if m >= 0 else min(xmax, -b / m)
        x_end = min(x_end, (ymax - b) / m) if m > 0 else x_end
        pygame.draw.line(surface, LINE_C, to_px(0, b), to_px(x_end, m * x_end + b), max(2, rs(4)))
    for x, y in g.get("scatter", []):
        p = to_px(x, y)
        pygame.draw.circle(surface, (90, 70, 0), p, max(3, rs(7)))
        pygame.draw.circle(surface, (245, 200, 40), p, max(2, rs(5)))
    for x, y in g.get("pts", []):
        pygame.draw.circle(surface, LINE_C, to_px(x, y), max(3, rs(7)))
    for x, y, text in g.get("highlight", []):
        p = to_px(x, y)
        pygame.draw.circle(surface, (20, 150, 60), p, max(3, rs(9)))
        s = get_font(22).render(text, True, (10, 120, 40))
        surface.blit(s, s.get_rect(midleft=(p[0] + rs(14), p[1])))
    for x, y, text in g.get("labels", []):
        p = to_px(x, y)
        pygame.draw.circle(surface, (120, 60, 200), p, max(3, rs(8)))
        _txt(surface, text, 22, (p[0] + rs(10), p[1] - rs(22)), (110, 40, 190))


BAR_COLORS = [(25, 95, 190), (200, 60, 40), (30, 140, 70), (150, 70, 190)]


def _ylabel(surface, text, center):
    if text:
        lab = pygame.transform.rotate(get_font(22).render(text, True, INK), 90)
        surface.blit(lab, lab.get_rect(center=center))


def _tick_label(surface, text, ax_left, y):
    px, py = _P(ax_left, y)
    _txt(surface, text, 22, (px - rs(12) - get_font(22).size(text)[0] // 2, py))


def _fmt_tick(v):
    v = float(v)
    return str(int(v)) if v == int(v) else f"{v:g}"


def draw_bar_chart(surface, g, area):
    """Bar graph.  The vertical axis starts at g["ymin"] (not always 0) and has a line at every step,
    so bar heights can be counted in grid steps."""
    ax_left, ax_bottom = area.x + 120, area.bottom - 60
    ax_w, ax_h = area.w - 180, area.h - 120
    ymin, ymax, ystep = g["ymin"], g["ymax"], g["ystep"]

    def to_y(v):
        return ax_bottom - (v - ymin) / (ymax - ymin) * ax_h

    _txt(surface, g["title"], 30, _P(area.centerx, area.y + 22))
    v = ymin
    while v <= ymax + 1e-9:
        y = to_y(v)
        pygame.draw.line(surface, GRID_C, _P(ax_left, y), _P(ax_left + ax_w, y), 1)
        lab = _fmt_tick(v)
        _tick_label(surface, lab, ax_left, y)
        v += ystep
    n = len(g["cats"])
    slot = ax_w / n
    bw = slot * 0.42
    for i, (cat, val) in enumerate(zip(g["cats"], g["vals"])):
        cx = ax_left + slot * (i + 0.5)
        top = to_y(val)
        bar = pygame.Rect(*_P(cx - bw / 2, top), rx(bw), ry(ax_bottom - top))
        pygame.draw.rect(surface, BAR_COLORS[i % len(BAR_COLORS)], bar)
        pygame.draw.rect(surface, INK, bar, max(1, rs(2)))
        _txt(surface, cat, 26, _P(cx, ax_bottom + 26))
    pygame.draw.line(surface, AXIS_C, _P(ax_left, ax_bottom), _P(ax_left + ax_w, ax_bottom), max(1, rs(3)))
    pygame.draw.line(surface, AXIS_C, _P(ax_left, ax_bottom), _P(ax_left, ax_bottom - ax_h), max(1, rs(3)))
    _ylabel(surface, g.get("ylabel", ""), _P(area.x + 24, ax_bottom - ax_h / 2))


def draw_line_chart(surface, g, area):
    """Line graph over named steps (months, years).  "ticklabels" can label the grid lines
    with uneven numbers (0, 10, 20, 50, 100): the misleading-scale graph."""
    ax_left, ax_bottom = area.x + 120, area.bottom - 60
    ax_w, ax_h = area.w - 180, area.h - 120
    ymin, ymax = g.get("ymin", 0), g["ymax"]
    ys = g.get("ypos") or g["ys"]
    xs = g["xs"]

    def to_px(i, v):
        x = ax_left + ax_w * (i + 0.5) / len(xs)
        return _P(x, ax_bottom - (v - ymin) / (ymax - ymin) * ax_h)

    _txt(surface, g["title"], 30, _P(area.centerx, area.y + 22))
    ticks = g.get("ticks", [])
    labels = g.get("ticklabels") or [_fmt_tick(t) for t in ticks]
    for t, lab in zip(ticks, labels):
        y = ax_bottom - (t - ymin) / (ymax - ymin) * ax_h
        pygame.draw.line(surface, GRID_C, _P(ax_left, y), _P(ax_left + ax_w, y), 1)
        _tick_label(surface, lab, ax_left, y)
    for i, name in enumerate(xs):
        px, _ = to_px(i, ymin)
        _txt(surface, name, 24, (px, ry(ax_bottom + 26)))
    pts = [to_px(i, v) for i, v in enumerate(ys)]
    if len(pts) > 1:
        pygame.draw.lines(surface, LINE_C, False, pts, max(2, rs(4)))
    for p in pts:
        pygame.draw.circle(surface, LINE_C, p, max(3, rs(8)))
    pygame.draw.line(surface, AXIS_C, _P(ax_left, ax_bottom), _P(ax_left + ax_w, ax_bottom), max(1, rs(3)))
    pygame.draw.line(surface, AXIS_C, _P(ax_left, ax_bottom), _P(ax_left, ax_bottom - ax_h), max(1, rs(3)))
    _ylabel(surface, g.get("ylabel", ""), _P(area.x + 24, ax_bottom - ax_h / 2))


def _draw_icon(surface, kind, x, y, w, h):
    """A simple picture filling the base box (x, y, w, h): juice box, book, tree or cookie."""
    R = lambda a, b, c, d: pygame.Rect(*_P(x + a * w, y + b * h), max(1, rx(c * w)), max(1, ry(d * h)))
    edge = max(1, rs(2))
    if kind == "book":
        pygame.draw.rect(surface, (180, 50, 50), R(0.1, 0.05, 0.8, 0.9))
        pygame.draw.rect(surface, (120, 30, 30), R(0.1, 0.05, 0.14, 0.9))
        pygame.draw.rect(surface, (245, 240, 225), R(0.84, 0.08, 0.05, 0.84))
        pygame.draw.rect(surface, INK, R(0.1, 0.05, 0.8, 0.9), edge)
    elif kind == "tree":
        pygame.draw.rect(surface, (120, 80, 40), R(0.42, 0.62, 0.16, 0.38))
        pygame.draw.polygon(surface, (40, 140, 60),
                            [_P(x + 0.5 * w, y), _P(x + 0.95 * w, y + 0.7 * h), _P(x + 0.05 * w, y + 0.7 * h)])
        pygame.draw.polygon(surface, INK,
                            [_P(x + 0.5 * w, y), _P(x + 0.95 * w, y + 0.7 * h), _P(x + 0.05 * w, y + 0.7 * h)], edge)
    elif kind == "cookie":
        c, r = _P(x + w / 2, y + h / 2), int(min(rx(w), ry(h)) * 0.47)
        pygame.draw.circle(surface, (215, 160, 80), c, r)
        pygame.draw.circle(surface, (150, 100, 40), c, r, edge)
        for dx, dy in ((-0.2, -0.15), (0.15, -0.22), (0.05, 0.12), (-0.18, 0.2), (0.25, 0.1)):
            pygame.draw.circle(surface, (80, 45, 20), _P(x + (0.5 + dx) * w, y + (0.5 + dy) * h), max(2, r // 9))
    else:                                                   # juice box
        pygame.draw.rect(surface, (250, 160, 40), R(0.18, 0.15, 0.64, 0.85))
        pygame.draw.rect(surface, (255, 255, 255), R(0.28, 0.45, 0.44, 0.3))
        pygame.draw.circle(surface, (230, 80, 60), _P(x + 0.5 * w, y + 0.6 * h), max(2, int(rx(0.11 * w))))
        pygame.draw.rect(surface, INK, R(0.18, 0.15, 0.64, 0.85), edge)
        pygame.draw.line(surface, (60, 150, 220), _P(x + 0.62 * w, y + 0.15 * h), _P(x + 0.72 * w, y),
                         max(2, rs(0.06 * w)))


def draw_pictures(surface, g, area):
    """Pictures side by side, bottom-aligned; an item with number k is k times as wide AND k times as tall."""
    t = g["title"].lower()
    kind = ("book" if "book" in t else "tree" if "tree" in t else "cookie" if "cookie" in t else "juice")
    items = g["items"]
    _txt(surface, g["title"], 32, _P(area.centerx, area.y + 22))
    base_y = area.bottom - 85
    total_k = sum(k for _, k in items)
    gap = 80
    s = min((area.h - 150) / max(k for _, k in items), (area.w - 120 - gap * (len(items) - 1)) / total_k)
    s *= 0.92
    x = area.centerx - (s * total_k + gap * (len(items) - 1)) / 2
    for label, k in items:
        size = s * k
        _draw_icon(surface, kind, x, base_y - size, size, size)
        for j, line in enumerate(label.split("\n")):
            _txt(surface, line, 24, _P(x + size / 2, base_y + 22 + 28 * j))
        x += size + gap


BIG_VISUALS = ("grid", "graph", "bars", "pics", "lgraph")    # these use the whole panel


BATTLE_H = 720                                  # the battle area above the text box


def draw_visual_panel(surface, visual):
    left, top, w, h = PANEL.x, PANEL.y, PANEL.w, PANEL.h
    if not any(k in visual for k in BIG_VISUALS):
        # short info / table only: a pop-up sized to fit, exactly in the middle of the battle area
        notes = visual.get("notes", [])
        h = 35 + 44 * len(notes)
        widths = [get_font(fit_size(n, 28, PANEL.w - 60)).size(n)[0] for n in notes]
        if "table" in visual:
            h += 15 + 56 * len(visual["table"]["rows"]) + 15
            widths.append(_table_size(visual["table"])[3])
        w = min(PANEL.w, max([420] + [wd + 80 for wd in widths]))
        left, top = (BASE_W - w) // 2, (BATTLE_H - h) // 2
    box = pygame.Rect(*_P(left, top), rx(w), ry(h))
    pygame.draw.rect(surface, (250, 250, 245), box)
    pygame.draw.rect(surface, INK, box, max(1, rs(3)))
    y = top + 25
    for line in visual.get("notes", []):
        size = fit_size(line, 28, PANEL.w - 60)
        _txt(surface, line, size, _P(BASE_W // 2, y + 12))
        y += 44
    if "table" in visual:
        y = draw_table(surface, visual["table"], BASE_W // 2, y + 15) + 25
    if "grid" in visual:
        size = min(PANEL.bottom - y - 30, 640)
        draw_grid(surface, visual["grid"], PANEL.centerx, y + 10, size)
    if "graph" in visual:
        draw_context_graph(surface, visual["graph"],
                           pygame.Rect(PANEL.x + 60, y, PANEL.w - 120, PANEL.bottom - y - 10))
    chart_area = pygame.Rect(PANEL.x + 30, y, PANEL.w - 60, PANEL.bottom - y - 10)
    if "bars" in visual:
        draw_bar_chart(surface, visual["bars"], chart_area)
    if "lgraph" in visual:
        draw_line_chart(surface, visual["lgraph"], chart_area)
    if "pics" in visual:
        draw_pictures(surface, visual["pics"], chart_area)


def build_visual_surface(visual):
    """The visual drawn once onto a see-through, screen-sized surface (reused every frame)."""
    surf = pygame.Surface((curr_w, curr_h), pygame.SRCALPHA)
    draw_visual_panel(surf, visual)
    return surf


def draw_visual_overlay(screen, surf):
    """Dims the battle area a little, then shows the visual on top (the text box stays clear)."""
    dim = pygame.Surface((curr_w, ry(BATTLE_H)), pygame.SRCALPHA)
    dim.fill((0, 0, 0, 90))
    screen.blit(dim, (0, 0))
    screen.blit(surf, (0, 0))
