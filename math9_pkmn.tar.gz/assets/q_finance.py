# ==========================================
# q_finance.py  -  Math 9 questions: Financial Literacy (Week 13)
#   topic 1  W13L1  Planned Purchases
#   topic 2  W13L2  Simple Interest (banking)
#   topic 3  W13L3  Budgets & Savings
#
#   Rules every question follows:
#     - one true answer; wrong answers are real mistakes of the same kind and size
#     - no shortcut (longest, odd one out, middle number, a remembered answer) finds the answer
#     - why(...) gives the worked solution shown after a wrong answer
#   Tax: 12% in stores (5% GST + 7% PST); restaurant meals have 5% GST only.
#   Game entry points: make_question_typed(n), make_question(n) (at the bottom).
# ==========================================
import math
import random
from fractions import Fraction as F

from q_tools import (build, build_fixed, build_num, two_way, ask, info, fnum, money, r2, nice, as_money,
                     as_cents, as_units, as_pct, pos_int, NAMES, Picker, why)

STORE = F(112, 100)
CAFE = F(105, 100)


def off(p):
    """p% off -> the multiplier for the sale price."""
    return 1 - F(p, 100)


def d4(v):
    """A decimal with up to 4 places: 0.035, 0.952, 0.7."""
    s = f"{float(v):.4f}".rstrip("0").rstrip(".")
    return s or "0"


def as_dec(vals):
    return [d4(v) for v in vals]


def div(a, b):
    """a / b for a solution: '2.5', or '14.53...' when it doesn't come out even."""
    q = F(a) / F(b)
    return d4(r2(q)) + ("" if r2(q) == q else "...")


def cents_ok(v):
    return v > 0 and nice(v, 100)


def weeks_ok(v):
    return pos_int(v) and 1 <= v < 300


def around(ans, step, n=4):
    """Values a few steps either side: same size as the answer, so the answer can be anywhere in order."""
    return [ans + step * i for i in range(-n, n + 1) if i]


def ceil(v):
    return math.ceil(F(v))


def other(w, a, b):
    return b if w == a else a


# ==========================================
# 1. PLANNED PURCHASES
# ==========================================
ITEMS = [("hoodie", 40, 90), ("pair of shoes", 60, 160), ("video game", 50, 90), ("backpack", 30, 80),
         ("pair of headphones", 40, 200), ("skateboard", 60, 140), ("winter jacket", 80, 220),
         ("phone case", 16, 40), ("basketball", 24, 60), ("bike helmet", 40, 90), ("tablet", 200, 450),
         ("guitar", 120, 300), ("pair of jeans", 40, 90), ("watch", 50, 180)]
SALES = [10, 15, 20, 25, 30, 40, 50]
CLEARANCE = [60, 70, 75]
MEALS = ["a family dinner", "a pizza night", "a team lunch", "a birthday dinner", "a sushi dinner",
         "a burger lunch"]


def price(lo, hi):
    """A store price: usually whole dollars, sometimes $x.99 or $x.50."""
    p = F(random.randint(lo, hi))
    r = random.random()
    if r < 0.25:
        p -= F(1, 100)
    elif r < 0.4:
        p -= F(1, 2)
    return p


def item():
    name, lo, hi = random.choice(ITEMS)
    return name, price(lo, hi)


def item_on_sale(offs=SALES):
    """(name, price, percent off) where the sale price is an exact number of cents."""
    for _ in range(500):
        name, P = item()
        p = random.choice(offs)
        if nice(P * off(p), 100):
            return name, P, p
    return "hoodie", F(60), 25


def near(p, steps=(-10, -5, 5, 10)):
    """Nearby percents: the right answer to a similar question, so not a giveaway."""
    return [p + d for d in steps if 0 < p + d < 100]


def q1_multiplier():                                 # E  one number to multiply by
    kind = random.choice(["off", "off", "saved", "both", "both", "tax"])
    p = random.choice(SALES + CLEARANCE)
    if kind == "off":
        ans = off(p)
        traps = [F(p, 100), off(p) * STORE] + [off(q) for q in near(p, (-20, -15, -10, -5, 5, 10, 15, 20))]
        text = f"A store has {p}% off. What do you multiply the price by to get the sale price?"
        w = f"{p}% off means you pay {100 - p}% of the price.  {100 - p}% = {d4(ans)}."
    elif kind == "saved":
        ans = F(p, 100)
        traps = [off(p), F(p, 100) * STORE] + [F(q, 100) for q in near(p, (-20, -15, -10, -5, 5, 10, 15, 20))]
        text = f"A store has {p}% off. What do you multiply the price by to find the amount saved?"
        w = f"You save {p}% of the price.  {p}% = {d4(ans)}.  ({d4(off(p))} would give the sale price.)"
    elif kind == "tax":
        ans, text, w, traps = random.choice([
            (STORE, "A store adds 12% tax (5% GST + 7% PST). What do you multiply the price by to get the total?",
             "With 12% tax you pay 100% + 12% = 112% of the price.  112% = 1.12.", [F(12, 100), CAFE, F(5, 100), F(107, 100)]),
            (F(12, 100), "A store adds 12% tax. What do you multiply the price by to find just the tax?",
             "The tax is 12% of the price.  12% = 0.12.  (1.12 would give the total.)", [STORE, F(5, 100), CAFE, F(7, 100)]),
            (CAFE, "Restaurant meals have 5% GST only. What do you multiply the bill by to get the total?",
             "With 5% GST you pay 100% + 5% = 105% of the bill.  105% = 1.05.  (No PST on restaurant meals.)",
             [STORE, F(5, 100), F(12, 100), F(107, 100)]),
            (F(5, 100), "Restaurant meals have 5% GST only. What do you multiply the bill by to find just the tax?",
             "The GST is 5% of the bill.  5% = 0.05.  (1.05 would give the total.)", [CAFE, F(12, 100), STORE, F(7, 100)])])
    else:
        tax, where = random.choice([(STORE, "store"), (STORE, "store"), (CAFE, "cafe")])
        if where == "cafe":
            p = random.choice([10, 15, 20, 25])
            text = f"A restaurant coupon gives {p}% off the bill, then 5% GST is added. What single number do you multiply by?"
        else:
            text = f"{p}% off, then 12% tax. What single number do you multiply the price by?"
        ans = off(p) * tax
        traps = [off(p) + tax - 1, off(p), F(p, 100) * tax, off(p) * (STORE + CAFE - tax)] + \
                [off(q) * tax for q in near(p, (-10, -5, 5, 10))]
        w = (f"{p}% off -> x {d4(off(p))}.  Tax -> x {d4(tax)}.  Multiply them: {d4(off(p))} x {d4(tax)} = "
             f"{d4(ans)}.  (Adding them gives the wrong number.)")
    return why(build_num(ask(text), ans, traps, fmt=as_dec, ok=lambda v: 0 < v < 2 and nice(v, 10000), extra=[]), w)


def q1_sale_price():                                 # E  sale price
    name, P, p = item_on_sale(SALES + CLEARANCE)
    ans = P * off(p)
    traps = [P * F(p, 100), P - p, r2(ans * STORE)]
    extra = [r2(P * off(q)) for q in near(p, (-15, -10, -5, 5, 10, 15))]
    word = "on clearance at" if p in CLEARANCE else "on sale for"
    return why(build_num(ask(f"A {money(P)} {name} is {word} {p}% off. What is the sale price (before tax)?"),
                         ans, traps, fmt=as_cents, ok=cents_ok, extra=extra),
               f"{p}% off -> pay {100 - p}%.  {money(P, True)} x {d4(off(p))} = {money(ans, True)}.")


def q1_total_tax():                                  # E  total with tax (store or restaurant)
    if random.random() < 0.6:
        name, P = item()
        ans = r2(P * STORE)
        traps = [P + 12, r2(P * F(12, 100)), r2(P * CAFE), r2(P / F(88, 100))]
        text = f"A {name} costs {money(P)} in a store. What is the total with tax?"
        w = f"Stores add 12% (5% GST + 7% PST).  {money(P, True)} x 1.12 = {money(ans, True)}  (nearest cent)."
    else:
        P = F(random.randint(1800, 14000), 100)
        ans = r2(P * CAFE)
        traps = [r2(P * STORE), P + 5, r2(P * F(5, 100)), r2(P / F(95, 100))]
        text = f"The restaurant bill for {random.choice(MEALS)} is {money(P, True)} before tax. What is the total with tax?"
        w = f"Restaurant meals have 5% GST only.  {money(P, True)} x 1.05 = {money(ans, True)}  (nearest cent)."
    extra = [r2(P * (1 + F(k, 100))) for k in (2, 3, 7, 8, 10, 14, 15, 17) if 1 + F(k, 100) not in (STORE, CAFE)]
    return why(build_num(ask(text), ans, traps, fmt=as_cents, ok=cents_ok, extra=extra), w)


def q1_sale_tax():                                   # M  sale, then tax
    name, P, p = item_on_sale()
    sale = P * off(p)
    ans = r2(sale * STORE)
    traps = [sale, r2(P * (off(p) + F(12, 100))), r2(P * STORE), r2(sale * CAFE)]
    extra = [r2(P * off(q) * STORE) for q in near(p, (-15, -10, -5, 5, 10, 15))]
    v = info(f"A {name} is {money(P)}. It is {p}% off. Then 12% tax (5% GST + 7% PST) is added at the till.")
    return why(build_num(ask("What is the final price?"), ans, traps, fmt=as_cents, ok=cents_ok, visual=v, extra=extra),
               f"Sale first: {money(P, True)} x {d4(off(p))} = {money(sale, True)}.  Then tax: "
               f"{money(sale, True)} x 1.12 = {money(ans, True)}.  (Don't add {p}% and 12%.)")


def q1_percent_off():                                # M  what percent off
    for _ in range(300):
        name, lo, hi = random.choice(ITEMS)
        P = F(random.randint(lo, hi))
        p = random.randrange(10, 81, 5)
        S = P * off(p)
        if nice(S, 100):
            break
    traps = [100 - p]
    extra = near(p, (-20, -15, -10, -5, 5, 10, 15, 20))
    return why(build_num(ask(f"A {name} is usually {money(P, True)}. It is on sale for {money(S, True)}. "
                             f"What percent off is that?"), p, traps, fmt=as_pct,
                         ok=lambda v: 5 <= v <= 85 and nice(v, 1), extra=extra),
               f"Saved = {money(P, True)} - {money(S, True)} = {money(P - S, True)}.  Percent off = saved / usual x 100"
               f" = {money(P - S, True)} / {money(P, True)} x 100 = {p}%.  ({100 - p}% is the part you pay.)")


def q1_better_deal():                                # M  which store is cheaper
    for _ in range(300):
        name, lo, hi = random.choice(ITEMS)
        PA = F(random.randint(lo, hi))
        p = random.choice([10, 15, 20, 25, 30, 40])
        PB = PA + random.choice([-10, -5, 5, 10, 15])
        d = random.choice([5, 8, 10, 12, 15, 20, 25])
        A, B = r2(PA * off(p)), PB - d
        if A != B and abs(A - B) >= 1 and PB > d:
            break
    win = "A" if A < B else "B"
    diff = abs(A - B)
    alts = [abs(PA - PB), abs(PA * F(p, 100) - d), abs(PA - p - B), abs(r2(PA * F(p, 100)) - B), diff + 5, diff * 2]
    alts = [r2(a) for a in alts if a]
    v = info(f"Store A: the {name} is {money(PA)} with {p}% off. Store B: the {name} is {money(PB)} with "
             f"{money(d)} off. (Same tax at both stores.)")
    return why(two_way(ask("Which store is cheaper, and by how much?"),
                       lambda a, w: f"Store {w}, by {money(a, True)}", diff, win, alts, other(win, "A", "B"), v),
               f"Store A: {money(PA)} x {d4(off(p))} = {money(A, True)}.  Store B: {money(PB)} - {money(d)} = "
               f"{money(B, True)}.  Store {win} is cheaper by {money(diff, True)}.")


def q1_afford():                                     # H  enough money?
    name, P, p = item_on_sale()
    sale = P * off(p)
    total = r2(sale * STORE)
    for _ in range(100):
        B = F(random.randint(int(total * F(8, 10)), int(total * F(12, 10)) + 1))
        if abs(B - total) >= 1:
            break
    yes = B >= total
    wrongs = [sale, r2(P * STORE), r2(P * (off(p) + F(12, 100)))]
    alts = [r2(abs(B - t)) for t in wrongs if t != total] + [r2(abs(B - total) + 5), r2(abs(B - total) + 10)]
    v = info(f"{random.choice(NAMES)} has {money(B)}. A {name} costs {money(P)} and is {p}% off. "
             f"12% tax is added at the till.")
    end = (f"{money(B)} - {money(total, True)} = {money(B - total, True)} left." if yes else
           f"{money(total, True)} - {money(B)} = {money(total - B, True)} short.")
    return why(two_way(ask("Can they afford it? How much is left over, or how much short?"),
                       lambda a, w: f"Yes, {money(a, True)} left" if w == "Y" else f"No, {money(a, True)} short",
                       r2(abs(B - total)), "Y" if yes else "N", alts, "N" if yes else "Y", v),
               f"Sale: {money(P, True)} x {d4(off(p))} = {money(sale, True)}.  Tax: x 1.12 = {money(total, True)}.  {end}")


TAG_CHOICES = ["Correct",
               "Took off $, not %",
               "Sale price = discount",
               "Tax on regular price",
               "Only 5% tax added"]


TAG_WHY = {TAG_CHOICES[1]: "it took off dollars instead of a percent",
           TAG_CHOICES[2]: "the sale price shown is the discount, not what you pay",
           TAG_CHOICES[3]: "the tax was worked out on the regular price, not the sale price",
           TAG_CHOICES[4]: "only 5% was added, but stores add 12%"}


def q1_check_tag():                                  # M  check a price tag (Price Tag Detective)
    for _ in range(300):
        name, P, p = item_on_sale()
        sale = P * off(p)
        total = r2(sale * STORE)
        tags = {TAG_CHOICES[0]: (sale, total),
                TAG_CHOICES[1]: (P - p, r2((P - p) * STORE)),
                TAG_CHOICES[2]: (P * F(p, 100), r2(P * F(p, 100) * STORE)),
                TAG_CHOICES[3]: (sale, r2(P * STORE)),
                TAG_CHOICES[4]: (sale, r2(sale * CAFE))}
        if len(set(tags.values())) == 5 and P - p > 0:
            break
    right = random.choice(TAG_CHOICES)
    s, t = tags[right]
    v = {"notes": [f"{name[0].upper() + name[1:]}: {money(P, True)}", f"Sale: {p}% off",
                   f"Sale price: {money(s, True)}", f"Total with 12% tax: {money(t, True)}"]}
    w = (f"Sale price: {money(P, True)} x {d4(off(p))} = {money(sale, True)}.  Total: {money(sale, True)} x 1.12 = "
         f"{money(total, True)}.  " + ("The tag is correct." if right == TAG_CHOICES[0] else
                                       f"The tag shows {money(s, True)} and {money(t, True)}: {TAG_WHY[right]}."))
    return why(build_fixed(ask("Check the price tag. Is it correct? If not, what went wrong?"), right, TAG_CHOICES, v), w)


# ==========================================
# 2. BANKING & SIMPLE INTEREST  (I = Prt)
# ==========================================
RS = [F(1), F(3, 2), F(2), F(5, 2), F(3), F(7, 2), F(4), F(9, 2), F(5), F(6)]
TS = [2, 3, 4, 5, 6, 8, 10]


def principal():
    return F(random.choice([random.randrange(200, 1001, 50), random.randrange(1000, 3001, 100)]))


def interest(P, r, t):
    return P * r / 100 * t


def account(kinds=("save", "save", "gic", "loan")):
    """(P, r, t, sentence, kind) with interest in whole cents."""
    for _ in range(300):
        P, r, t = principal(), random.choice(RS), random.choice(TS)
        if nice(interest(P, r, 1), 100):
            break
    who = random.choice(NAMES)
    kind = random.choice(kinds)
    s = {"save": f"{who} puts {money(P)} in a savings account that pays {fnum(r)}% simple interest per year.",
         "gic": f"{who} buys a {money(P)} GIC that pays {fnum(r)}% simple interest per year.",
         "loan": f"{who} borrows {money(P)} at {fnum(r)}% simple interest per year."}[kind]
    return P, r, t, s, kind


def q2_interest():                                   # M  I = Prt
    P, r, t, s, kind = account()
    I = interest(P, r, t)
    traps = [P * r * t, interest(P, r, 1), P + I, interest(P, r, t - 1), interest(P, r, t + 1)]
    extra = [interest(P, r + d, t) for d in (-1, F(-1, 2), F(1, 2), 1)] + [interest(P, r, t + k) for k in (-3, -2, 2, 3)]
    word = "is owed" if kind == "loan" else "is earned"
    return why(build_num(ask(f"How much interest {word} in {t} years?"), I, traps, fmt=as_money, ok=cents_ok,
                         visual=info(s), extra=extra),
               f"I = Prt.  r = {fnum(r)}% = {d4(r / 100)}.  I = {money(P)} x {d4(r / 100)} x {t} = {money(I)}.")


def q2_balance():                                    # M  balance (save or borrow)
    P, r, t, s, kind = account()
    I = interest(P, r, t)
    A = P + I
    traps = [I, P + interest(P, r, 1), P - I, P + interest(P, r, t - 1), P + interest(P, r, t + 1)]
    extra = [P + interest(P, r + d, t) for d in (-1, F(-1, 2), F(1, 2), 1)] + [P + interest(P, r, t + k) for k in (-3, -2, 2, 3)]
    text = (f"How much must be paid back after {t} years?" if kind == "loan"
            else f"What is the balance after {t} years?")
    return why(build_num(ask(text), A, traps, fmt=as_money, ok=cents_ok, visual=info(s), extra=extra),
               f"I = Prt = {money(P)} x {d4(r / 100)} x {t} = {money(I)}.  Then add it on: {money(P)} + {money(I)} "
               f"= {money(A)}.")


def q2_months():                                     # M  time in months
    for _ in range(300):
        P, r = principal(), random.choice(RS)
        m = random.choice([3, 4, 6, 8, 9, 15, 18, 30])
        I = interest(P, r, F(m, 12))
        if nice(I, 100):
            break
    who = random.choice(NAMES)
    traps = [interest(P, r, m), interest(P, r, 1), interest(P, r, F(m, 100))]
    extra = [interest(P, r, F(m + k, 12)) for k in (-6, -3, -2, -1, 1, 2, 3, 6)] + \
            [interest(P, r + d, F(m, 12)) for d in (-1, F(-1, 2), F(1, 2), 1)]
    extra = [x for x in extra if nice(x, 100)]
    return why(build_num(ask(f"{who} saves {money(P)} at {fnum(r)}% simple interest per year for {m} months. "
                             f"How much interest is earned?"), I, traps, fmt=as_money, ok=cents_ok, extra=extra),
               f"t must be in years: {m} months = {m} / 12 = {d4(F(m, 12))} years.  I = {money(P)} x {d4(r / 100)} x "
               f"{d4(F(m, 12))} = {money(I)}.")


def q2_compare():                                    # H  compare accounts (a fee or a bonus)
    for _ in range(500):
        P = F(random.randrange(500, 2501, 100))
        t = random.choice([1, 2, 3, 4, 5])
        lo, hi = sorted(random.sample(RS, 2))
        kind = random.choice(["fee", "fee", "bonus"])          # fee on the higher rate, or bonus on the lower
        x = F(random.choice([1, 2, 3, 4, 5])) if kind == "fee" else F(random.choice([10, 20, 25, 30, 40, 50]))
        hi_add = f" - 12 x {money(x)} x {t}" if kind == "fee" else ""
        lo_add = f" + {money(x)}" if kind == "bonus" else ""
        high = P + interest(P, hi, t) - (12 * x * t if kind == "fee" else 0)
        low = P + interest(P, lo, t) + (x if kind == "bonus" else 0)
        if low != high and nice(low, 100) and nice(high, 100) and 1 <= abs(low - high) <= 150:
            break
    hi_note = f"a {money(x)} monthly fee" if kind == "fee" else "no fee"
    lo_note = "no fee" if kind == "fee" else f"a {money(x)} bonus for opening it"
    accts = [(hi, hi_note, hi_add, high), (lo, lo_note, lo_add, low)]
    random.shuffle(accts)
    (ra, na, xa, A), (rb, nb, xb, B) = accts
    win = "A" if A > B else "B"
    diff = abs(A - B)
    plain = abs(interest(P, hi, t) - interest(P, lo, t))      # forgot the fee or bonus
    alts = ([plain, abs(plain - x * t), abs(plain - 12 * x), diff + 12 * x, diff * 2] if kind == "fee"
            else [plain, abs(plain - x * t), diff + x, diff * 2, abs(diff - 10)])
    alts = [r2(a) for a in alts if a]
    yrs = f"{t} year{'s' if t > 1 else ''}"
    v = info(f"Both accounts start with {money(P)} for {yrs}. "
             f"Account A: {fnum(ra)}% simple interest, {na}. Account B: {fnum(rb)}% simple interest, {nb}.")
    tip = "  A higher rate can still lose to a fee." if kind == "fee" and A < B and ra == hi or \
        kind == "fee" and B < A and rb == hi else ""
    return why(two_way(ask(f"Which account has more after {yrs}, and by how much?"),
                       lambda a, w: f"Account {w}, by {money(a, True)}", diff, win, alts, other(win, "A", "B"), v),
               f"A: {money(P)} + {money(P)} x {d4(ra / 100)} x {t}{xa} = {money(A, True)}.  "
               f"B: {money(P)} + {money(P)} x {d4(rb / 100)} x {t}{xb} = {money(B, True)}.  "
               f"Account {win} has {money(diff, True)} more.{tip}")


def eq_b(m, b, x="t", y="B"):
    return f"{y} = {fnum(m)}{x} + {fnum(b)}"


def q2_equation():                                   # M  balance equation (words or table)
    P, r, t, s, kind = account(("save", "gic"))
    m = interest(P, r, 1)
    step = 1
    if random.random() < 0.5:
        vis = info(s)
    else:
        step = random.choice([1, 2])
        years = [0, step, 2 * step, 3 * step]
        vis = {"notes": ["A savings account (simple interest)."],
               "table": {"rows": [("Year", [str(y) for y in years]),
                                  ("Balance ($)", [fnum(P + m * y) for y in years])]}}
    near_m = [x for x in (interest(P, r + d, 1) for d in (-1, F(-1, 2), F(1, 2), 1)) if x > 0 and nice(x, 100)]
    traps = [eq_b(m, P + m * step), eq_b(r if step == 1 else m * step, P)]
    extra = [eq_b(x, P) for x in near_m] + [eq_b(x, P + m * step) for x in near_m]
    src = (f"Interest each year = {money(P)} x {d4(r / 100)} = {money(m)}" if "table" not in vis else
           f"The balance goes up {money(m * step)} every {step} year{'s' if step > 1 else ''}, so {money(m)} a year")
    return why(build(ask("Which equation gives the balance B after t years?"), eq_b(m, P), traps, vis, extra),
               f"{src} (the rate of change).  Start (year 0) = {money(P)} (the constant).  So {eq_b(m, P)}.")


def q2_table():                                      # M  balance from a table (linear)
    for _ in range(300):
        P, r = principal(), random.choice(RS)
        m = interest(P, r, 1)
        if m.denominator == 1:
            break
    step = random.choice([1, 1, 2])
    years = [0, step, 2 * step, 3 * step]
    vis = {"notes": ["A savings account (simple interest)."],
           "table": {"rows": [("Year", [str(y) for y in years]), ("Balance ($)", [fnum(P + m * y) for y in years])]}}
    each = f"{money(m * step)} every {step} years = {money(m)} a year" if step > 1 else f"{money(m)} a year"
    if random.random() < 0.6:
        T = random.choice([8, 10, 12, 15, 20, 25])
        ans = P + m * T
        last = P + m * years[-1]
        traps = [m * T, last + m * T, P + m * step * T if step > 1 else P + m * (T - 1)]
        return why(build_num(ask(f"Use the table. What will the balance be after {T} years?"), ans, traps, fmt=as_money,
                             ok=cents_ok, visual=vis, extra=around(ans, m)),
                   f"The balance goes up {each}.  B = {fnum(m)}t + {fnum(P)}.  B = {fnum(m)}({T}) + {fnum(P)} = {money(ans)}.")
    traps = [r * step if step > 1 else m] + around(r, F(1, 2))
    return why(build_num(ask("Use the table. What is the simple interest rate per year?"), r, traps, fmt=as_pct,
                         ok=lambda v: 0 < v <= 30 and nice(v, 10), visual=vis, extra=[]),
               f"The balance goes up {each}.  Rate = {money(m)} / {money(P)} x 100 = {fnum(r)}%.")


# ==========================================
# 3. BUDGETS & SAVINGS
# ==========================================
EXPENSES = [("Phone plan", 35, 65), ("Bus pass", 40, 55), ("Eating out", 30, 120), ("Clothes", 25, 100),
            ("Streaming", 10, 20), ("Gym", 20, 45), ("Movies", 15, 40), ("Gifts", 15, 60), ("Snacks", 15, 50),
            ("Video games", 15, 70), ("Gas", 30, 80)]
FIXED = ["Rent", "Phone plan", "Bus pass", "Internet", "Streaming plan", "Gym membership", "Music lessons",
         "Car insurance"]
VARIABLE = ["Eating out", "Groceries", "Clothes", "Snacks", "Movies", "Gifts", "Gas for the car", "Concert tickets"]
SAVE_FOR = [("bike", 280, 600), ("laptop", 500, 1100), ("concert ticket", 80, 220), ("phone", 400, 1000),
            ("pair of skis", 300, 700), ("gaming console", 350, 650), ("guitar", 150, 400), ("camera", 250, 700)]


def q3_budget():                                     # E  saving or overspending
    while True:
        rows = [(n, random.randint(lo, hi)) for n, lo, hi in random.sample(EXPENSES, random.randint(3, 5))]
        spend = sum(v for _, v in rows)
        gap = random.randint(5, 120) * random.choice([1, 1, -1])
        income = spend + gap
        if income >= 150:                            # a real part-time income
            break
    word = "S" if gap > 0 else "O"
    small = min(v for _, v in rows)
    alts = [abs(gap) + small, abs(abs(gap) - small), abs(gap) + 10, abs(abs(gap) - 10), abs(gap) * 2]
    alts = [a for a in alts if a]
    vis = {"notes": [f"Monthly income (part-time job): ${income}"],
           "table": {"rows": [("Expense", ["Cost"])] + [(n, [f"${v}"]) for n, v in rows]}}
    end = (f"Income is bigger: ${income} - ${spend} = ${gap} left to save." if gap > 0 else
           f"Expenses are bigger: ${spend} - ${income} = ${-gap} overspent.")
    return why(two_way(ask("Is this monthly budget saving or overspending? By how much?"),
                       lambda a, w: f"Saving ${fnum(a)} a month" if w == "S" else f"Overspending by ${fnum(a)}",
                       abs(gap), word, alts, "O" if word == "S" else "S", vis),
               f"Expenses: {' + '.join(str(v) for _, v in rows)} = ${spend}.  {end}")


def q3_fixed_variable():                             # E  fixed or variable expense
    if random.random() < 0.5:
        right, traps = random.choice(FIXED), random.sample(VARIABLE, 4)
        text = "Which is a FIXED expense (the same amount every month)?"
        w = f"{right}: the same amount every month, so it is fixed.  The others change from month to month (variable)."
    else:
        right, traps = random.choice(VARIABLE), random.sample(FIXED, 4)
        text = "Which is a VARIABLE expense (changes from month to month)?"
        w = f"{right}: the amount changes from month to month, so it is variable.  The others are set amounts (fixed)."
    return why(build(ask(text), right, traps), w)


def q3_weeks():                                      # M  weeks to save (round up)
    for _ in range(300):
        thing, lo, hi = random.choice(SAVE_FOR)
        P = random.randint(lo, hi)
        s = random.choice([15, 20, 25, 30, 35, 40, 45, 50, 60, 75])
        if 5 <= P / s <= 30 and (P % s or random.random() < 0.2):
            break
    ans = ceil(F(P, s))
    traps = [P // s, ceil(r2(P * STORE) / s)]
    who = random.choice(NAMES)
    end = (f"Not a whole number: after {P // s} weeks there is only ${s * (P // s)}.  Round up: {ans} weeks."
           if P % s else f"Exactly {ans} weeks.")
    return why(build_num(ask(f"{who} saves ${s} each week for a ${P} {thing} (tax included). "
                             f"How many weeks until {who} can buy it?"), ans, traps, fmt=as_units("weeks"),
                         ok=weeks_ok, extra=around(ans, 1)),
               f"{P} / {s} = {div(P, s)}  {end}")


def q3_weeks_tax():                                  # H  weeks to save (tax + savings)
    for _ in range(300):
        thing, lo, hi = random.choice(SAVE_FOR)
        P = random.randint(lo, hi)
        B = random.randint(2, 15) * 10
        s = random.choice([15, 20, 25, 30, 40, 50, 60])
        T = r2(P * STORE)
        need = T - B
        if need > 0 and 5 <= need / s <= 30 and (need / s).denominator != 1:
            break
    ans = ceil(need / s)
    traps = [ceil((P - B) / s), ceil(T / s), ans - 1, ceil((T + B) / s)]
    who = random.choice(NAMES)
    v = info(f"{who} wants a ${P} {thing}. 12% tax is added. {who} has ${B} saved and saves ${s} each week.")
    return why(build_num(ask("How many more weeks until they can buy it?"), ans, traps, fmt=as_units("weeks"),
                         ok=weeks_ok, visual=v, extra=around(ans, 1)),
               f"With tax: ${P} x 1.12 = {money(T, True)}.  Still needed: {money(T, True)} - ${B} = "
               f"{money(need, True)}.  {money(need, True)} / ${s} = {div(need, s)}  Round up: {ans} weeks.")


def eq_s(m, b):
    return f"S = {fnum(m)}w + {fnum(b)}"


def q3_equation():                                   # M  savings equation
    who = random.choice(NAMES)
    if random.random() < 0.5:
        for _ in range(300):
            s = random.randrange(10, 101, 5)
            E = s + random.randrange(10, 81, 5)
            B = random.randrange(5, 101, 5)
            if len({s, E, B}) == 3:
                break
        v = info(f"{who} earns ${E} a week and saves ${s} of it. {who} already has ${B} saved.")
        traps = [eq_s(x, y) for x, y in [(E, B), (B, s), (s, E), (E, s), (B, E)]]
        w = f"Only the ${s} saved each week adds to the savings: it goes with w.  The start (${B}) is the constant."
    else:
        for _ in range(300):
            B = random.randrange(5, 151, 5)
            s = random.randrange(10, 81, 5)
            k = random.choice([3, 4, 5, 6, 8])
            S2 = B + s * k
            if s != B and S2 % k == 0:
                break
        v = info(f"{who} had ${B} saved, then saved the same amount every week. After {k} weeks {who} had ${S2}.")
        traps = [eq_s(S2 - B, B), eq_s(s, S2), eq_s(S2 // k, B), eq_s(k, B), eq_s(S2 - B, S2)]
        w = (f"Saved in {k} weeks: ${S2} - ${B} = ${S2 - B}, so ${S2 - B} / {k} = ${s} a week (the rate).  "
             f"Start: ${B} (the constant).")
    return why(build(ask("Which equation gives the savings S after w weeks?"), eq_s(s, B), traps, v),
               f"{w}  So {eq_s(s, B)}.")


def q3_percent_income():                             # M  save a percent of income
    for _ in range(300):
        I = random.randrange(300, 1601, 20)
        p = random.choice([10, 15, 20, 25, 30, 40])
        save = F(I * p, 100)
        G = random.randrange(200, 1501, 25)
        if save.denominator == 1 and 5 <= G / save <= 24:
            break
    if random.random() < 0.4:
        traps = [I - save, save * 10, F(I, p)]
        extra = [F(I * q, 100) for q in near(p, (-15, -10, -5, 5, 10, 15)) if q != p]
        return why(build_num(ask(f"You earn ${I} a month and save {p}% of it. How much do you save each month?"),
                             save, traps, fmt=as_money, ok=cents_ok, extra=extra),
                   f"{p}% = {d4(F(p, 100))}.  ${I} x {d4(F(p, 100))} = {money(save)} each month.")
    ans = ceil(G / save)
    traps = [G // save, ceil(F(G, I - save))]
    end = f"Round up: {ans} months." if G % save else f"Exactly {ans} months."
    return why(build_num(ask(f"You earn ${I} a month and save {p}% of it. How many months until you have ${G}?"),
                         ans, traps, fmt=as_units("months"), ok=lambda v: pos_int(v) and 3 <= v <= 26, extra=around(ans, 1)),
               f"Each month: ${I} x {d4(F(p, 100))} = {money(save)}.  ${G} / {money(save)} = {div(G, save)}  {end}")


EVENTS = [("a lunch to welcome a Knowledge Keeper", "Lunch", [("Thank-you gift and honorarium", 100, 250, 25),
                                                              ("Plates, cups, napkins", 20, 50, 1)]),
          ("a Grade 9 year-end barbecue", "Food", [("Park shelter rental", 40, 120, 5), ("Games and prizes", 20, 80, 1)]),
          ("a class movie night", "Snacks", [("Movie licence", 50, 120, 5), ("Decorations", 15, 40, 1)]),
          ("a school dance", "Snacks and drinks", [("DJ", 150, 350, 25), ("Decorations", 30, 90, 1)]),
          ("a food bank fundraiser dinner", "Food", [("Hall rental", 80, 200, 10), ("Printing posters", 15, 40, 1)])]


def q3_event():                                      # H  event budget (Event Planner)
    event, food, items = random.choice(EVENTS)
    c = random.choice([F(2), F(5, 2), F(3), F(7, 2), F(4), F(9, 2), F(5), F(6), F(7)])
    n = random.choice([40, 50, 60, 75, 80, 100, 120])
    costs = [(name, random.randint(lo // st, hi // st) * st) for name, lo, hi, st in items]
    fixed = sum(v for _, v in costs)
    total = c * n + fixed
    fund = random.randint(5, 20) * 10
    s = random.choice([30, 40, 45, 50, 55, 60, 75])
    vis = info("\n".join([f"Your class is planning {event} for {n} guests (prices include tax).",
                           f"{food}: {money(c, True)} per guest"] + [f"{name}: ${v}" for name, v in costs] +
                          [f"Class fund: ${fund}. Fundraising: ${s} a week."]))
    kind = random.choice(["total", "weeks", "guests"])
    if kind == "total":
        traps = [c + fixed, total - costs[0][1], total - costs[1][1], total - fund]
        extra = [c * (n + k) + fixed for k in (-20, -10, -5, 5, 10, 20)]
        return why(build_num(ask("What is the total cost of the event?"), total, traps, fmt=as_money, ok=cents_ok,
                             visual=vis, extra=extra),
                   f"{food}: {money(c, True)} x {n} = {money(c * n)}.  Add the rest: {money(c * n)} + "
                   f"{' + '.join(f'${v}' for _, v in costs)} = {money(total)}.")
    if kind == "weeks":
        need = total - fund
        if need <= 0:
            return None
        ans = ceil(need / s)
        traps = [ceil(total / s), ans - 1 if need % s else None, ceil((total + fund) / s)]
        return why(build_num(ask("How many weeks of fundraising does the class need?"), ans, traps,
                             fmt=as_units("weeks"), ok=weeks_ok, visual=vis, extra=around(ans, 1)),
                   f"Total: {money(c, True)} x {n} + {' + '.join(f'${v}' for _, v in costs)} = {money(total)}.  "
                   f"Still needed: {money(total)} - ${fund} = {money(need)}.  {money(need)} / ${s} = {div(need, s)}  "
                   f"Round up: {ans} weeks.")
    k = random.choice([10, 15, 20, 25])
    ans = c * k
    traps = [c * (n + k), c * k + fixed, total + c * k]
    extra = [c * (k + d) for d in (-10, -5, 5, 10)] + [(c + d) * k for d in (-1, F(-1, 2), F(1, 2), 1)]
    return why(build_num(ask(f"{k} more guests are coming. How much more will the event cost?"), ans, traps,
                         fmt=as_money, ok=cents_ok, visual=vis, extra=extra),
               f"Only the {food.lower()} changes with the number of guests (variable).  {k} x {money(c, True)} = "
               f"{money(ans)} more.  The other costs stay the same (fixed).")


# ==========================================
# 4. QUESTION MIX
# ==========================================
GENERATORS = {     # topic: [(generator, question type shown in the Sheet), ...]
    1: [(q1_multiplier, "Multipliers"),
        (q1_sale_price, "Sale price"),
        (q1_total_tax, "Total with tax"),
        (q1_sale_tax, "Sale, then tax"),
        (q1_percent_off, "What percent off?"),
        (q1_better_deal, "Which deal is better?"),
        (q1_afford, "Can they afford it?"),
        (q1_check_tag, "Check the price tag")],
    2: [(q2_interest, "Interest (I = Prt)"),
        (q2_balance, "Balance after t years"),
        (q2_months, "Time in months"),
        (q2_compare, "Compare accounts (fees)"),
        (q2_equation, "Balance equation"),
        (q2_table, "Balance from a table")],
    3: [(q3_budget, "Saving or overspending?"),
        (q3_fixed_variable, "Fixed or variable"),
        (q3_weeks, "Weeks to save"),
        (q3_weeks_tax, "Weeks to save (tax + savings)"),
        (q3_equation, "Savings equation"),
        (q3_percent_income, "Save a percent of income"),
        (q3_event, "Event budget")],
}
TOPIC_COUNT = 3
_picker = Picker(GENERATORS)


def make_question(n):
    """(text, correct, 5 choices, visual or None) for topic n (1-3)."""
    return _picker.make(n)[:4]


def make_question_typed(n):
    """Same, plus the question type's name and the worked solution."""
    return _picker.make(n)
