# ==========================================
# q_tools.py  -  Shared helpers for the question files (q_statistics.py, q_finance.py, ...)
#   (No pygame here: question making only.)
#
#   The formatting and choice-building helpers are the same ones q_linear.py uses
#   (imported from there, so a fix in one place fixes every unit).  Added here:
#     ask(text)        the question for the text box (split into 2 lines if long)
#     info(text)       a "Show Info" panel: {"notes": [lines]}
#     wrap(text, w)    text -> list of lines of at most w characters
#     build_fixed(...) the same 5 choices every time, in the same order (e.g. 5 sampling methods)
#     why(q, text)     attaches the worked solution to a question
#     Picker           picks question types for each topic: no repeats, never the same type twice in a row
#     r0, r2, pct, as_cents
#
#   A question file lists  GENERATORS = {topic: [(generator, "type name"), ...]}  and
#   makes  _picker = Picker(GENERATORS).  _picker.make(n) returns
#     (text, correct, [5 choices], visual or None, type name, worked solution)
# ==========================================
import math
import random
from fractions import Fraction as F

from q_linear import (Question, nice, fnum, money, two_way, build, build_num,
                      as_plain, as_money, as_units, as_pct, as_prefix, pos_int, NAMES)

__all__ = ["Question", "nice", "fnum", "money", "two_way", "build", "build_num", "build_fixed",
           "as_plain", "as_money", "as_cents", "as_units", "as_pct", "as_prefix", "pos_int", "NAMES",
           "ask", "info", "wrap", "pct", "r0", "r2", "why", "Picker"]


# ==========================================
# 1. ROUNDING AND FORMATTING
# ==========================================
def _round_half_up(v, q):
    v = F(v)
    sign = -1 if v < 0 else 1
    return sign * F(math.floor(abs(v) * q + F(1, 2)), q)


def r0(v):
    """Nearest whole number (0.5 rounds up), as a Fraction."""
    return _round_half_up(v, 1)


def r2(v):
    """Nearest cent / hundredth (0.005 rounds up), as a Fraction."""
    return _round_half_up(v, 100)


def pct(v):
    """37.5 -> '37.5%'."""
    return f"{fnum(v)}%"


def as_cents(vals):
    """Money always with cents: '$45', '$7.5' -> '$45.00', '$7.50'."""
    return [money(v, True) for v in vals]


# ==========================================
# 2. TEXT: the question line and the info panel
# ==========================================
ASK_ONE_LINE = 64           # longer questions are split into 2 lines (the text box shows 2 at most)
ASK_LINE_MAX = 78           # a line longer than this (in a 2-line question) would be shrunk too small


def ask(text):
    """The question for the text box.  A long question is split at the space nearest its middle;
    a question already split with '\\n' keeps its split unless a line is too long."""
    lines = text.split("\n")
    if len(lines) == 1 and len(text) <= ASK_ONE_LINE:
        return text
    if len(lines) == 2 and max(len(l) for l in lines) <= ASK_LINE_MAX:
        return text
    text = " ".join(" ".join(lines).split())
    mid = len(text) // 2
    spaces = [i for i, ch in enumerate(text) if ch == " "]
    if not spaces:
        return text
    cut = min(spaces, key=lambda i: abs(i - mid))
    return text[:cut] + "\n" + text[cut + 1:]


def wrap(text, width=60):
    """Text -> lines of at most `width` characters (a '\\n' always starts a new line)."""
    lines = []
    for para in str(text).split("\n"):
        line = ""
        for word in para.split():
            if line and len(line) + 1 + len(word) > width:
                lines.append(line)
                line = word
            else:
                line = f"{line} {word}" if line else word
        lines.append(line)
    return lines


def info(text, width=60):
    """A situation shown with the yellow "Show Info" button."""
    return {"notes": wrap(text, width)}


# ==========================================
# 3. CHOICES
# ==========================================
def build_fixed(text, correct, choices, visual=None):
    """The same 5 choices every time, in the same order (so where an answer sits gives nothing away)."""
    choices = list(choices)
    if correct not in choices or len(choices) != 5 or len(set(choices)) != 5:
        return None
    return Question(text, correct, choices, visual)


def why(q, solution):
    """Attach the worked solution (shown after a wrong answer).  Keeps None as None."""
    return None if q is None else (q, solution)


# ==========================================
# 4. PICKER
# ==========================================
class Picker:
    """
    Picks a question type for a topic (all types equally often), never the same type
    twice in a row, and never a question already asked in this visit.
    A type that can't make a question this time (returns None, or fails) is just tried again.
    """
    STRICT = False          # True: let a failing question type crash (for testing only)

    def __init__(self, generators):
        self.generators = generators
        self.seen = {n: set() for n in generators}
        self.last = {}

    def make(self, n):
        types = self.generators[n]
        for attempt in range(400):
            gen, name = random.choice(types)
            if gen is self.last.get(n) and attempt < 200 and len(types) > 1:
                continue
            try:
                made = gen()
            except Exception:
                if self.STRICT:
                    raise
                continue
            if made is None:
                continue
            q, solution = made if isinstance(made, tuple) else (made, "")
            if q is None:
                continue
            opts = list(q.options)
            if q.correct not in opts or len(opts) != 5 or len(set(opts)) != 5:
                continue
            key = q.key()
            if key in self.seen[n] and attempt < 300:
                continue
            self.seen[n].add(key)
            self.last[n] = gen
            return q.text, q.correct, opts, q.visual, name, solution
        raise RuntimeError(f"could not make a question for topic {n}")
