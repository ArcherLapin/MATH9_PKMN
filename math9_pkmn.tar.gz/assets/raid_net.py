# ==========================================
# raid_net.py  -  Class Raid: the rules and the online part.  (No pygame in this file.)
#   raid_battle.py draws the screens.  raid_test.py checks files and plays fake students.
#   To take Class Raid out of the game: delete raid_net.py, raid_battle.py and raid_test.py
#   (main.py hides the Class Raid button by itself).
#
# How a raid works
#   Everyone in a room fights the same Mewtwo, but each student's fight is 1-on-1:
#   answer -> your attack (if right) -> Mewtwo's turn (attacks you, or Recover after a wrong answer).
#   Each student only writes their OWN totals (damage dealt, HP Mewtwo recovered), so two
#   students attacking at the same moment can never overwrite each other:
#       Mewtwo's HP = full HP - everyone's damage + everyone's Recover
#   Nothing runs "the boss": every screen works out the same HP from the same numbers.
#   The class loses if the time runs out, or if everyone in the raid is fainted at the same moment
#   (Magikarp doesn't count: it can't help, and a teacher playing it shouldn't keep the raid alive).
#
# Database (same Firebase as Team Battle, its own folder, so nothing mixes):
#   tb/math9/raid/r1 ... r6          one room per unit review (r5 = Multistep Equations)
#       who/<id>    {m: Pokemon picked, j: joined, pk: when picked, t: heartbeat}
#       game        {id, start, mode, over: "win"/"lose",
#                    p/<id>: {m: Pokemon, g: game id, d: damage, h: Recover HP, a: answers,
#                             f: 1 = fainted right now, t: heartbeat}}
#   (no names: students are shown by their Pokemon)
# ==========================================
import random

import pokedex
import team_net as tn          # reused: the Firebase connection, clock sync and ids (nothing in it changes)

# ---------- Settings you can change ----------
BOSS = "Mewtwo"                # the raid boss (pokedex.py); everyone else can be picked
MAX_PLAYERS = 30               # most students in one room (also: at most this many Pokemon to pick)
RAID_MINUTES = 30              # the class loses if Mewtwo is still standing after this long
                               # (or if everyone is fainted at the same time)
PLAYER_HP = 300                # every student's Pokemon
PLAYER_POWER = 30              # damage for a correct answer (same as Team Battle)
STREAK_BONUS = 1.2             # x1.2 more for each correct answer in a row (same as Team Battle)...
STREAK_CAP = 2.0               # ...but never more than x2 (+100%)
CRIT_CHANCE = 5                # % chance a correct answer is a critical hit (x1.5)
NO_DAMAGE = {"Magikarp"}       # their attack does nothing: not counted in Mewtwo's HP or the ranking
RECOVER_HP = 30                # what Mewtwo's Recover heals (about one student hit)
REVIVE_STEP = 20               # fainted: each correct answer = 20% more HP when you get up
REVIVE_FULL = 5                # 5 correct answers = back up at 100% automatically
REST_SECONDS = 60              # fainted, first answer wrong: wait this long for a new question
TOP_N = 10                     # how many Pokemon the end-of-raid ranking shows

# Look and sound (file names next to main.py)
RAID_BACKGROUND = "background.jpg"                    # change to e.g. "raid_background.jpg" later
RAID_MUSIC = ["music_raid1.ogg", "music_raid2.ogg"]   # played most of the time...
RAID_MUSIC_CHANCE = 80                                # ...this % of the time
OTHER_MUSIC = [f"music{n}.ogg" for n in range(2, 11)] # otherwise one of these

# Difficulty = Mewtwo's HP, its damage and its Recover.  Tuned with raid_test.py (fake classes, 15-45 s
# per question) so that a class needs about 60% right on Easy, 70% on Medium, 80% on Hard: at that
# accuracy it wins in about 23 minutes; 10 points lower it usually runs out of time.
#   hp_per_player: Mewtwo's HP for each student who answers (Magikarp not counted)
#   power:   x Mewtwo's move power (pokedex.py)        recover: % chance of Recover after a wrong answer
MODES = {
    "easy":   {"name": "Easy",   "hp_per_player": 620, "power": 0.6,  "recover": 10},
    "medium": {"name": "Medium", "hp_per_player": 650, "power": 0.9,  "recover": 20},
    "hard":   {"name": "Hard",   "hp_per_player": 760, "power": 1.15, "recover": 30},
}
MODE_ORDER = ["easy", "medium", "hard"]
DEFAULT_MODE = "medium"

# ---------- Timing (milliseconds) ----------
POLL_MS = 1000                 # read the room this often
BEAT_MS = 3000                 # "I'm still here" this often
FRESH_MS = 12000               # no heartbeat for this long = left (their Pokemon can be picked again)
PURGE_MS = 60000               # old entries are deleted after this
START_GRACE_MS = 60000         # a new raid counts as going on for this long even before anyone answers
RAID_MS = RAID_MINUTES * 60 * 1000
REST_MS = REST_SECONDS * 1000

SV = tn.SV


def mode_info(mode):
    return MODES.get(mode, MODES[DEFAULT_MODE])


def roster():
    """The Pokemon students can pick: every pokedex.py entry with an "attack", except the boss
    (folder order).  A new Pokemon added to pokedex.py shows up here by itself."""
    names = [n for n, e in pokedex.POKEMON.items()
             if n != BOSS and e.get("folder") is not None and "attack" in e]
    return sorted(names, key=lambda n: pokedex.POKEMON[n]["folder"])[:MAX_PLAYERS]


def attack_of(mon):
    """(move name, effect) a student's Pokemon uses on a correct answer."""
    return pokedex.attack_name(mon), pokedex.info(mon).get("attack_effect", pokedex.PLAYER_ATTACK_EFFECT)


# ==========================================
# 1. ONE STUDENT'S FIGHT  (the same rules for the screen and for raid_test.py's fake students)
#   answer() returns the messages, in order:  (text, kind, amount, effect)
#     kind: None (just text), "boss_hit", "boss_heal", "boss_faint", "me_hit", "me_heal", "faint"
#     me_heal's amount is the HP after getting up.
# ==========================================
class Fighter:
    def __init__(self, mon, mode):
        self.mon, self.mode = mon, mode_info(mode)
        self.max_hp = self.hp = PLAYER_HP
        self.streak = 0
        self.fainted, self.revive, self.rest_until = False, 0, 0
        self.d = self.h = 0                      # damage dealt, HP Mewtwo recovered (after my wrong answers)
        self.answered = self.correct = self.wrong = 0

    def resting(self, now):
        return self.fainted and now < self.rest_until

    def can_get_up(self):
        return self.fainted and self.revive > 0

    def answer(self, ok, boss_hp, boss_max, now):
        """ok = answered correctly.  boss_hp / boss_max: Mewtwo right now (for Recover and the win)."""
        self.answered += 1
        if ok:
            self.correct += 1
        else:
            self.wrong += 1
        if self.fainted:
            return self._revive_answer(ok, now)
        out = []
        nm = self.mon
        if ok:
            move, effect = attack_of(nm)
            if nm in NO_DAMAGE:
                out += [(f"{nm} used {move}!", None, 0, None), ("But nothing happened!", None, 0, None)]
            else:
                mult = min(STREAK_BONUS ** self.streak, STREAK_CAP)
                if self.streak:
                    out.append((f"{nm} is pumped! (+{round((mult - 1) * 100)}%)", None, 0, None))
                power = round(PLAYER_POWER * mult)
                crit = random.randint(1, 100) <= CRIT_CHANCE
                dmg = int(power * 1.5) if crit else power
                out.append((f"{nm} used {move}!", None, 0, None))
                out.append((("A critical hit! " if crit else "") + f"It dealt {dmg} damage!", "boss_hit", dmg, effect))
                self.d += dmg
                boss_hp -= dmg
            self.streak += 1
            if boss_hp <= 0:
                out.append((f"{BOSS} fainted!", "boss_faint", 0, None))
                return out
        else:
            if self.streak:
                out.append((f"{nm} calms down (0%).", None, 0, None))
            self.streak = 0
        # Mewtwo's turn: after a wrong answer it sometimes uses Recover instead of attacking
        if not ok and boss_hp < boss_max and random.randint(1, 100) <= self.mode["recover"]:
            heal = min(RECOVER_HP, boss_max - boss_hp)
            self.h += heal
            out += [(f"{BOSS} used Recover!", None, 0, None),
                    (f"{BOSS} recovered {heal} HP!", "boss_heal", heal, None)]
            return out
        return out + self._boss_attack()

    def _boss_attack(self):
        mname, power, miss, crit, effect = random.choice(pokedex.moves(BOSS))
        out = [(f"{BOSS} used {mname}!", None, 0, None)]
        if random.randint(1, 100) <= miss:
            return out + [(f"{BOSS}'s attack missed!", None, 0, None)]
        dmg = int(power * self.mode["power"])
        text = f"It dealt {dmg} damage!"
        if random.randint(1, 100) <= crit:
            dmg = int(dmg * 1.5)
            text = f"A critical hit! It dealt {dmg} damage!"
        self.hp = max(0, self.hp - dmg)
        out.append((text, "me_hit", dmg, effect))
        if self.hp == 0:
            self.fainted, self.revive, self.streak = True, 0, 0
            out.append((f"{self.mon} fainted!", "faint", 0, None))
        return out

    def _revive_answer(self, ok, now):
        if ok:
            self.revive += 1
            if self.revive >= REVIVE_FULL:
                return self.get_up()
            return [(f"Recovery: {self.revive * REVIVE_STEP}%", None, 0, None)]
        if self.revive == 0:
            self.rest_until = now + REST_MS
            return [("Catch your breath: a new question in 1 minute.", None, 0, None)]
        return [("That one was wrong, so up you get!", None, 0, None)] + self.get_up()

    def get_up(self):
        """Get up now with 20% x correct answers (the button, a wrong answer, or 5 right)."""
        if not self.can_get_up():
            return []
        pct = min(100, self.revive * REVIVE_STEP)
        self.hp = max(1, self.max_hp * pct // 100)
        self.fainted, self.revive, self.streak, self.rest_until = False, 0, 0, 0
        return [(f"{self.mon} got back up with {self.hp} HP!", "me_heal", self.hp, None)]


# ==========================================
# 2. READING A ROOM  (plain functions: every screen gets the same answer)
# ==========================================
def _num(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool)


def fresh_who(room, now):
    """{id: entry} of everyone really in the room (lobby or raid)."""
    w = (room or {}).get("who") or {}
    return {pid: e for pid, e in w.items()
            if isinstance(e, dict) and _num(e.get("t")) and now - e["t"] <= FRESH_MS}


def taken(room, now):
    """{Pokemon: id of the student who has it}.  Two picks of the same one: the earlier pick wins."""
    best = {}
    for pid, e in fresh_who(room, now).items():
        m = e.get("m")
        if isinstance(m, str) and m:
            key = (e["pk"] if _num(e.get("pk")) else e["t"], pid)
            if m not in best or key < best[m][0]:
                best[m] = (key, pid)
    return {m: v[1] for m, v in best.items()}


def leader(room, now):
    """The first student still in the room: they choose the difficulty and press Start."""
    w = fresh_who(room, now)
    if not w:
        return None
    return min(w, key=lambda pid: (w[pid]["j"] if _num(w[pid].get("j")) else w[pid]["t"], pid))


def game_ok(game):
    return isinstance(game, dict) and isinstance(game.get("id"), str) and _num(game.get("start"))


def players(game):
    """{id: entry} of everyone who joined this raid."""
    p = (game or {}).get("p") or {}
    return {pid: e for pid, e in p.items() if isinstance(e, dict) and e.get("g") == game.get("id")
            and isinstance(e.get("m"), str)}


def game_active(game, now):
    """A raid is going on: started, not over, not past its time, and someone is still in it."""
    if not game_ok(game) or game.get("over"):
        return False
    if now > game["start"] + RAID_MS + 15000:
        return False
    if now - game["start"] < START_GRACE_MS:
        return True
    return any(_num(e.get("t")) and now - e["t"] <= FRESH_MS for e in players(game).values())


def _with_mine(game, me, mine):
    ps = dict(players(game))
    if me is not None and mine is not None:
        ps[me] = mine
    return ps


def boss_numbers(game, me=None, mine=None):
    """(Mewtwo's HP now, full HP).  mine = my own up-to-date entry (the server copy may lag a second).
    Full HP counts each Pokemon that has answered at least once (Magikarp never counts)."""
    ps = _with_mine(game, me, mine)
    counted = {e["m"] for e in ps.values() if (e.get("a") or 0) > 0 and e["m"] not in NO_DAMAGE}
    full = mode_info(game.get("mode"))["hp_per_player"] * max(1, len(counted))
    dmg = sum(int(e.get("d") or 0) for e in ps.values())
    heal = sum(int(e.get("h") or 0) for e in ps.values())
    return max(0, min(full, full - dmg + heal)), full


def ranking(game, me=None, mine=None):
    """Pokemon names, best first, by net damage (damage - Recover after their wrong answers). Top N."""
    net = {}
    for e in _with_mine(game, me, mine).values():
        if e["m"] in NO_DAMAGE or not (e.get("a") or 0):
            continue
        net[e["m"]] = net.get(e["m"], 0) + int(e.get("d") or 0) - int(e.get("h") or 0)
    order = sorted(net, key=lambda m: (-net[m], m))
    return order[:TOP_N]


def all_fainted(game, now, me=None, mine=None):
    """True if everyone still in the raid (who has answered at least once, Magikarp not counted)
    is fainted right now: the class loses."""
    team = [e for e in _with_mine(game, me, mine).values()
            if (e.get("a") or 0) > 0 and e["m"] not in NO_DAMAGE and _num(e.get("t")) and now - e["t"] <= FRESH_MS]
    return bool(team) and all(e.get("f") for e in team)


def time_left_ms(game, now):
    return max(0, game["start"] + RAID_MS - now)


def room_key(k):
    return f"r{k}"


# ==========================================
# 3. ONLINE: one room (lobby + raid)
# ==========================================
class Room:
    """Being in one raid room: my Pokemon pick, the lobby, and my totals during the raid."""
    def __init__(self, net, clock, k, me):
        self.net, self.clock, self.me = net, clock, me
        self.path = f"raid/{room_key(k)}"
        self.data = {}                       # the room as last read
        self.loaded = False
        self.mon, self.j, self.pk = "", None, None
        self.beat, self.next_beat = None, 0
        self.poll, self.next_poll = None, 0
        self.p_call, self.p_entry, self.p_dirty, self.p_next = None, None, False, 0
        self.lost = None                     # a Pokemon someone else got first (to tell the student)
        self.left = False

    # ----- lobby -----
    def pick(self, mon):
        if mon != self.mon:
            self.mon, self.pk, self.next_beat = mon, None, 0

    def leave(self):
        if not self.left:
            self.left = True
            self.net.delete(f"{self.path}/who/{self.me}")

    def who(self):
        return fresh_who(self.data, self.clock.now())

    def taken(self):
        return taken(self.data, self.clock.now())

    def my_pick(self):
        """My Pokemon once the room agrees it is mine, else None."""
        if self.mon and self.taken().get(self.mon) == self.me:
            return self.mon
        return None

    def is_leader(self):
        return leader(self.data, self.clock.now()) == self.me

    def leader_mon(self):
        lid = leader(self.data, self.clock.now())
        return (self.who().get(lid) or {}).get("m") or ""

    def game(self):
        """The raid going on in this room, or None."""
        g = self.data.get("game")
        return g if game_active(g, self.clock.now()) else None

    def game_by_id(self, gid):
        g = self.data.get("game")
        return g if game_ok(g) and g.get("id") == gid else None

    def start(self, mode):
        """The leader starts a new raid (replaces any finished one)."""
        if self.game() is not None or not self.is_leader():
            return False
        self.net.put(f"{self.path}/game", {"id": tn.new_id(), "start": SV, "mode": mode, "over": ""})
        self.next_poll = 0
        return True

    def end(self, gid, result):
        """Mark the raid won or lost (anyone may; the first one to arrive stays)."""
        g = self.game_by_id(gid)
        if g is not None and not g.get("over"):
            self.net.put(f"{self.path}/game/over", result)

    # ----- my totals during a raid -----
    def send(self, gid, fighter):
        """My up-to-date totals (sent right away, then with every heartbeat)."""
        self.p_entry = {"m": fighter.mon, "g": gid, "d": fighter.d, "h": fighter.h, "a": fighter.answered,
                        "f": 1 if fighter.fainted else 0}
        self.p_dirty = True

    def mine(self):
        """My entry as the room should see it (before the server copy catches up)."""
        if self.p_entry is None:
            return None
        return dict(self.p_entry, t=self.clock.now())

    # ----- every frame -----
    def update(self):
        if self.left:
            return
        t = self.clock.local()
        if (self.beat is None or self.beat.done) and t >= self.next_beat:
            self.beat = self.net.put(f"{self.path}/who/{self.me}",
                                     {"m": self.mon, "j": self.j or SV, "pk": self.pk or SV, "t": SV})
            self.next_beat = t + BEAT_MS
        if self.p_entry is not None and (self.p_call is None or self.p_call.done) and (self.p_dirty or t >= self.p_next):
            if self.p_call is not None and not self.p_call.ok:
                self.p_dirty = True                # didn't arrive: the next one carries the same totals
            self.p_call = self.net.put(f"{self.path}/game/p/{self.me}", dict(self.p_entry, t=SV))
            self.p_dirty, self.p_next = False, t + BEAT_MS
        if self.poll is None and t >= self.next_poll:
            self.poll = self.net.get(self.path)
        elif self.poll is not None and self.poll.done:
            if self.poll.ok:
                self.data = self.poll.data if isinstance(self.poll.data, dict) else {}
                self.loaded = True
                self._look()
            self.poll, self.next_poll = None, t + POLL_MS

    def _look(self):
        now = self.clock.now()
        mine = (self.data.get("who") or {}).get(self.me)
        if isinstance(mine, dict) and self.j is None and _num(mine.get("j")):
            self.j = mine["j"]                     # the server's own join time (kept from now on)
        if isinstance(mine, dict) and mine.get("m") == self.mon and self.mon:
            if self.pk is None and _num(mine.get("pk")):
                self.pk = mine["pk"]
            owner = taken(self.data, now).get(self.mon)
            if owner is not None and owner != self.me:
                self.lost, self.mon, self.pk, self.next_beat = self.mon, "", None, 0
        if self.is_leader():                       # the leader tidies up old entries
            for pid, e in (self.data.get("who") or {}).items():
                if not isinstance(e, dict) or not _num(e.get("t")) or now - e["t"] > PURGE_MS:
                    self.net.delete(f"{self.path}/who/{pid}")
