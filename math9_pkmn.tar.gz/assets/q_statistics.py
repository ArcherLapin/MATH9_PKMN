# ==========================================
# q_statistics.py  -  Math 9 questions: Statistics in Society (Week 12)
#   topic 1  W12L1  Populations & Samples
#   topic 2  W12L2  Bias in Collecting Data
#   topic 3  W12L3  Misleading Graphs
#   topic 4  W12L4  Percents in Data
#
#   Rules every question follows:
#     - one true answer; wrong answers are real mistakes of the same kind and size
#     - no shortcut (longest, odd one out, a key word, a "round" number) finds the answer
#     - why(...) gives the worked solution shown after a wrong answer
#   Game entry points: make_question_typed(n), make_question(n) (at the bottom).
# ==========================================
import random
import re
from fractions import Fraction as F

from q_tools import (build, build_fixed, build_num, ask, info, wrap, fnum, pct, r0, r2, nice,
                     as_units, as_pct, pos_int, NAMES, Picker, why)


# ==========================================
# 1. POPULATIONS & SAMPLES
# ==========================================
METHODS = ["Simple random", "Systematic", "Stratified", "Convenience", "Voluntary"]
FAIR = {"Simple random": True, "Systematic": True, "Stratified": True, "Convenience": False, "Voluntary": False}

TOPICS = ["a later school start", "a longer lunch break", "a new school logo", "more clubs after school",
          "a school garden", "the new cafeteria menu", "a no-phones rule in class", "the winter dance theme",
          "the library hours", "a school-wide reading time"]

PLACES = ["cafeteria", "library", "gym", "front hallway", "parking lot", "computer lab"]


def school_ctx():
    """(who wants to know, population size, what about)."""
    n = random.choice([400, 480, 500, 600, 720, 800, 900, 1000, 1200])
    who = random.choice(["The principal", "The student council", "The PAC", "The leadership class",
                         f"{random.choice(NAMES)} from the newspaper club"])
    return who, n, random.choice(TOPICS)


def plan(method, n_pop):
    """(long description for the info panel, short one for a choice)."""
    k = random.choice([d for d in (5, 8, 10, 12, 15, 20, 25) if n_pop % d == 0])
    m = n_pop // k
    g = random.choice([6, 8, 10, 12, 15, 20])
    place = random.choice(PLACES)
    friend = random.choice(NAMES)
    if method == "Simple random":
        return random.choice([
            (f"A computer picks {m} student numbers at random from all {n_pop} students.",
             f"Computer picks {m} at random"),
            (f"Every student's name goes in a hat and {m} names are drawn.", f"Draw {m} names from a hat"),
            (f"Each student gets a number, and a random number generator picks {m} of them.",
             f"{m} random student numbers"),
        ])
    if method == "Systematic":
        return random.choice([
            (f"From an alphabetical list of all {n_pop} students, every {k}th name is chosen.",
             f"Every {k}th name on the school list"),
            (f"Starting at a random spot on the school list, every {k}th student is picked.",
             f"Every {k}th student on the list"),
        ])
    if method == "Stratified":
        return random.choice([
            (f"{g} students are picked at random from each grade.", f"{g} at random from each grade"),
            (f"{g} students are chosen at random from each homeroom.", f"{g} at random from each homeroom"),
        ])
    if method == "Convenience":
        return random.choice([
            (f"The first {m} students who walk into the {place} are asked.", f"First {m} into the {place}"),
            (f"{friend} asks {g} friends at lunch.", f"{friend}'s {g} friends at lunch"),
            (f"Students in the {place} at lunch on Tuesday are asked.", f"Students in the {place} at lunch"),
        ])
    return random.choice([
        ("A poll is posted on the school's Instagram page.", "A poll on Instagram"),
        ("Anyone who wants to can drop an answer in a box by the office.", "A box anyone can use"),
        ("A survey is on the school website for anyone who wants to answer.", "An online survey, if you want"),
    ])


def p1_name_method():                                # M  name the sampling method
    method = random.choice(METHODS)
    who, n, topic = school_ctx()
    long, _ = plan(method, n)
    v = info(f"{who} wants to know what the school's {n} students think about {topic}.\nPlan: {long}")
    return why(build_fixed(ask("Name the sampling method."), method, METHODS, v), METHOD_WHY[method])


METHOD_WHY = {
    "Simple random": "Simple random: every student has the same chance, like names drawn from a hat "
                     "or a computer picking numbers.",
    "Systematic": "Systematic: go down a list and pick every kth person (every 5th, every 10th, ...).",
    "Stratified": "Stratified: split everyone into groups (grades, homerooms) and pick at random "
                  "from each group.",
    "Convenience": "Convenience: ask whoever is easy to reach (friends, people nearby). Not everyone "
                   "has a chance.",
    "Voluntary": "Voluntary: people choose to answer (a poll, a box, a website). Only people who care "
                 "will answer.",
}

FAIR_WHY = {
    "Simple random": "random picking gives every student the same chance",
    "Systematic": "every kth name on the full list gives every student the same chance",
    "Stratified": "picking at random from every group gives every student a chance",
}

FB_CHOICES = ["Fair: all have a chance", "Fair: anyone can answer",
              "Biased: only easy to reach", "Biased: only volunteers",
              "Biased: not a census"]


SNEAKY_LONG = {      # sound random, but only reach one place, friends or volunteers
    "Convenience": lambda n: random.choice([
        f"{random.choice([10, 15, 20])} students in the {random.choice(PLACES)} at lunch are picked at random.",
        f"{random.choice(NAMES)} picks {random.choice([8, 10, 12])} friends at random to ask.",
        f"A computer picks {random.choice([20, 25, 30])} random students from the ones at the bus stop.",
    ]),
    "Voluntary": lambda n: random.choice([
        f"{random.choice([20, 25, 30])} answers are picked at random from an Instagram poll.",
        f"{random.choice([20, 25, 30])} slips are drawn at random from a box anyone could use.",
        f"Students sign up if they want to, and {random.choice([20, 25, 30])} are picked at random.",
    ]),
}


def p1_fair():                                       # M  fair or biased, and why
    # the 3 possible right answers come up equally often
    kind = random.choice(["fair", "Convenience", "Voluntary"])
    method = random.choice(["Simple random", "Systematic", "Stratified"]) if kind == "fair" else kind
    who, n, topic = school_ctx()
    long, _ = plan(method, n)
    if not FAIR[method] and random.random() < 0.5:
        long = SNEAKY_LONG[method](n)
    right = FB_CHOICES[0] if FAIR[method] else (FB_CHOICES[2] if method == "Convenience" else FB_CHOICES[3])
    v = info(f"{who} wants to know what the school's {n} students think about {topic}.\nPlan: {long}")
    if FAIR[method]:
        w = f"{method} sample: {FAIR_WHY[method]}. So it is fair. A sample does not have to be a census."
    elif method == "Convenience":
        w = ("Convenience sample: only people who are easy to reach are asked. Others have no chance, even if "
             "the picking is 'random'. Biased.")
    else:
        w = ("Voluntary sample: only people who choose to answer (usually people with strong feelings), even "
             "if some are picked 'at random'. Biased.")
    return why(build(ask("Is this sample fair or biased? Why?"), right, [c for c in FB_CHOICES if c != right], v),
               w)


FAIRS = ["Simple random", "Systematic", "Stratified"]


def short_plan(method, n_pop, sneaky=False):
    """A short plan.  sneaky=True (convenience / voluntary): biased but shaped like a fair plan,
    e.g. 'random students in the gym', 'every 5th in the lunch line', 'volunteers from each grade'."""
    m = random.choice([20, 25, 30, 40, 50])
    k = random.choice([d for d in (5, 8, 10, 12, 15, 20, 25) if n_pop % d == 0])
    g = random.choice([4, 5, 6, 8, 10])
    place = random.choice(PLACES)
    name = random.choice(NAMES)
    if method == "Simple random":
        return random.choice([f"Computer picks {m} at random", f"Draw {m} names from a hat",
                              f"{m} random student numbers"])
    if method == "Systematic":
        return random.choice([f"Every {k}th name on the school list", f"Every {k}th on the attendance list"])
    if method == "Stratified":
        return random.choice([f"{g} at random from each grade", f"{g} names drawn from each homeroom"])
    if method == "Convenience":
        if sneaky:
            return random.choice([f"{m} random students in the {place}", f"{m} random students at the bus stop",
                                  f"{g} picked at random from {name}'s friends", f"Every {k}th student in the lunch line",
                                  f"{g} of {name}'s friends from each grade"])
        return random.choice([f"First {m} into the {place}", f"{name}'s {g} friends at lunch",
                              f"Students in the {place} at lunch"])
    if sneaky:
        return random.choice([f"{m} picked at random from volunteers", f"{m} random answers from an online poll",
                              f"{g} volunteers from each grade", f"Every {k}th person who answers the poll"])
    return random.choice(["A poll on Instagram", "A box anyone can use", "An online survey, if you want"])


def _kind(plan_text):
    """The plan's shape (numbers, names, places removed), so no two choices are the same plan."""
    t = re.sub(r"\d+", "#", plan_text)
    for w in NAMES + PLACES:
        t = t.replace(w, "_")
    return t


def p1_best_plan():                                  # M  which plan is fair / biased
    who, n, topic = school_ctx()
    v = info(f"{who} wants to know what the school's {n} students think about {topic}.")
    if random.random() < 0.5:
        good = random.choice(FAIRS)
        right = short_plan(good, n)
        bad = [short_plan(random.choice(["Convenience", "Voluntary"]), n, sneaky=True)]
        for _ in range(80):
            x = short_plan(random.choice(["Convenience", "Voluntary"]), n, sneaky=random.random() < 0.7)
            if _kind(x) not in {_kind(y) for y in bad + [right]}:
                bad.append(x)
            if len(bad) == 4:
                break
        return why(build(ask("Which plan gives a fair sample?"), right, bad, v),
                   f"'{right}' is {good.lower()}: every student has a chance. The others only reach people in "
                   f"one place or people who chose to answer. Picking 'at random' from those is still biased.")
    badm = random.choice(["Convenience", "Voluntary"])
    right = short_plan(badm, n, sneaky=random.random() < 0.7)
    fair = []
    for _ in range(80):
        x = short_plan(random.choice(FAIRS), n)
        if _kind(x) not in {_kind(y) for y in fair + [right]}:
            fair.append(x)
        if len(fair) == 4:
            break
    reach = "the people who happen to be in one place" if badm == "Convenience" else "people who chose to answer"
    return why(build(ask("Which plan gives a BIASED sample?"), right, fair, v),
               f"'{right}' is {badm.lower()}: it only reaches {reach}, even if it says 'random'. "
               f"The other plans give every student a chance.")


# Each method fits one kind of situation; the deciding fact is stated plainly.
def _fit_cases():
    who = random.choice(NAMES)
    n, k = random.choice([120, 150, 200, 240, 300]), random.choice([10, 12, 15, 20])
    return {
        "Simple random": [
            f"All {n} permission slips are mixed together in one big box. {who} wants to check {k} of them, "
            f"and every slip must have the same chance of being checked.",
            f"Every student's name is on a card, and all {n} cards are shuffled in a bin. The council needs "
            f"{k} students for a fair survey. No group has to be included on purpose.",
            f"A jar holds {n} mixed-up raffle tickets. {who} wants to check {k} of them, each with the same "
            f"chance.",
        ],
        "Systematic": [
            "Fans walk through the stadium gate one at a time. There is no list of who will come, but the "
            "survey must be fair.",
            "Phones come off a factory line one after another all day. The factory wants to test some of "
            "them fairly through the whole day.",
            "Cars pass a checkpoint one at a time. The city wants to survey drivers fairly, and there is no "
            "list of drivers.",
        ],
        "Stratified": [
            "The school has Grades 8 to 12, and the grades are very different sizes. Each grade might feel "
            "differently, and every grade must be heard.",
            "A town has 4 neighbourhoods that may want different things. The survey must include people "
            "from each neighbourhood.",
            "A swim club has beginner, middle and advanced swimmers. The coach must hear from every level.",
        ],
        "Convenience": [
            f"{who} has 5 minutes before class and only wants a rough idea, just for fun, of which snack "
            f"people like. There is no list, and nothing will be decided from it.",
            f"{who} wants to quickly check that a survey question is easy to read before the real survey. "
            f"There are 5 minutes and no list.",
            "A reporter needs 3 quick quotes about the new gym for a story due in 10 minutes. She is not "
            "trying to find out what most students think.",
        ],
        "Voluntary": [
            "The city wants ideas for a new park from anyone who has one. It is collecting ideas, not "
            "finding out what most people think.",
            "The school sets up a box where anyone can suggest a spirit week theme. They want as many "
            "ideas as possible.",
            "A restaurant wants to hear from any customer who has a complaint or a compliment to share.",
        ],
    }


FIT_WHY = {
    "Simple random": "Everything is mixed together (no order, no groups) and each one needs the same chance: "
                     "draw at random. That is simple random.",
    "Systematic": "They come one at A time and there is no list to draw from: pick every 10th one (or every "
                  "kth). That is systematic, and still fair.",
    "Stratified": "every group must be heard: pick at random from each group. That is stratified.",
    "Convenience": "Only a rough idea, no list, little time, and nothing big is decided: asking whoever is "
                   "nearby is OK here. That is convenience. (For a real decision it would be biased.)",
    "Voluntary": "They want ideas from anyone who cares, not what most people think: let people choose to "
                 "answer. That is voluntary. (To measure what most people think, it would be biased.)",
}


def p1_best_fit():                                   # M  which method fits the situation
    method = random.choice(METHODS)
    text = random.choice(_fit_cases()[method])
    return why(build_fixed(ask("Which sampling method fits this situation best?"), method, METHODS, info(text)),
               FIT_WHY[method])


GROUPS = [
    # (population, subject, what they want, people asked, wrong group, wrong group)
    ("All Grade 9 students at the school", "Grade 9 students at the school", "want a later start", "Grade 9s",
     "All students at the school", "All Grade 9 students in BC"),
    ("All students in the school band", "students in the school band", "want a new uniform", "band members",
     "All students at the school", "All musicians in the city"),
    ("All people who live in the town", "people who live in the town", "want a skate park", "people at the mall",
     "All people in BC", "All teens in the town"),
    ("All players in the hockey league", "players in the hockey league", "want later games", "players",
     "All hockey players in Canada", "All players on one team"),
    ("All the store's customers", "the store's customers", "like the new hours", "customers",
     "Everyone in the city", "Customers who shop on Mondays"),
    ("All students who ride the school bus", "students who ride the school bus", "want a later bus", "bus riders",
     "All students at the school", "Students on one bus route"),
    ("All the library's members", "the library's members", "want longer hours", "members",
     "Everyone in the city", "Members who come on Saturdays"),
    # groups that are wrong above are right here, so no answer is always right
    ("All students at the school", "students at the school", "want a longer lunch", "students",
     "All students in BC", "All Grade 9 students at the school"),
    ("Everyone in the city", "people in the city", "want a new library", "people downtown",
     "All people in BC", "All the library's members"),
    ("All people in BC", "people in BC", "want more bike lanes", "people in Victoria",
     "All people in Canada", "All people who live in the town"),
]


def p1_population():                                 # M  population or sample
    pop, subject, wants, asked, bigger, smaller = random.choice(GROUPS)
    who = random.choice(NAMES)
    m = random.choice([20, 25, 30, 40, 50, 60, 80])
    yes = random.randint(m // 4, m - 3)
    sample = f"The {m} {asked} {who} asked"
    only_yes = f"Only {subject} who {wants}"                 # mistake: only the "yes" side
    said_yes = f"The {yes} {asked} who said yes"              # mistake: only the "yes" side
    v = info(f"{who} wants to know if {subject} {wants}. {who} asks {m} {asked}. {yes} say yes.")
    w = (f"Population = the whole group the question is about ({pop.lower()}), not just the ones who agree. "
         f"Sample = everyone who was actually asked ({m} {asked}), not just the ones who said yes.")
    said_yes = random.choice([said_yes, f"The {yes} {asked} {who} asked who said yes"])
    extra = [who, f"{who} and the {m} {asked}", f"The {m - yes} {asked} {who} asked who said no",
             f"All {subject} {who} did not ask"]
    if random.random() < 0.5:
        return why(build(ask("Who is the population?"), pop, [only_yes, sample, bigger, smaller, said_yes], v,
                         extra=extra), w)
    return why(build(ask("Who is the sample?"), sample, [said_yes, pop, only_yes, bigger, smaller], v,
                     extra=extra), w)


CS_CHOICES = ["Census: few, and all count", "Census: always better",
              "Sample: too many to ask", "Sample: testing ruins them",
              "Sample: always fairer"]


def p1_census():                                     # M  census or sample, and why
    # same 5 choices every time; "testing ruins it" cases are small groups, so size alone doesn't decide
    kind = random.choice(["small", "big", "destroy"])
    n = random.randint(14, 32)
    if kind == "small":
        text = random.choice([
            f"A coach checks that the {n} players on the team have paid the team fee.",
            f"A teacher checks that her {n} students handed in a permission form.",
            f"A bus driver checks that the {n} students are back on the bus after a field trip.",
            f"The {n} members of the chess club vote on a new club logo.",
            f"A teacher wants to know if her {n} students finished the reading.",
        ])
    elif kind == "big":
        text = random.choice([
            "A TV station wants to know how people in BC feel about daylight saving time.",
            f"A phone company wants to know if its {random.randint(20, 90)},000 customers like its new app.",
            f"A city of {random.randint(40, 95)},000 people wants to know if people would use a new bike lane.",
            "The province wants to know how many hours of sleep Grade 9 students get.",
            "A cereal company wants to know if Canadians like its new flavour.",
        ])
    else:
        text = random.choice([
            f"A company made {n} new bike helmets and wants to know if they crack in a crash.",
            f"A bakery made {n} cookies for a contest and checks that they taste right.",
            f"A shop made {n} fireworks for a show and wants to check that they work.",
            f"A class built {n} model rockets and wants to know how high they fly before they break.",
            f"A juice company made {n} boxes of a new juice and checks the sugar by opening them.",
        ])
    right = {"small": CS_CHOICES[0], "big": CS_CHOICES[2], "destroy": CS_CHOICES[3]}[kind]
    w = {"small": "The group is small and every one of them matters, so check them all: a census.",
         "big": "There are far too many people to ask everyone, so ask a sample.",
         "destroy": "Testing uses up or ruins the item. A census would destroy all of them (even a small group), "
                    "so test a sample."}[kind]
    return why(build(ask("Census or sample? Why?"), right, [c for c in CS_CHOICES if c != right], info(text)), w)


def _sample_desc(method):
    """Short description of a sample.  Biased ones often sound random too."""
    who, n = random.choice(NAMES), random.choice([10, 15, 20, 25])
    if method == "Simple random":
        return f"a computer picked {random.choice([20, 25, 40, 50])} students at random"
    if method == "Systematic":
        return f"every {random.choice([10, 12, 15, 20, 24, 25])}th name on the school list"
    if method == "Stratified":
        return f"{random.choice([4, 5, 8, 10])} at random from each of the 5 grades"
    if method == "Convenience":
        return random.choice([f"{n} picked at random from {who}'s friends", f"{n} random students in the gym",
                              f"{n} random students at the bus stop", f"the first {n} students in the lunch line",
                              f"{who}'s {n} friends at lunch"])
    return random.choice([f"{n} random answers from an Instagram poll", f"{n} picked at random from volunteers",
                          f"{n} random slips from a box anyone could use", f"{n} students who chose to answer online"])


def p1_closest():                                       # M  which sample is closest / farthest
    """Census % and three samples' % (fair, convenience, voluntary in random order).  No calculating."""
    fair = random.choice(FAIRS)
    methods = [fair, "Convenience", "Voluntary"]
    random.shuffle(methods)
    pc = random.choice([20, 25, 30, 35, 40, 45, 50, 60])
    pcts = []
    for m in methods:
        if m == fair:
            p = pc + random.choice([-1, 1]) * random.randint(1, 6)
        else:
            far = [x for x in range(5, 96) if abs(x - pc) >= 25 and x not in pcts]
            p = random.choice(far)
        pcts.append(p)
    _, _, topic = school_ctx()
    letters = "ABC"
    lines = wrap(f"Census of all students: {pc}% want {topic}.", 66)
    descs = [_sample_desc(m) for m in methods]
    for L, d, p in zip(letters, descs, pcts):
        lines += [f"Sample {L}: {d}", f"{p}% said yes"]
    i = methods.index(fair)
    F_, others = letters[i], [letters[j] for j in range(3) if j != i]
    sneaky = any("random" in d for d, m in zip(descs, methods) if m != fair)
    reach = ", even if they say 'random'" if sneaky else ""
    if random.random() < 0.5:                     # closest = the fair one
        random.shuffle(others)
        right = f"Sample {F_}: it is fair"
        traps = [f"Sample {F_}: it is biased", f"Sample {others[0]}: it is fair",
                 f"Sample {others[0]}: it is biased",
                 f"Sample {others[1]}: it is {random.choice(['fair', 'biased'])}"]
        return why(build(ask("Which sample is closest to the census, and why?"), right, traps, {"notes": lines}),
                   f"Sample {F_} ({pcts[i]}%) is closest to {pc}%. It is {fair.lower()}: every student had a "
                   f"chance. Samples {others[0]} and {others[1]} only reached people nearby or people who chose "
                   f"to answer{reach}. They are biased and far off.")
    far = max((j for j in range(3) if j != i), key=lambda j: abs(pcts[j] - pc))
    other = next(j for j in range(3) if j not in (i, far))
    L, O = letters[far], letters[other]
    right = f"Sample {L}: it is biased"
    traps = [f"Sample {L}: it is fair", f"Sample {F_}: it is biased",
             f"Sample {F_}: it is fair", f"Sample {O}: it is {random.choice(['fair', 'biased'])}"]
    return why(build(ask("Which sample is FARTHEST from the census, and why?"), right, traps, {"notes": lines}),
               f"Sample {L} ({pcts[far]}%) is farthest from {pc}%. It only reached people nearby or people who "
               f"chose to answer{reach}: biased. Sample {F_} ({pcts[i]}%) is {fair.lower()}, fair and close.")


# ==========================================
# 2. BIAS IN COLLECTING DATA
# ==========================================
PROBLEMS = ["Leading or loaded words", "Timing", "Privacy", "Ethics", "Biased sample"]

WANT = ["a longer lunch break", "later start times", "more field trips", "a new gym", "a school garden",
        "more clubs", "a bigger library", "a student lounge"]
SPEND = ["field trips", "the school dance", "new computers", "the band", "sports uniforms", "the yearbook"]
NEW = ["cafeteria menu", "school logo", "library hours", "bell schedule", "gym floor", "school website"]
PAIRS = [("delicious homemade pizza", "frozen pizza"), ("fun, exciting field trips", "regular classes"),
         ("the bright, modern gym", "the old gym"), ("a relaxing study hall", "an extra math class")]
CLAIMS = ["homework should be banned", "lunch should be longer", "the school day is too long",
          "phones should be allowed in class"]


def loaded_question():
    k = random.randrange(6)
    if k == 0:
        return f"Don't you agree that our school needs {random.choice(WANT)}?"
    if k == 1:
        return f"Should the school stop wasting money on {random.choice(SPEND)}?"
    if k == 2:
        return f"How much do you love the new {random.choice(NEW)}?"
    if k == 3:
        a, b = random.choice(PAIRS)
        return f"Do you prefer {a} or {b}?"
    if k == 4:
        return f"Most students already agree that {random.choice(CLAIMS)}. Do you?"
    return f"Isn't it true that {random.choice(CLAIMS)}?"


def neutral_question():
    """A fairly worded question (gives every choice, no hint)."""
    return random.choice([
        f"Do you want {random.choice(WANT)}? (yes, no, not sure)",
        f"Should we spend more, less or the same on {random.choice(SPEND)}?",
        f"How do you feel about the new {random.choice(NEW)}: like it, don't like it, or not sure?",
        f"Would you like {random.choice(WANT)}? (yes, no, not sure)",
    ])


# Every case quotes the question asked, so quote marks don't point to "leading words".
def timing_case():
    return random.choice([
        'During a June heat wave, students are asked: "Should classrooms get air conditioning?"',
        'On a cold, rainy January day, students are asked: "Should outdoor PE move inside all year?"',
        'During the first big snowfall, a store asks shoppers: "How much hot chocolate do you buy in a year?"',
        'On the morning of a big exam, students are asked: "How stressed do you usually feel?"',
        'Right after their team wins the championship, fans are asked: "How do you usually feel about the team?"',
        'In the middle of a blizzard, people are asked: "How many snowplows should the city have?"',
        'Right after a free pizza day, students are asked: "Do you like the cafeteria\'s food?"',
        'The morning after a storm made every bus late, riders are asked: "Is the bus usually on time?"',
    ])


SECRETS = ["copied homework", "skipped a class", "cheated on a test", "lied to a teacher"]
PERSONAL = ["What was your last test mark?", "How much allowance do you get?", "How many push-ups can you do?",
            "How many hours do you game each night?"]


def privacy_case():
    s = random.choice(SECRETS)
    return random.choice([
        f'Students raise their hands to answer: "Have you ever {s}?"',
        f'A teacher asks each student, in front of the class: "{random.choice(PERSONAL)}"',
        f'Students move to one side of the room to answer: "Have you ever {s}?"',
        f'Students must write their name on the survey: "Have you ever {s}?"',
    ])


def ethics_case():
    return random.choice([
        "A company tests the water on a First Nation's land and posts the results online without asking the community.",
        "A researcher writes about a First Nation's traditional fishing without asking the community's Elders or leaders.",
        'A club asks students "What is your favourite snack?" and sells the answers to a snack company without asking.',
        f'{random.choice(NAMES)} records students\' answers to "How do you feel about school?" for a study without telling them.',
        'Students answer "Which clubs do you like?" for a club fair. The answers are then used for a different project.',
    ])


def sample_case():
    name, m = random.choice(NAMES), random.choice([20, 25, 30, 40])
    what, where = random.choice([("the new library hours", "in the library"), ("the gym schedule", "in the gym"),
                                 ("the cafeteria food", "in the cafeteria line"), ("the school buses", "at the bus loop")])
    return random.choice([
        f'To learn what all students think, surveys are handed out only {where}: "Do you like {what}?"',
        f'To learn what all students think, {m} random students {where} are asked: "Do you like {what}?"',
        'A TV show asks viewers to text in their vote: "Are video games good for teens?"',
        f'To find the school\'s favourite sport, {name} asks students at basketball practice: "What is your favourite sport?"',
        f'To learn how all students get to school, {name} asks only students at the bus stop: "How do you get to school?"',
        'A radio station asks listeners to phone in: "Should the city build a new arena?"',
    ])


def loaded_case():
    name, m = random.choice(NAMES), random.choice([40, 50, 60, 80])
    q = loaded_question()
    return random.choice([f'{name}\'s survey asks: "{q}"', f'A random sample of {m} students is asked: "{q}"',
                          f'Every 10th student on the school list is asked: "{q}"'])


CASES = {"Leading or loaded words": loaded_case, "Timing": timing_case, "Privacy": privacy_case,
         "Ethics": ethics_case, "Biased sample": sample_case}

PROBLEM_WHY = {
    "Leading or loaded words": "Leading or loaded words: the question pushes people toward one answer "
                               "(\"Don't you agree...\", \"wasting\", \"love\", \"delicious\"). Even a random "
                               "sample can't fix that.",
    "Timing": "Timing: it is asked at an unusual time (heat wave, storm, big win), so the answers are not "
              "what people usually think. The question itself is fair.",
    "Privacy": "Privacy: people must answer a personal question where others can see. Many will not tell "
               "the truth.",
    "Ethics": "Ethics: the data is collected or used without permission or respect (no asking first, "
              "selling answers, secret studies).",
    "Biased sample": "Biased sample: only one kind of person is asked (people in one place, or who choose "
                     "to call in), not the whole group, even if they are picked 'at random' there.",
}


def p2_name_problem():                               # M  name the problem
    right = random.choice(PROBLEMS)
    return why(build_fixed(ask("What is the main problem with this survey?"), right, PROBLEMS,
                           info(CASES[right]())), PROBLEM_WHY[right])


def _fair_forms():
    """(fair questions, loaded questions) about one topic, in several wordings."""
    if random.random() < 0.5:
        x = random.choice(WANT)
        fair = [f"Do you want {x}?", f"Do you want {x}? (yes, no, not sure)", f"How do you feel about {x}?",
                f"Should the school have {x}? (yes, no, not sure)"]
        loaded = [f"Don't you agree we need {x}?", f"Wouldn't {x} be great?", f"Most students want {x}. Do you?",
                  f"Isn't it unfair that we don't have {x}?", f"Don't you agree we need {x}? (yes, no, not sure)",
                  f"Do you want {x}? (yes, definitely / yes, a little)", f"Why do we need {x}?"]
    else:
        y = random.choice(SPEND)
        fair = [f"Should we spend more, less or the same on {y}?", f"How much should we spend on {y}?",
                f"Should spending on {y} go up, go down or stay the same?",
                f"How do you feel about what we spend on {y}?"]
        loaded = [f"Should we stop wasting money on {y}?", f"Isn't too much spent on {y}?",
                  f"Why is so much spent on {y}?", f"Most people say spending on {y} is a waste. Agree?",
                  f"Should we cut the costly {y}?", f"Should we spend less on {y}? (yes / a lot less)",
                  f"Isn't spending on {y} a waste? (yes, no, not sure)"]
    return fair, loaded


def p2_fix_question():                               # M  fair / not fair wording
    fair, loaded = _fair_forms()
    if random.random() < 0.5:
        right = random.choice(fair)
        return why(build(ask("Which survey question is fair?"), right,
                         random.sample(loaded, 4)),
                   f"'{right}' uses neutral words and leaves every answer open. The others hint at an answer "
                   f"('waste', 'Don't you agree', 'Most students...') or only offer one side of the choices.")
    right = random.choice(loaded)
    return why(build(ask("Which survey question is NOT fair?"), right, random.sample(fair, 4)),
               f"'{right}' pushes one answer: it uses words that hint at the 'right' answer, or its choices only "
               f"allow one side. Adding '(yes, no, not sure)' does not fix loaded words.")


FIXES = {   # problem: (right fixes, plausible fixes that don't solve it)
    "Timing": (["Ask on ordinary days through the year", "Ask at a normal time, not a special one",
                "Spread the survey over regular days"],
               ["Ask a lot more people on that same day", "Ask the same people again the very next day",
                "Ask a random sample on that same day"]),
    "Privacy": (["Use anonymous answers on paper slips", "Let students answer in secret, with no names",
                 "Collect answers in a closed box, with no names"],
                ["Ask a random sample of students out loud", "Have every student sign their answer",
                 "Ask in front of a smaller group of students"]),
    "Biased sample": (["Choose people at random from the whole group", "Pick every 10th name on the full list",
                       "Pick a few at random from each grade"],
                      ["Ask a lot more people in that same place", "Let anyone who wants to answer online",
                       "Pick at random from the people who are there"]),
    "Leading or loaded words": (["Reword it so it does not push an answer", "Use neutral words and give all choices",
                                 "Remove the words that hint at an answer"],
                                ["Ask the same question to a bigger random sample", "Ask the same question on a different day",
                                 "Ask the same question again next week"]),
    "Ethics": (["Ask permission first and respect the data", "Get permission and use answers only as agreed"],
               ["Collect the data faster, before anyone objects", "Ask a bigger random sample of people",
                "Post all of the results online sooner"]),
}


def p2_fix_plan():                                   # M  best fix
    prob = random.choice(list(FIXES))
    right = random.choice(FIXES[prob][0])
    others = [random.choice(FIXES[p][0]) for p in FIXES if p != prob]
    traps = random.sample(FIXES[prob][1], 2) + random.sample(others, 2)
    return why(build(ask("What is the best way to fix this survey?"), right, traps, info(CASES[prob]())),
               f"The problem is {prob.lower()}. Fix that problem: {right.lower()}. "
               f"Asking more people, or another fix for a different problem, does not fix it.")


def p2_which_fair():                                 # H  plan with no problem / with a problem
    m, k, g = random.choice([30, 40, 50, 60]), random.choice([10, 20, 25]), random.choice([5, 8, 10])
    topic = random.choice(["copying homework", "skipping class", "cheating on tests", "vaping at school",
                           "lying to teachers"])
    good = {"who": [f"{m} random students", f"every {k}th name on the list", f"{g} at random from each grade"],
            "words": ["fair words", "neutral question", "no leading words"],
            "priv": ["anonymous", "no names on it", "answers kept secret"]}
    bad = {"who": [f"{m} of my friends", f"{m} volunteers", f"{m} random students in the gym",
                   f"every {k}th in the lunch line"],
           "words": ["leading words", "loaded question", "'Don't you agree...?'"],
           "priv": ["hands up", "names written on it", "answered out loud"]}

    def plan_(bad_parts):
        return ", ".join(random.choice(bad[p] if p in bad_parts else good[p]) for p in ("who", "words", "priv"))
    combos = [{"who"}, {"words"}, {"priv"}, {"who", "words"}, {"who", "priv"}, {"words", "priv"}]
    if random.random() < 0.5:
        right = plan_(set())
        traps = []
        for parts in random.sample(combos, 6):
            x = plan_(parts)
            if x not in traps and x != right:
                traps.append(x)
        q = "Which survey plan has no problem?"
        w = ("A good plan needs all three: a fair sample (random, every kth on the full list, or from each grade; "
             "not friends, volunteers or one place), fair words, and anonymous answers (this topic is personal).")
    else:
        parts = random.choice(combos)
        right = plan_(parts)
        traps = []
        for _ in range(30):
            x = plan_(set())
            if x not in traps and x != right:
                traps.append(x)
            if len(traps) == 4:
                break
        q = "Which survey plan has a problem?"
        w = (f"'{right}' has a problem: " + ", ".join({"who": "the sample only reaches some students",
                                                      "words": "the words push an answer",
                                                      "priv": "answers are not anonymous"}[p] for p in sorted(parts)) +
             ". The others have a fair sample, fair words and anonymous answers.")
    return why(build(ask(q), right, traps, info(f"A survey asks the students of a school about {topic}.")), w)


RESULT_CHOICES = ["Yes: fair sample and words", "No: words push an answer",
                  "No: it's a biased sample", "No: sample too small", "No: needs a census"]


def p2_results_fair():                          # M  are the results fair (sample and words)
    m = random.choice([80, 100, 120, 150])
    who = random.choice(NAMES)
    kind = random.choice(["fair", "words", "sample"])
    sample = (random.choice([f"{m} students picked at random from the whole school",
                             f"every 5th name on the school list ({m} students)"])
              if kind != "sample" else
              random.choice([f"{m} random students in the cafeteria", f"{m} students who answered a poll",
                             f"{m} random students at the bus stop"]))
    q = loaded_question() if kind == "words" else neutral_question()
    right = {"fair": RESULT_CHOICES[0], "words": RESULT_CHOICES[1], "sample": RESULT_CHOICES[2]}[kind]
    w = {"fair": "The sample gives every student a chance and the question is worded fairly, so the results are fair. "
                 f"{m} students is plenty for a sample.",
         "words": "A fair sample fixes who is asked, not how. The question uses leading words, so the results are biased.",
         "sample": "The question is fair, but only students in one place (or who chose to answer) could be picked, "
                   "even if 'random'. Biased."}[kind]
    return why(build(ask("Are the results fair?"), right, [c for c in RESULT_CHOICES if c != right],
                     info(f"{who} asks {sample}: \"{q}\"")), w)


# ==========================================
# 3. MISLEADING GRAPHS
# ==========================================
BAR_CTX = [("Mascot Vote", "Votes", ["Eagles", "Ravens"]), ("Battery Life", "Hours", ["Brand A", "Brand B"]),
           ("Test Average", "Mark (%)", ["Class A", "Class B"]), ("Cans Collected", "Cans", ["Grade 9", "Grade 10"]),
           ("Pizza Sales", "Pizzas", ["Monday", "Tuesday"]), ("Club Members", "Members", ["Chess", "Drama"]),
           ("Phone Ratings", "Score", ["Phone X", "Phone Y"])]


def poss(name):
    """Eagles -> Eagles',  Brand B -> Brand B's."""
    return name + ("'" if name.endswith("s") else "'s")


def cut_axis_bars():
    """Two bars on an axis that starts above 0. Returns the visual and the numbers."""
    for _ in range(300):
        title, ylabel, cats = random.choice(BAR_CTX)
        step = random.choice([1, 2, 5, 10])
        a = random.choice([1, 2])
        b = random.choice([x for x in (2, 3, 4, 5, 6) if x > a])
        ymin = step * random.randint(8, 40)
        v1, v2 = ymin + a * step, ymin + b * step
        pct_ok = "%" not in ylabel or ymin + (b + 1) * step <= 100      # a mark can't go past 100%
        if v2 / v1 < 1.6 and nice(F(b, a), 2) and pct_ok:
            break
    order = [0, 1] if random.random() < 0.5 else [1, 0]
    vals = [v1, v2] if order == [0, 1] else [v2, v1]
    small_cat, big_cat = (cats[0], cats[1]) if order == [0, 1] else (cats[1], cats[0])
    top = ymin + (b + 1) * step
    vis = {"bars": {"title": title, "ylabel": ylabel, "cats": cats, "vals": vals, "ymin": ymin, "ymax": top,
                    "ystep": step}}
    return vis, dict(v1=v1, v2=v2, a=a, b=b, ymin=ymin, step=step, small=small_cat, big=big_cat, unit=ylabel)


def p3_looks_really():                               # M  looks vs really (bar graph)
    target = random.choice([F(3, 2), F(2), F(5, 2), F(3), F(4), F(5)])     # even spread of answers
    for _ in range(300):
        vis, d = cut_axis_bars()
        if F(d["b"], d["a"]) == target:
            break
    looks, really = F(d["b"], d["a"]), r2(F(d["v2"], d["v1"]))
    fmt = as_units("times")
    if random.random() < 0.5:
        traps = [really, d["v2"] - d["v1"], d["b"] - d["a"], F(d["v2"] - d["ymin"], d["v1"]), looks + 1]
        return why(build_num(ask(f"The {d['big']} bar looks how many times as tall as the {d['small']} bar?"),
                             looks, traps, fmt=fmt, ok=LOOKS_OK, visual=vis,
                             extra=[x for x in LOOKS_POOL if x != looks]),
                   f"The axis starts at {d['ymin']}, so measure the bars from there: {d['big']} {d['v2']} - "
                   f"{d['ymin']} = {d['v2'] - d['ymin']},  {d['small']} {d['v1']} - {d['ymin']} = "
                   f"{d['v1'] - d['ymin']}.  {d['v2'] - d['ymin']} / {d['v1'] - d['ymin']} = {fnum(looks)} times.")
    st = d["step"]
    misread = [r2(F(d["v2"] + st, d["v1"])), r2(F(d["v2"], d["v1"] + st)), r2(F(d["v2"] - st, d["v1"])),
               r2(F(d["v2"] + st, d["v1"] - st))]                # misread by one grid line
    traps = [looks] + [x for x in misread if x != really and x > 1][:3] + [r2(F(d["v1"], d["v2"]))]
    return why(build_num(ask(f"How many times as big is {poss(d['big'])} number really? (2 decimals)"), really,
                         traps, fmt=fmt, ok=lambda v: v > 0 and nice(v, 100), visual=vis,
                         extra=[really + F(1, 10), really - F(5, 100), really + F(5, 100), looks + 1]),
               f"Use the real numbers, not the bar heights: {d['big']} {d['v2']},  {d['small']} {d['v1']}.  "
               f"{d['v2']} / {d['v1']} = {fnum(really)} times.")


# "Looks" answers come from this pool; wrong answers do too.
LOOKS_POOL = [F(3, 2), F(2), F(5, 2), F(3), F(7, 2), F(4), F(5), F(6)]
LOOKS_OK = lambda v: (1 < v <= 6) and nice(v, 100)          # same range as the right answers

WHAT_CHOICES = ["Axis doesn't start at 0", "Picture grows two ways", "Uneven scale steps",
                "Only part of the data", "Nothing: it's fair"]
WHAT_WHY = [
    "Look at the bottom of the vertical axis: it does not start at 0, so a small difference looks huge.",
    "The picture got bigger in width and height, so it looks far bigger than the real change.",
    "Read the axis numbers: the steps jump by different amounts (like 10, 20, 50, 100), so the line's "
    "shape is wrong.",
    "The poster shows only the months that went up. The full list of months shows it went back down after.",
    "The axis starts at 0, the steps are even and all the data is shown. Nothing is misleading.",
]
MONTHS = ["Sep", "Oct", "Nov", "Dec", "Jan", "Feb", "Mar", "Apr"]


def _fair_bars():
    title, ylabel, cats = random.choice(BAR_CTX)
    step = 10 if "%" in ylabel else random.choice([5, 10, 20])        # marks stay at 100% or less
    vals = [step * random.randint(2, 9) for _ in cats]
    while vals[0] == vals[1]:
        vals[1] = step * random.randint(2, 9)
    return {"bars": {"title": title, "ylabel": ylabel, "cats": cats, "vals": vals, "ymin": 0,
                     "ymax": step * 10, "ystep": step * 2}}


def _pics_visual():
    k = random.choice([2, 3])
    thing, unit = random.choice([("Juice Box Sales", "boxes"), ("Books Read", "books"), ("Trees Planted", "trees"),
                                 ("Cookie Sales", "cookies")])
    base = random.choice([50, 100, 150, 200, 250])
    word = {2: "DOUBLED", 3: "TRIPLED"}[k]
    return {"pics": {"title": f"{thing} {word}!",
                     "items": [(f"Last year\n{base} {unit}", 1), (f"This year\n{base * k} {unit}", k)]}}, k


def _uneven_visual():
    title = random.choice(["Bike Thefts", "Phone Sales", "Website Visits", "Library Fines"])
    labels = random.choice([["0", "10", "20", "50", "100"], ["0", "5", "10", "50", "100"], ["0", "20", "40", "100", "200"]])
    vals = [int(x) for x in labels[1:]]
    xs = random.choice([["2023", "2024", "2025", "2026"], ["Spring", "Summer", "Fall", "Winter"]])
    return {"lgraph": {"title": title, "ylabel": "", "xs": xs, "ys": vals, "ypos": [1, 2, 3, 4], "ymin": 0,
                       "ymax": 4.3, "ticks": [0, 1, 2, 3, 4], "ticklabels": labels}}


def _window_visual():
    start = random.choice([200, 250, 300, 350])
    up = random.choice([20, 30, 40, 50])
    ys = [start, start + up, start + 2 * up]
    down = [start + up - random.choice([10, 20]), start - random.choice([10, 20, 30]),
            start - random.choice([40, 50, 60])]
    full = ys + down
    title = random.choice(["Library Visits", "Cafeteria Sales", "Gym Sign-ups", "Website Visits"])
    allv = ", ".join(f"{m} {v}" for m, v in zip(MONTHS, full))
    top = (max(ys) // 100 + 1) * 100
    return {"notes": wrap(f"A poster says: {title.upper()} ARE SOARING! Every month so far: {allv}"),
            "lgraph": {"title": f"{title} (poster)", "ylabel": "", "xs": MONTHS[:3], "ys": ys, "ymin": 0,
                       "ymax": top, "ticks": list(range(0, top + 1, 100))}}


def _fair_line():
    start, up = random.choice([100, 150, 200, 250]), random.choice([10, 20, 30])
    ys = [start + up * i + random.choice([-5, 0, 5]) for i in range(6)]
    title = random.choice(["Library Visits", "Cafeteria Sales", "Gym Sign-ups", "Website Visits"])
    allv = ", ".join(f"{m} {v}" for m, v in zip(MONTHS, ys))
    top = (max(ys) // 100 + 1) * 100
    return {"notes": wrap(f"A poster says: {title.upper()} ARE GOING UP! Every month so far: {allv}"),
            "lgraph": {"title": f"{title} (poster)", "ylabel": "", "xs": MONTHS[:6], "ys": ys, "ymin": 0,
                       "ymax": top, "ticks": list(range(0, top + 1, 50 if top <= 300 else 100))}}


def p3_whats_wrong():                                # M  what makes the graph misleading
    kind = random.choice([0, 1, 2, 3, 4])
    if kind == 0:
        vis = cut_axis_bars()[0]
    elif kind == 1:
        vis = _pics_visual()[0]
    elif kind == 2:
        vis = _uneven_visual()
    elif kind == 3:
        vis = _window_visual()
    else:
        vis = _fair_bars() if random.random() < 0.5 else _fair_line()
    return why(build_fixed(ask("What makes this graph misleading?"), WHAT_CHOICES[kind], WHAT_CHOICES, vis),
               WHAT_WHY[kind])


def p3_looks_text():                                 # M  looks (axis start given in words)
    target = random.choice([F(3, 2), F(2), F(5, 2), F(3), F(7, 2), F(4), F(5), F(6)])  # even spread
    step = random.choice([1, 2, 5, 10])
    a = random.choice([2, 4]) if target.denominator == 2 else random.choice([1, 2])
    b = int(target * a)
    ymin = step * random.randint(5, 30)
    v1, v2 = ymin + a * step, ymin + b * step
    looks = F(b, a)
    text = (f"A bar graph's vertical axis starts at {ymin}. Bar A shows {v1} and bar B shows {v2}.\n"
            f"Bar B looks how many times as tall as bar A?")
    traps = [r2(F(v2, v1)), b - a, F(b, a) + 1, F(b + 1, a), F(b, a + 1) if nice(F(b, a + 1), 100) else None]
    return why(build_num(ask(text), looks, traps, fmt=as_units("times"), ok=LOOKS_OK,
                         extra=[x for x in LOOKS_POOL if x != looks]),
               f"The bars start at {ymin}, so their heights are B: {v2} - {ymin} = {v2 - ymin} and "
               f"A: {v1} - {ymin} = {v1 - ymin}.  {v2 - ymin} / {v1 - ymin} = {fnum(looks)} times.")


PIC_POOL = [2, 3, 4, 9, 16]                 # all right answers; wrong ones come from here too


def p3_picture():                                    # M  pictures that grow two ways
    k = random.choice([2, 3, 4])
    word = {2: "doubled", 3: "tripled", 4: "went up 4 times"}[k]
    thing = random.choice(["Juice box sales", "Book sales", "Ticket sales", "The number of trees planted"])
    kind = random.choice(["looks", "fair bar", "really"])
    pool = [x for x in PIC_POOL]
    if kind == "looks":
        text = (f"{thing} {word}. A poster shows this with a picture made {k} times as wide and {k} times as tall.\n"
                f"How many times as big does the new picture look?")
        return why(build_num(ask(text), k * k, [k, 2 * k], fmt=as_units("times"), ok=pos_int, extra=pool),
                   f"The picture grows two ways: {k} times as wide x {k} times as tall = {k * k} times as big. "
                   f"That is why it misleads.")
    if kind == "fair bar":
        text = f"{thing} {word}. To show this fairly with bars, how many times as tall should the new bar be?"
        return why(build_num(ask(text), k, [k * k, 2 * k, k + 1], fmt=as_units("times"), ok=pos_int, extra=pool),
                   f"A fair bar grows only one way (taller, same width). It went up {k} times, so the bar is "
                   f"{k} times as tall.")
    text = (f"A poster made a picture bigger by the same amount in width and height. Now it looks {k * k} times "
            f"as big. How many times did {thing.lower()} really go up?")
    return why(build_num(ask(text), k, [k * k, F(k * k, 2), 2 * k], fmt=as_units("times"), ok=pos_int, extra=pool),
               f"The picture grew two ways: wide x tall = {k} x {k} = {k * k}. So the real change is only {k} times. "
               f"(Which number times itself makes {k * k}?)")


# ==========================================
# 4. PERCENTS IN DATA
# ==========================================
VERBS = [("walk to school", "walk"), ("eat breakfast every day", "eat breakfast"),
         ("play on a sports team", "play a sport"), ("have a part-time job", "have a job"),
         ("read for fun", "read for fun"), ("want a later start", "want a later start")]


def p4_percent_of():                                 # E  find the percent
    for _ in range(300):
        n = random.choice([20, 25, 40, 50, 80, 200, 250, 400, 500])
        k = random.randint(2, n - 2)
        p = F(100 * k, n)
        if nice(p, 10) and p != 50:
            break
    verb = random.choice(VERBS)[0]
    traps = [F(100 * n, k) if nice(F(100 * n, k), 10) else None, k, 100 - p, r2(F(k, n)), p + 10, p - 10]
    return why(build_num(ask(f"{k} of {n} students surveyed {verb}. What percent is that?"), p, traps, fmt=as_pct,
                         ok=lambda v: 0 < v < 100 and nice(v, 100), extra=[p + 5, p - 5, p * 2, p + 2, p - 2]),
               f"Percent = part / whole x 100 = {k} / {n} x 100 = {fnum(p)}%.")


def p4_part():                                       # E  find the part
    for _ in range(300):
        p = random.choice([5, 10, 12, 15, 20, 24, 25, 30, 35, 40, 45, 60, 65, 75, 80])
        N = random.choice([60, 80, 120, 150, 200, 240, 250, 300, 320, 400, 450, 500, 600, 800])
        if (N * p) % 100 == 0:
            break
    ans = F(N * p, 100)
    verb = random.choice(VERBS)[0]
    # real slips, whole numbers below the total (like the answer)
    traps = [N - ans, F(N * p, 1000), F(N, p) if nice(F(N, p)) else None, p, 2 * ans, ans // 2 if ans % 2 == 0 else None]
    return why(build_num(ask(f"{p}% of the {N} students at a school {verb}. How many students is that?"), ans,
                         traps, fmt=as_units("students"), ok=lambda v: pos_int(v) and 2 <= v < N,
                         extra=[ans + 10, ans - 10, ans + 20, ans - 20, ans + 5]),
               f"Part = whole x percent = {N} x {fnum(F(p, 100))} = {fnum(ans)} students.  "
               f"({p}% = {fnum(F(p, 100))})")


def p4_whole():                                      # M  find the whole
    for _ in range(300):
        p = random.choice([10, 15, 20, 25, 30, 35, 40, 45, 60, 75, 80])
        N = 10 * random.randint(4, 50)                       # 40 ... 500
        if (N * p) % 100 == 0:
            break
    k = N * p // 100
    # real slips, round numbers above the part (like the answer)
    traps = [F(k * 100, 100 - p) if nice(F(k * 100, 100 - p)) else None, k + p, 2 * N, k * 10,
             N // 2 if N % 2 == 0 and N // 2 > k else None, F(k * p, 10) if nice(F(k * p, 10)) else None]
    return why(build_num(ask(f"{k} students said yes. That is {p}% of everyone surveyed. How many were surveyed?"),
                         N, traps, fmt=as_units("people"), ok=lambda v: pos_int(v) and k < v <= 1000 and v % 10 == 0,
                         extra=[N + 20, N - 20, N + 40, N - 40, N + 10, N + 80, N - 10, N + 50]),
               f"Whole = part / percent = {k} / {fnum(F(p, 100))} = {N}.  Check: {N} x {fnum(F(p, 100))} = {k}.")


COMPARE_CTX = [("School A", "School B", "students", "are in band"),
               ("Grade 9", "Grade 10", "students", "chose pizza"),
               ("Orcas", "Ravens", "free throws", "went in"),
               ("Block A", "Block B", "students", "handed in the project early")]


def p4_compare():                                    # M  compare groups by percent
    a_name, b_name, noun, rest = random.choice(COMPARE_CTX)
    for _ in range(800):
        nA = random.choice([20, 40, 50, 80, 100, 200, 300])
        nB = random.choice([25, 50, 75, 150, 250, 400, 500])
        if random.random() < 0.5:
            nA, nB = nB, nA
        kA, kB = random.randint(2, nA - 1), random.randint(2, nB - 1)
        pA, pB = F(100 * kA, nA), F(100 * kB, nB)
        if (nice(pA, 10) and nice(pB, 10) and abs(pA - pB) >= 3 and kA != kB
                and (kA > kB) != (pA > pB)            # bigger count, smaller percent
                and max(kA, kB) <= 3 * min(kA, kB)):
            break
    win, lose = (a_name, b_name) if pA > pB else (b_name, a_name)
    pw, pl = max(pA, pB), min(pA, pB)
    km, kl = max(kA, kB), min(kA, kB)
    # each name and each reason appears at least twice, so neither gives it away
    r0 = f"{pct(pw)} is more than {pct(pl)}"                       # true
    r1 = f"{km} is more than {kl}" + (f" {noun}" if random.random() < 0.5 else "")   # counts: classic mistake
    r2 = f"{pct(pl)} is more than {pct(pw)}"                       # false
    right = f"{win}: {r0}"
    traps = [f"{lose}: {r0}", f"{win}: {r1}", f"{lose}: {r1}", f"{random.choice([win, lose])}: {r2}"]
    text = f"{a_name}: {kA} of {nA} {noun} {rest}. {b_name}: {kB} of {nB} {noun} {rest}."
    return why(build(ask("Which has the greater percent?"), right, traps, info(text)),
               f"The groups are different sizes, so compare percents, not counts.  {a_name}: {kA} / {nA} x 100 = "
               f"{pct(pA)}.  {b_name}: {kB} / {nB} x 100 = {pct(pB)}.")


def p4_two_way():                                    # M  two-way tables
    verb, short = random.choice(VERBS)
    rows = random.choice([("Grade 8", "Grade 9"), ("Grade 9", "Grade 10"), ("Block A", "Block B")])
    for _ in range(500):
        t1, t2 = random.choice([20, 25, 40, 50, 80]), random.choice([20, 25, 40, 50, 80])
        a, c = random.randint(2, t1 - 2), random.randint(2, t2 - 2)
        if nice(F(100 * a, t1), 10) and nice(F(100 * c, t2), 10) and a != c:
            break
    b, d = t1 - a, t2 - c
    N = t1 + t2
    yes, no = a + c, b + d
    table = {"rows": [("", ["Yes", "No", "Total"]), (rows[0], [a, b, t1]), (rows[1], [c, d, t2]),
                      ("Total", [yes, no, N])]}
    vis = {"notes": [f"\"Do you {verb}?\""], "table": table}
    kind = random.choice(["row", "all"])
    if kind == "row":
        r, k, t, other = random.choice([(rows[0], a, t1, c), (rows[1], c, t2, a)])
        ans = F(100 * k, t)
        traps = [r0(F(100 * k, N)), r0(F(100 * k, yes)), F(100 * (t - k), t), k, r0(F(100 * t, N))]
        text = f"What percent of the {r} students said yes?"
        w = (f"Use only the {r} row: {k} said yes out of a row total of {t}.  {k} / {t} x 100 = {fnum(ans)}%.")
    elif kind == "all":
        ans = r0(F(100 * yes, N))
        traps = [yes, r0(F(100 * no, N)), r0(F(100 * a, t1)), r0(F(100 * c, t2)), r0(F(100 * yes, t1))]
        text = "What percent of all students said yes? (nearest whole %)"
        exact = F(100 * yes, N) == ans
        w = (f"Use the Total row: {yes} said yes out of {N} students.  {yes} / {N} x 100 = "
             + (f"{fnum(ans)}%." if exact else f"{fnum(r2(F(100 * yes, N)))} -> about {fnum(ans)}%."))
    return why(build_num(ask(text), ans, traps, fmt=as_pct, ok=lambda v: v > 0 and nice(v, 10), visual=vis,
                         extra=[ans + 5, ans - 5, ans + 10]), w)


# ==========================================
# 5. QUESTION MIX
# ==========================================
GENERATORS = {     # topic: [(generator, question type shown in the Sheet), ...]
    1: [(p1_name_method, "Name the sampling method"),
        (p1_fair, "Fair or biased? Why?"),
        (p1_best_plan, "Which plan is fair / biased?"),
        (p1_population, "Population or sample"),
        (p1_census, "Census or sample? Why?"),
        (p1_closest, "Closest to the census"),
        (p1_best_fit, "Which method fits best?")],
    2: [(p2_name_problem, "Name the problem"),
        (p2_fix_question, "Fair wording"),
        (p2_fix_plan, "Fix the survey"),
        (p2_which_fair, "Plan with or without a problem"),
        (p2_results_fair, "Are the results fair?")],
    3: [(p3_looks_really, "Looks vs really (graph)"),
        (p3_whats_wrong, "What makes it misleading?"),
        (p3_looks_text, "Looks vs really (numbers)"),
        (p3_picture, "Pictures that grow two ways")],
    4: [(p4_percent_of, "Find the percent"),
        (p4_part, "Find the part"),
        (p4_whole, "Find the whole"),
        (p4_compare, "Compare groups fairly"),
        (p4_two_way, "Two-way tables")],
}
TOPIC_COUNT = 4
_picker = Picker(GENERATORS)


def make_question(n):
    """(text, correct, 5 choices, visual or None) for topic n (1-4)."""
    return _picker.make(n)[:4]


def make_question_typed(n):
    """Same, plus the question type's name and the worked solution."""
    return _picker.make(n)
