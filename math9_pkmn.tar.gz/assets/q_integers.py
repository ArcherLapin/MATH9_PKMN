# ==========================================
# q_integers.py  -  Math 9 questions: Homework Club, Integer Operations
#   (No pygame here: question making only.  main.py shows them; Team Battle uses them too.)
#
#   n = 1  Adding Integers         -7 + (-5),  -8 + 5 + (-12) + 3,  word problems
#   n = 2  Subtracting Integers    6 - (-9),  "add the opposite",  4 - (-2) + 7 - 9,  temperature change
#   n = 3  Multiplying Integers    (-6)(7),  (-2)(3)(-4),  a diver going down 4 m a minute
#   n = 4  Dividing Integers       -48 / (-6),  (-6)(8) / (-12),  -63 / (-9) + 2,  the mean temperature
#
#   For Homework Club (students who find math hard): no "find the missing number" (that is
#   solving equations, a different topic), numbers up to 30, multiplying within the times tables.
#
#   Every answer is a whole number.  Numbers are random, so a repeat is very unlikely.
#   Wrong answers are real mistakes first: a sign error, adding instead of subtracting,
#   "- (-9)" read as "- 9", a times-table slip.
#   Plain ASCII only: products are written (-6)(4), division with "/", no degree sign.
#   Every question is ONE line: a word problem's story is in the yellow "Show Info" panel.
#   make_question(n) -> (text, correct, [5 choices], None)
# ==========================================
import random

from q_tools import build, build_num, ask, info, fnum, as_units, as_money, NAMES, Picker


# ==========================================
# 0. SMALL HELPERS
# ==========================================
def nz(lo, hi):
    """A random integer from lo to hi, never 0."""
    return random.choice([i for i in range(lo, hi + 1) if i != 0])


def nz2(lo, hi):
    """Never 0, 1 or -1 (multiplying or dividing by 1 is too easy)."""
    return random.choice([i for i in range(lo, hi + 1) if i not in (-1, 0, 1)])


def p(v):
    """A number inside an expression: negatives in brackets  (-4)."""
    return f"({fnum(v)})" if v < 0 else fnum(v)


def chain(vals, ops):
    """[-8, 5, -12], ['+', '-'] -> '-8 + 5 - (-12)'."""
    return fnum(vals[0]) + "".join(f" {o} {p(v)}" for o, v in zip(ops, vals[1:]))


def value(vals, ops):
    return vals[0] + sum(v if o == "+" else -v for o, v in zip(ops, vals[1:]))


def ints(v):
    return v.denominator == 1 and abs(v) <= 999


def evaluate(text, ans, traps):
    return build_num(ask(f"Evaluate:   {text}"), ans, traps, ok=ints)


def word(story, question, ans, traps, fmt=None):
    """A word problem: the story in Show Info, a short question in the text box (always one line)."""
    return build_num(ask(question), ans, traps, fmt=fmt or (lambda vals: [fnum(v) for v in vals]),
                     ok=ints, visual=info(story))


DEG = as_units("degrees")
METRES = as_units("m")


# ==========================================
# 1. ADDING INTEGERS
# ==========================================
def q1_add_two():
    r = random.choice([10, 20, 20, 30])
    a, b = nz(-r, r), nz(-r, r)
    if a > 0 and b > 0:                                # at least one negative
        if random.random() < 0.5:
            a = -a
        else:
            b = -b
    ans = a + b
    mag = abs(a) + abs(b)
    traps = [-ans, a - b, b - a, -mag if ans >= 0 else mag, mag if ans >= 0 else -mag]
    return evaluate(f"{fnum(a)} + {p(b)}", ans, traps)


def q1_add_many():
    n = random.randint(3, 4)
    vals = [nz(-20, 20) for _ in range(n)]
    if sum(1 for v in vals if v < 0) < 2:              # at least two negatives
        for k in random.sample(range(n), 2):
            vals[k] = -abs(vals[k])
    ans = sum(vals)
    neg = random.choice([v for v in vals if v < 0])
    traps = [-ans, ans - 2 * neg,                      # one negative sign dropped
             sum(abs(v) for v in vals) * (1 if ans >= 0 else -1),
             ans - 2 * vals[-1], ans + 10, ans - 10]
    return evaluate(" + ".join([fnum(vals[0])] + [p(v) for v in vals[1:]]), ans, traps)


def q1_add_word():
    t = random.choice(["temp", "sub", "money", "golf"])
    if t == "temp":
        start, rise = nz(-20, -1), random.randint(3, 25)
        ans = start + rise
        story = f"At 6 a.m. it was {start} degrees C. By noon the temperature rose {rise} degrees."
        return word(story, "What was the temperature at noon?", ans, [start - rise, -ans, -(start - rise), rise], DEG)
    if t == "sub":
        depth, up = random.randint(4, 30) * 10, random.randint(2, 25) * 5
        if up >= depth:
            return None
        ans = -depth + up
        story = f"A submarine is at -{depth} m ({depth} m below sea level). It rises {up} m."
        return word(story, "Where is the submarine now?", ans, [-depth - up, -ans, depth + up, up - depth - 10], METRES)
    if t == "money":
        name = random.choice(NAMES)
        owe, dep = random.randint(5, 60), random.randint(5, 80)
        if owe == dep:
            return None
        ans = -owe + dep
        story = f"{name}'s bank balance is -${owe}. {name} deposits ${dep}."
        return word(story, f"What is {name}'s new balance?", ans, [-owe - dep, -ans, owe + dep, ans - 10, ans + 10],
                    as_money)
    name = random.choice(NAMES)                        # golf: under par is negative
    scores = [nz(-5, 4) for _ in range(4)]
    if sum(1 for s in scores if s < 0) < 2:
        return None
    ans = sum(scores)
    shown = ", ".join(f"+{s}" if s > 0 else str(s) for s in scores)
    story = f"In golf, a score under par is negative. {name} scores {shown} in four rounds."
    traps = [-ans, sum(abs(s) for s in scores), ans - 2 * scores[0], ans + 2 * scores[-1]]
    return word(story, f"What is {name}'s total golf score?", ans, traps)


# ==========================================
# 2. SUBTRACTING INTEGERS
# ==========================================
def q2_sub_two():
    r = random.choice([10, 20, 20, 30])
    a, b = nz(-r, r), nz(-r, r)
    if random.random() < 0.65 and b > 0:               # mostly "- (negative)"
        b = -b
    ans = a - b
    traps = [a + b, -ans, -(a + b), abs(a) - abs(b), abs(a) + abs(b)]
    return evaluate(f"{fnum(a)} - {p(b)}", ans, traps)


def q2_rewrite():
    a, b = nz(-15, 15), nz(-15, 15)
    if random.random() < 0.6 and b > 0:
        b = -b
    correct = (f"{fnum(a)} + {p(-b)}", a - b)          # add the opposite
    cands = [(f"{fnum(a)} + {p(b)}", a + b),           # didn't change the sign of b
             (f"{fnum(-a)} + {p(-b)}", -a - b),        # changed the first number too
             (f"{fnum(-a)} + {p(b)}", -a + b),
             (f"{fnum(a)} - {p(-b)}", a + b),          # changed the sign but kept the minus
             (f"{fnum(b)} + {p(-a)}", b - a)]
    traps = [s for s, v in cands if v != correct[1]]   # never a second right answer
    return build(ask(f"Add the opposite:   {fnum(a)} - {p(b)}  is the same as ..."), correct[0], traps)


def q2_sub_chain():
    n = random.randint(3, 4)
    vals = [nz(-15, 15) for _ in range(n)]
    ops = [random.choice(["+", "-"]) for _ in range(n - 1)]
    if not any(o == "-" and v < 0 for o, v in zip(ops, vals[1:])):     # always one "- (negative)"
        k = random.randrange(n - 1)
        ops[k], vals[k + 1] = "-", -abs(vals[k + 1])
    ans = value(vals, ops)
    wrong = vals[0] + sum(v if o == "+" else -abs(v) for o, v in zip(ops, vals[1:]))   # "- (-3)" read as "- 3"
    traps = [wrong, -ans, ans + 2 * vals[-1], ans - 10, ans + 10]
    return evaluate(chain(vals, ops), ans, traps)


def q2_sub_word():
    t = random.choice(["warmer", "change", "apart"])
    if t == "warmer":
        hi, lo = random.randint(-5, 15), random.randint(-25, -2)
        if hi <= lo:
            return None
        ans = hi - lo
        story = f"One day the high was {hi} degrees C and the low was {lo} degrees C."
        return word(story, "How many degrees warmer was the high than the low?", ans,
                    [hi + lo, -ans, abs(hi + lo) if hi + lo else None, lo - hi - 2], DEG)
    if t == "change":
        a, b = nz(-15, 12), nz(-20, 12)
        if a == b or (a > 0 and b > 0):
            return None
        ans = b - a
        story = f"The temperature went from {a} degrees C to {b} degrees C."
        return word(story, "What was the change in temperature?", ans, [a - b, a + b, -(a + b), abs(b) - abs(a)], DEG)
    up, down = random.randint(5, 60), random.randint(3, 40)
    who = random.choice([("A bird flies", "a fish swims"), ("A kite flies", "a diver swims"),
                         ("A drone flies", "a submarine is")])
    ans = up - (-down)
    story = f"{who[0]} {up} m above sea level ({up} m), and {who[1]} {down} m below sea level (-{down} m)."
    return word(story, "How far apart are they (up and down)?", ans, [up - down, down - up, -ans, ans + 10], METRES)


# ==========================================
# 3. MULTIPLYING INTEGERS
# ==========================================
def slip(a, b):
    """Times-table slips with the right sign: (|a| +- 1) x |b|."""
    s = 1 if a * b > 0 else -1
    return [s * (abs(a) + 1) * abs(b), s * (abs(a) - 1) * abs(b), s * abs(a) * (abs(b) + 1)]


def q3_mul_two():
    a, b = nz2(-12, 12), nz2(-12, 12)                   # within the times tables
    if a > 0 and b > 0:
        a = -a
    if random.random() < 0.5:
        a, b = b, a
    ans = a * b
    return evaluate(f"({fnum(a)})({fnum(b)})", ans, [-ans, a + b, -(a + b)] + slip(a, b))


def q3_mul_many():
    n = random.choice([3, 3, 4])
    vals = [nz2(-6, 6) if random.random() < 0.8 else random.choice([1, -1]) for _ in range(n)]
    if sum(1 for v in vals if v < 0) < 2:              # at least two negatives (the sign rule matters)
        for k in random.sample(range(n), 2):
            vals[k] = -abs(vals[k])
    ans = 1
    for v in vals:
        ans *= v
    if abs(ans) > 400:
        return None
    first_two = vals[0] * vals[1]
    traps = [-ans, sum(vals), first_two + sum(vals[2:]), -sum(vals),
             ans // vals[-1] if vals[-1] not in (1, -1) else None]
    return evaluate("".join(f"({fnum(v)})" for v in vals), ans, traps)


def q3_mul_word():
    """Equal groups (no time, no rates: those are Linear Relations)."""
    t = random.choice(["game", "golf", "debt", "steps"])
    k, n = random.randint(2, 9), random.randint(3, 9)
    name = random.choice(NAMES)
    traps = [k * n, -(k + n), k + n, -k * (n + 1), -k * (n - 1)]
    if t == "game":
        story = f"In a video game, each wrong move is worth -{k} points. {name} makes {n} wrong moves."
        return word(story, "What do the wrong moves add up to?", -k * n, traps)
    if t == "golf":
        story = f"In golf, a score under par is negative. {n} players on a team each score -{k}."
        return word(story, "What is the team's total score?", -k * n, traps)
    if t == "debt":
        story = f"{n} friends each owe ${k}, so each balance is -${k}."
        return word(story, "What do their balances add up to?", -k * n, traps, as_money)
    story = f"A diver goes down {n} ladder steps. Each step is -{k} m."
    return word(story, "What is the diver's total change in depth?", -k * n, traps, METRES)


# ==========================================
# 4. DIVIDING INTEGERS
# ==========================================
def q4_div_two():
    b, q = nz2(-12, 12), nz2(-12, 12)
    if b > 0 and q > 0:
        if random.random() < 0.5:
            b = -b
        else:
            q = -q
    a = b * q
    traps = [-q, q + 1 if q != -1 else 2, q - 1 if q != 1 else -2, a - b if abs(a - b) < 200 else None,
             -(q + 1), b * b if abs(b * b) < 200 else None]
    return evaluate(f"{fnum(a)} / {p(b)}", q, traps)


def q4_div_mixed():
    if random.random() < 0.5:                          # (a)(b) / c
        c, k = nz2(-9, 9), nz2(-8, 8)
        a = nz2(-9, 9)
        b = c * k
        ans = a * k
        text = f"({fnum(a)})({fnum(b)}) / {p(c)}"
        traps = [-ans, a * b * c if abs(a * b * c) < 400 else None, a + k, a * b, -(a + k)]
    else:                                              # a / b + c  or  a / b - c
        b, q, c = nz2(-9, 9), nz2(-9, 9), nz(-15, 15)
        a = b * q
        op = random.choice(["+", "-"])
        ans = q + c if op == "+" else q - c
        text = f"{fnum(a)} / {p(b)} {op} {p(c)}"
        traps = [-q + c if op == "+" else -q - c, q - c if op == "+" else q + c, -ans,
                 a // (b + c) if op == "+" and b + c and a % (b + c) == 0 else None]
    return evaluate(text, ans, traps)


def q4_mean():
    for _ in range(200):
        n = random.choice([4, 5, 5, 6])
        temps = [random.randint(-15, 8) for _ in range(n)]
        s = sum(temps)
        if s % n == 0 and s < 0 and sum(1 for t in temps if t < 0) >= 2:
            break
    else:
        return None
    ans = s // n
    shown = ", ".join(str(t) for t in temps)
    story = f"The low temperatures for {n} days were {shown} degrees C."
    pos = sum(abs(t) for t in temps)                   # signs ignored
    traps = [-ans, s, pos // n if pos % n == 0 else None, -(pos // n) if pos % n == 0 else None,
             s // (n - 1) if s % (n - 1) == 0 else None, ans + 1, ans - 1]
    return word(story, "What was the mean (average) low temperature?", ans, traps, DEG)


def q4_div_word():
    """Equal sharing (no time, no rates: those are Linear Relations)."""
    t = random.choice(["debt", "golf", "steps", "payments"])
    k, n = random.randint(2, 9), random.randint(3, 9)
    total = k * n
    traps = [k, -total, -(total - n), n, -n]
    if t == "debt":
        story = f"{n} friends share a debt of ${total} equally. Together their balance is -${total}."
        return word(story, "What is each friend's share of the debt?", -k, traps, as_money)
    if t == "golf":
        story = f"{n} golf players have a team score of -{total}. They all have the same score."
        return word(story, "What is each player's score?", -k, traps)
    if t == "steps":
        story = f"A diver goes down {total} m (-{total} m) in {n} equal steps."
        return word(story, "What is the change in depth for each step?", -k, traps, METRES)
    name = random.choice(NAMES)                        # two negatives: (-total) / (-k) is positive
    story = f"{name}'s balance is -${total}. {name} splits it into equal payments of -${k}."
    return word(story, "How many payments is that?", n, [-n, -total, total - k, n + 1, k])


# ==========================================
# 5. QUESTION MIX
# ==========================================
GENERATORS = {
    1: [(q1_add_two, "Add two integers"), (q1_add_many, "Add several integers"),
        (q1_add_word, "Adding: word problems")],
    2: [(q2_sub_two, "Subtract two integers"), (q2_rewrite, "Add the opposite"),
        (q2_sub_chain, "Add and subtract"), (q2_sub_word, "Subtracting: word problems")],
    3: [(q3_mul_two, "Multiply two integers"), (q3_mul_many, "Multiply several integers"),
        (q3_mul_word, "Multiplying: word problems")],
    4: [(q4_div_two, "Divide two integers"), (q4_div_mixed, "Multiply and divide"), (q4_mean, "Mean of integers"),
        (q4_div_word, "Dividing: word problems")],
}
TOPIC_COUNT = 4
_picker = Picker(GENERATORS)


def make_question(n):
    """(text, correct, 5 choices, visual or None) for topic n (1-4)."""
    return _picker.make(n)[:4]


def make_question_typed(n):
    return _picker.make(n)
