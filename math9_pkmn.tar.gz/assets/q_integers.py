# ==========================================
# q_integers.py  -  Math 9 questions: Homework Club (Integer Operations + Combining Like Terms)
#   (No pygame here: question making only.  main.py shows them; Team Battle uses them too.)
#
#   n = 1  Adding Integers         -7 + (-5),  -8 + 5 + (-12) + 3,  word problems
#   n = 2  Subtracting Integers    6 - (-9),  "add the opposite",  4 - (-2) + 7 - 9,  temperature change
#   n = 3  Multiplying Integers    (-6)(7),  (-2)(3)(-4),  a diver going down 4 m a minute
#   n = 4  Dividing Integers       -48 / (-6),  (-6)(8) / (-12),  -63 / (-9) + 2,  the mean temperature
#   n = 5  Combining Like Terms    3x + 5 - 2y + 4x - 7 + y,  4a - b + 2a + 6b,  which terms are
#                                  like terms,  the coefficient after simplifying,
#                                  (2x + 3y - 4) + (x - y + 6),  a triangle's perimeter
#                                  (1, 2 or 3 random letters from a, b, x, y in each question)
#
#   For Homework Club (students who find math hard): no "find the missing number" (that is
#   solving equations, a different topic), numbers up to 30, multiplying within the times tables.
#   Combining Like Terms: letters a, b, x, y and plain numbers, coefficients -9 to 9,
#   adding brackets only (no "- ( )", that needs the distributive property).
#
#   Topics 1-4: every answer is a whole number.  Topic 5: answers are written in alphabetical
#   order, then the number (4a - b + 7x - 2).  Numbers are random, so a repeat is very unlikely.
#   Wrong answers are real mistakes first: a sign error, adding instead of subtracting,
#   "- (-9)" read as "- 9", a times-table slip, two letters put together (6xy), a number added to the x's.
#   Plain ASCII only: products are written (-6)(4), division with "/", no degree sign.
#   Every question is ONE line: a word problem's story is in the yellow "Show Info" panel, and so is
#   a like-terms expression too long to fit on the line with its question (one_line, section 5).
#   make_question(n) -> (text, correct, [5 choices], None)
# ==========================================
import random

from q_tools import build, build_num, ask, info, fnum, as_units, as_money, NAMES, Picker


# ==========================================
# 0. SMALL HELPERS
# ==========================================
def nz(lo, hi):
    """A random integer from lo to hi, never 0."""
    return random.choice([i for i in range(lo, hi + 1) if i != 0])


def nz2(lo, hi):
    """Never 0, 1 or -1 (multiplying or dividing by 1 is too easy)."""
    return random.choice([i for i in range(lo, hi + 1) if i not in (-1, 0, 1)])


def p(v):
    """A number inside an expression: negatives in brackets  (-4)."""
    return f"({fnum(v)})" if v < 0 else fnum(v)


def chain(vals, ops):
    """[-8, 5, -12], ['+', '-'] -> '-8 + 5 - (-12)'."""
    return fnum(vals[0]) + "".join(f" {o} {p(v)}" for o, v in zip(ops, vals[1:]))


def value(vals, ops):
    return vals[0] + sum(v if o == "+" else -v for o, v in zip(ops, vals[1:]))


def ints(v):
    return v.denominator == 1 and abs(v) <= 999


def evaluate(text, ans, traps):
    return build_num(ask(f"Evaluate:   {text}"), ans, traps, ok=ints)


def word(story, question, ans, traps, fmt=None):
    """A word problem: the story in Show Info, a short question in the text box (always one line)."""
    return build_num(ask(question), ans, traps, fmt=fmt or (lambda vals: [fnum(v) for v in vals]),
                     ok=ints, visual=info(story))


DEG = as_units("degrees")
METRES = as_units("m")


# ==========================================
# 1. ADDING INTEGERS
# ==========================================
def q1_add_two():
    r = random.choice([10, 20, 20, 30])
    a, b = nz(-r, r), nz(-r, r)
    if a > 0 and b > 0:                                # at least one negative
        if random.random() < 0.5:
            a = -a
        else:
            b = -b
    ans = a + b
    mag = abs(a) + abs(b)
    traps = [-ans, a - b, b - a, -mag if ans >= 0 else mag, mag if ans >= 0 else -mag]
    return evaluate(f"{fnum(a)} + {p(b)}", ans, traps)


def q1_add_many():
    n = random.randint(3, 4)
    vals = [nz(-20, 20) for _ in range(n)]
    if sum(1 for v in vals if v < 0) < 2:              # at least two negatives
        for k in random.sample(range(n), 2):
            vals[k] = -abs(vals[k])
    ans = sum(vals)
    neg = random.choice([v for v in vals if v < 0])
    traps = [-ans, ans - 2 * neg,                      # one negative sign dropped
             sum(abs(v) for v in vals) * (1 if ans >= 0 else -1),
             ans - 2 * vals[-1], ans + 10, ans - 10]
    return evaluate(" + ".join([fnum(vals[0])] + [p(v) for v in vals[1:]]), ans, traps)


def q1_add_word():
    t = random.choice(["temp", "sub", "money", "golf"])
    if t == "temp":
        start, rise = nz(-20, -1), random.randint(3, 25)
        ans = start + rise
        story = f"At 6 a.m. it was {start} degrees C. By noon the temperature rose {rise} degrees."
        return word(story, "What was the temperature at noon?", ans, [start - rise, -ans, -(start - rise), rise], DEG)
    if t == "sub":
        depth, up = random.randint(4, 30) * 10, random.randint(2, 25) * 5
        if up >= depth:
            return None
        ans = -depth + up
        story = f"A submarine is at -{depth} m ({depth} m below sea level). It rises {up} m."
        return word(story, "Where is the submarine now?", ans, [-depth - up, -ans, depth + up, up - depth - 10], METRES)
    if t == "money":
        name = random.choice(NAMES)
        owe, dep = random.randint(5, 60), random.randint(5, 80)
        if owe == dep:
            return None
        ans = -owe + dep
        story = f"{name}'s bank balance is -${owe}. {name} deposits ${dep}."
        return word(story, f"What is {name}'s new balance?", ans, [-owe - dep, -ans, owe + dep, ans - 10, ans + 10],
                    as_money)
    name = random.choice(NAMES)                        # golf: under par is negative
    scores = [nz(-5, 4) for _ in range(4)]
    if sum(1 for s in scores if s < 0) < 2:
        return None
    ans = sum(scores)
    shown = ", ".join(f"+{s}" if s > 0 else str(s) for s in scores)
    story = f"In golf, a score under par is negative. {name} scores {shown} in four rounds."
    traps = [-ans, sum(abs(s) for s in scores), ans - 2 * scores[0], ans + 2 * scores[-1]]
    return word(story, f"What is {name}'s total golf score?", ans, traps)


# ==========================================
# 2. SUBTRACTING INTEGERS
# ==========================================
def q2_sub_two():
    r = random.choice([10, 20, 20, 30])
    a, b = nz(-r, r), nz(-r, r)
    if random.random() < 0.65 and b > 0:               # mostly "- (negative)"
        b = -b
    ans = a - b
    traps = [a + b, -ans, -(a + b), abs(a) - abs(b), abs(a) + abs(b)]
    return evaluate(f"{fnum(a)} - {p(b)}", ans, traps)


def q2_rewrite():
    a, b = nz(-15, 15), nz(-15, 15)
    if random.random() < 0.6 and b > 0:
        b = -b
    correct = (f"{fnum(a)} + {p(-b)}", a - b)          # add the opposite
    cands = [(f"{fnum(a)} + {p(b)}", a + b),           # didn't change the sign of b
             (f"{fnum(-a)} + {p(-b)}", -a - b),        # changed the first number too
             (f"{fnum(-a)} + {p(b)}", -a + b),
             (f"{fnum(a)} - {p(-b)}", a + b),          # changed the sign but kept the minus
             (f"{fnum(b)} + {p(-a)}", b - a)]
    traps = [s for s, v in cands if v != correct[1]]   # never a second right answer
    return build(ask(f"Add the opposite:   {fnum(a)} - {p(b)}  is the same as ..."), correct[0], traps)


def q2_sub_chain():
    n = random.randint(3, 4)
    vals = [nz(-15, 15) for _ in range(n)]
    ops = [random.choice(["+", "-"]) for _ in range(n - 1)]
    if not any(o == "-" and v < 0 for o, v in zip(ops, vals[1:])):     # always one "- (negative)"
        k = random.randrange(n - 1)
        ops[k], vals[k + 1] = "-", -abs(vals[k + 1])
    ans = value(vals, ops)
    wrong = vals[0] + sum(v if o == "+" else -abs(v) for o, v in zip(ops, vals[1:]))   # "- (-3)" read as "- 3"
    traps = [wrong, -ans, ans + 2 * vals[-1], ans - 10, ans + 10]
    return evaluate(chain(vals, ops), ans, traps)


def q2_sub_word():
    t = random.choice(["warmer", "change", "apart"])
    if t == "warmer":
        hi, lo = random.randint(-5, 15), random.randint(-25, -2)
        if hi <= lo:
            return None
        ans = hi - lo
        story = f"One day the high was {hi} degrees C and the low was {lo} degrees C."
        return word(story, "How many degrees warmer was the high than the low?", ans,
                    [hi + lo, -ans, abs(hi + lo) if hi + lo else None, lo - hi - 2], DEG)
    if t == "change":
        a, b = nz(-15, 12), nz(-20, 12)
        if a == b or (a > 0 and b > 0):
            return None
        ans = b - a
        story = f"The temperature went from {a} degrees C to {b} degrees C."
        return word(story, "What was the change in temperature?", ans, [a - b, a + b, -(a + b), abs(b) - abs(a)], DEG)
    up, down = random.randint(5, 60), random.randint(3, 40)
    who = random.choice([("A bird flies", "a fish swims"), ("A kite flies", "a diver swims"),
                         ("A drone flies", "a submarine is")])
    ans = up - (-down)
    story = f"{who[0]} {up} m above sea level ({up} m), and {who[1]} {down} m below sea level (-{down} m)."
    return word(story, "How far apart are they (up and down)?", ans, [up - down, down - up, -ans, ans + 10], METRES)


# ==========================================
# 3. MULTIPLYING INTEGERS
# ==========================================
def slip(a, b):
    """Times-table slips with the right sign: (|a| +- 1) x |b|."""
    s = 1 if a * b > 0 else -1
    return [s * (abs(a) + 1) * abs(b), s * (abs(a) - 1) * abs(b), s * abs(a) * (abs(b) + 1)]


def q3_mul_two():
    a, b = nz2(-12, 12), nz2(-12, 12)                   # within the times tables
    if a > 0 and b > 0:
        a = -a
    if random.random() < 0.5:
        a, b = b, a
    ans = a * b
    return evaluate(f"({fnum(a)})({fnum(b)})", ans, [-ans, a + b, -(a + b)] + slip(a, b))


def q3_mul_many():
    n = random.choice([3, 3, 4])
    vals = [nz2(-6, 6) if random.random() < 0.8 else random.choice([1, -1]) for _ in range(n)]
    if sum(1 for v in vals if v < 0) < 2:              # at least two negatives (the sign rule matters)
        for k in random.sample(range(n), 2):
            vals[k] = -abs(vals[k])
    ans = 1
    for v in vals:
        ans *= v
    if abs(ans) > 400:
        return None
    first_two = vals[0] * vals[1]
    traps = [-ans, sum(vals), first_two + sum(vals[2:]), -sum(vals),
             ans // vals[-1] if vals[-1] not in (1, -1) else None]
    return evaluate("".join(f"({fnum(v)})" for v in vals), ans, traps)


def q3_mul_word():
    """Equal groups (no time, no rates: those are Linear Relations)."""
    t = random.choice(["game", "golf", "debt", "steps"])
    k, n = random.randint(2, 9), random.randint(3, 9)
    name = random.choice(NAMES)
    traps = [k * n, -(k + n), k + n, -k * (n + 1), -k * (n - 1)]
    if t == "game":
        story = f"In a video game, each wrong move is worth -{k} points. {name} makes {n} wrong moves."
        return word(story, "What do the wrong moves add up to?", -k * n, traps)
    if t == "golf":
        story = f"In golf, a score under par is negative. {n} players on a team each score -{k}."
        return word(story, "What is the team's total score?", -k * n, traps)
    if t == "debt":
        story = f"{n} friends each owe ${k}, so each balance is -${k}."
        return word(story, "What do their balances add up to?", -k * n, traps, as_money)
    story = f"A diver goes down {n} ladder steps. Each step is -{k} m."
    return word(story, "What is the diver's total change in depth?", -k * n, traps, METRES)


# ==========================================
# 4. DIVIDING INTEGERS
# ==========================================
def q4_div_two():
    b, q = nz2(-12, 12), nz2(-12, 12)
    if b > 0 and q > 0:
        if random.random() < 0.5:
            b = -b
        else:
            q = -q
    a = b * q
    traps = [-q, q + 1 if q != -1 else 2, q - 1 if q != 1 else -2, a - b if abs(a - b) < 200 else None,
             -(q + 1), b * b if abs(b * b) < 200 else None]
    return evaluate(f"{fnum(a)} / {p(b)}", q, traps)


def q4_div_mixed():
    if random.random() < 0.5:                          # (a)(b) / c
        c, k = nz2(-9, 9), nz2(-8, 8)
        a = nz2(-9, 9)
        b = c * k
        ans = a * k
        text = f"({fnum(a)})({fnum(b)}) / {p(c)}"
        traps = [-ans, a * b * c if abs(a * b * c) < 400 else None, a + k, a * b, -(a + k)]
    else:                                              # a / b + c  or  a / b - c
        b, q, c = nz2(-9, 9), nz2(-9, 9), nz(-15, 15)
        a = b * q
        op = random.choice(["+", "-"])
        ans = q + c if op == "+" else q - c
        text = f"{fnum(a)} / {p(b)} {op} {p(c)}"
        traps = [-q + c if op == "+" else -q - c, q - c if op == "+" else q + c, -ans,
                 a // (b + c) if op == "+" and b + c and a % (b + c) == 0 else None]
    return evaluate(text, ans, traps)


def q4_mean():
    for _ in range(200):
        n = random.choice([4, 5, 5, 6])
        temps = [random.randint(-15, 8) for _ in range(n)]
        s = sum(temps)
        if s % n == 0 and s < 0 and sum(1 for t in temps if t < 0) >= 2:
            break
    else:
        return None
    ans = s // n
    shown = ", ".join(str(t) for t in temps)
    story = f"The low temperatures for {n} days were {shown} degrees C."
    pos = sum(abs(t) for t in temps)                   # signs ignored
    traps = [-ans, s, pos // n if pos % n == 0 else None, -(pos // n) if pos % n == 0 else None,
             s // (n - 1) if s % (n - 1) == 0 else None, ans + 1, ans - 1]
    return word(story, "What was the mean (average) low temperature?", ans, traps, DEG)


def q4_div_word():
    """Equal sharing (no time, no rates: those are Linear Relations)."""
    t = random.choice(["debt", "golf", "steps", "payments"])
    k, n = random.randint(2, 9), random.randint(3, 9)
    total = k * n
    traps = [k, -total, -(total - n), n, -n]
    if t == "debt":
        story = f"{n} friends share a debt of ${total} equally. Together their balance is -${total}."
        return word(story, "What is each friend's share of the debt?", -k, traps, as_money)
    if t == "golf":
        story = f"{n} golf players have a team score of -{total}. They all have the same score."
        return word(story, "What is each player's score?", -k, traps)
    if t == "steps":
        story = f"A diver goes down {total} m (-{total} m) in {n} equal steps."
        return word(story, "What is the change in depth for each step?", -k, traps, METRES)
    name = random.choice(NAMES)                        # two negatives: (-total) / (-k) is positive
    story = f"{name}'s balance is -${total}. {name} splits it into equal payments of -${k}."
    return word(story, "How many payments is that?", n, [-n, -total, total - k, n + 1, k])


# ==========================================
# 5. COMBINING LIKE TERMS  (letters a, b, x, y and plain numbers)
#   Every question is made fresh from random numbers (nothing is premade): each one picks
#   1, 2 or 3 random letters from a, b, x, y (plus, most of the time, plain numbers).
#   A term is (coefficient, letter):  (3, "x") = 3x,   (-1, "b") = -b,   (5, "") = 5.
#   Answers are always written in alphabetical order, then the number:  4a - b + 7x - 2.
# ==========================================
LETTERS = ["a", "b", "x", "y"]
LT_ORDER = LETTERS + [""]                      # "" = a plain number (the constant)


def lt_body(c, v):
    """A term without its sign: 3x, x, 7."""
    a = abs(c)
    if v == "":
        return str(a)
    return v if a == 1 else f"{a}{v}"


def lt_text(terms):
    """[(3, 'x'), (-2, 'y'), (5, '')] in this order -> '3x - 2y + 5' (nothing combined, zeros left out)."""
    out = ""
    for c, v in terms:
        if c == 0:
            continue
        if not out:
            out = ("-" if c < 0 else "") + lt_body(c, v)
        else:
            out += (" - " if c < 0 else " + ") + lt_body(c, v)
    return out or "0"


def lt_term(c, v):
    return lt_text([(c, v)])


def lt_total(terms):
    """The terms combined:  {'x': 7, 'y': -1, '': -2}."""
    tot = {}
    for c, v in terms:
        tot[v] = tot.get(v, 0) + c
    return tot


def lt_simple(tot):
    """{'x': 7, 'y': -1, '': -2} -> '7x - y - 2'  (letters in alphabetical order, then the number).
    A made-up mistake term like 'ax' (two letters put together) goes right after its first letter."""
    def place(v):
        if v in LT_ORDER:
            return (LT_ORDER.index(v), 0)
        return (LT_ORDER.index(v[0]), 1)
    return lt_text([(tot[v], v) for v in sorted(tot, key=place)])


def pick_kinds(n_letters=None, number=None):
    """The kinds of terms in one question, e.g. ['a', 'x', ''] or ['b', 'y'] or ['x', ''].
    1, 2 or 3 random letters; a plain number most of the time (always with just one letter)."""
    n = n_letters or random.choice([1, 2, 2, 3, 3])
    letters = sorted(random.sample(LETTERS, n))
    if number is None:
        number = n == 1 or random.random() < 0.75
    return letters + ([""] if number else [])


def lt_split(t, pieces=2):
    """Split a total into like terms that add up to it: 7 -> [4, 3] or [9, -2] (no zeros, at most 9)."""
    for _ in range(100):
        parts = [nz(-9, 9) for _ in range(pieces - 1)]
        last = t - sum(parts)
        if last != 0 and abs(last) <= 9:
            return parts + [last]
    return None


def lt_expression(kinds):
    """Random terms for the kinds given, in a random order (3 to 8 terms).
    At least 2 kinds (or the only 2) have 2 or more terms, so there is something to combine."""
    k = random.randint(min(2, len(kinds)), len(kinds))
    to_split = random.sample(kinds, k)
    terms = []
    for v in kinds:
        if v in to_split:
            n = 3 if len(kinds) <= 2 and random.random() < 0.3 else 2
            parts = lt_split(nz(-12, 12), n)
            if parts is None:
                return None
            terms += [(c, v) for c in parts]
        else:
            terms.append((nz(-9, 9), v))
    random.shuffle(terms)
    return terms, lt_total(terms)


def lt_variants(tot):
    """Near misses: one sign flipped, or one coefficient off by 1."""
    out = []
    for v in tot:
        if tot[v]:
            out.append(lt_simple({**tot, v: -tot[v]}))
            for d in (1, -1):
                out.append(lt_simple({**tot, v: tot[v] + d}))
    random.shuffle(out)
    return out


def lt_traps(terms, tot):
    """Wrong answers students really give, most common first."""
    out = []
    letters = [v for v in LT_ORDER if v and tot.get(v)]
    C = tot.get("", 0)
    negs = [(c, v) for i, (c, v) in enumerate(terms) if c < 0 and i > 0]
    if negs:                                           # one "- 5" read as "+ 5"
        c, v = random.choice(negs)
        out.append(lt_simple({**tot, v: tot[v] - 2 * c}))
    if len(letters) >= 2:                              # two different letters put together: 6xy
        v, w = random.sample(letters, 2)
        v, w = sorted([v, w])
        if tot[v] + tot[w]:
            rest = {u: c for u, c in tot.items() if u not in (v, w)}
            out.append(lt_simple({**rest, v + w: tot[v] + tot[w]}))
    if C and letters:                                  # the number added to a letter: 7x - 2 -> 5x
        v = random.choice(letters)
        if tot[v] + C:
            out.append(lt_simple({**tot, v: tot[v] + C, "": 0}))
    if len(tot) >= 2:                                  # everything added into one term
        s = sum(tot.values())
        if s:
            out.append(lt_term(s, letters[0] if letters else ""))
    ones = [(c, v) for c, v in terms if abs(c) == 1 and v]
    if ones:                                           # a plain x (or b) counted as 0
        c, v = random.choice(ones)
        out.append(lt_simple({**tot, v: tot[v] - c}))
    no_signs = lt_total([(abs(c), v) for c, v in terms])
    if no_signs != tot:                                # every minus sign ignored
        out.append(lt_simple(no_signs))
    return out + lt_variants(tot)


ONE_LINE = 60        # a question longer than this would take 2 lines: its expression goes to Show Info


def one_line(full, short, expr):
    """(question text, visual).  The whole question on one line if it fits; if not, a short
    question on one line and the expression in the yellow Show Info panel."""
    if len(full) <= ONE_LINE:
        return full, None
    return short, {"notes": ["The expression:", "", expr]}


def q5_simplify():
    """Simplify:  3x + 5 - 2y + 4x - 7 + y,   4a - b + 2a + 6b,   5x + 3 - 2x - 8."""
    for _ in range(20):
        made = lt_expression(pick_kinds())
        if made and sum(1 for v in made[1].values() if v) >= 2:
            break
    else:
        return None
    terms, tot = made
    expr = lt_text(terms)
    text, vis = one_line(f"Simplify:   {expr}", "Simplify the expression (see Show Info).", expr)
    return build(text, lt_simple(tot), lt_traps(terms, tot), vis)


def q5_part():
    """After simplifying, what is the coefficient of a letter, or the number?"""
    kinds = pick_kinds(random.choice([2, 3]))
    made = lt_expression(kinds)
    if made is None:
        return None
    terms, tot = made
    v = random.choice([k for k in kinds if k] * 2 + ([""] if "" in kinds else []))
    ans = tot[v]
    what = f"the coefficient of {v}" if v else "the constant"
    negs = [c for i, (c, w) in enumerate(terms) if w == v and c < 0 and i > 0]
    others = [tot[w] for w in kinds if w != v]
    traps = [ans - 2 * negs[0] if negs else None,          # one "- 5" read as "+ 5"
             sum(abs(c) for c, w in terms if w == v),      # minus signs ignored
             ans + others[0],                              # added an unlike term in
             -ans] + others
    expr = lt_text(terms)
    text, vis = one_line(f"Simplify  {expr} .  What is {what}?",
                         f"Simplify (see Show Info). What is {what}?", expr)
    return build_num(text, ans, traps, ok=ints, visual=vis)


def q5_like():
    """Which term is a like term with -4y?   /   Which two terms are like terms?"""
    if random.random() < 0.5:
        v, w = random.sample(LETTERS, 2)
        vw = "".join(sorted(v + w))
        c = nz2(-9, 9)
        c2 = random.choice([k for k in range(-9, 10) if k not in (0, c)])
        traps = [lt_term(c, w), lt_term(c, ""), lt_term(c, vw), lt_term(c2, w), lt_term(c2, ""),
                 lt_term(c2, vw)]
        return build(f"Which term is a LIKE TERM with  {lt_term(c, v)} ?", lt_term(c2, v), traps)
    # In  3x - 5 + 3y + 7x  only ONE pair are like terms: which pair?
    kinds = random.sample(LT_ORDER, random.choice([3, 3, 4]))
    if random.random() < 0.4:                           # a two-letter term too, like 2xy
        kinds[-1] = "".join(sorted(random.sample(LETTERS, 2)))
    like = random.choice(kinds)
    a = nz2(-9, 9)
    b = random.choice([k for k in range(-9, 10) if k not in (0, a)])
    terms = [(a, like), (b, like)]
    others = [v for v in kinds if v != like]
    for i, v in enumerate(others):                     # one other term has the same number as a like term
        terms.append((a if i == 0 else nz(-9, 9), v))
    random.shuffle(terms)
    if len({lt_term(c, v).lstrip("-") for c, v in terms}) < len(terms):
        return None                                    # two terms that look the same: confusing
    pair = lambda s, t: f"{lt_term(*s)}  and  {lt_term(*t)}"
    pairs = [(s, t) for i, s in enumerate(terms) for t in terms[i + 1:]]
    right = [pair(s, t) for s, t in pairs if s[1] == t[1]][0]
    same_num = [pair(s, t) for s, t in pairs if s[1] != t[1] and abs(s[0]) == abs(t[0])]
    traps = same_num + [pair(s, t) for s, t in pairs if s[1] != t[1] and pair(s, t) not in same_num]
    expr = lt_text(terms)
    text, vis = one_line(f"In  {expr} ,  which two are LIKE TERMS?",
                         "Which two terms are LIKE TERMS? (see Show Info)", expr)
    return build(text, right, traps, vis)


def q5_add():
    """Add two expressions:  (2x + 3y - 4) + (x - y + 6)   (plus only: no "- ( )")."""
    kinds = pick_kinds(random.choice([1, 2, 2, 3]), number=True)
    A = [(nz(-9, 9), v) for v in kinds]
    keep = random.sample(kinds, random.randint(max(1, len(kinds) - 1), len(kinds)))
    B = [(nz(-9, 9), v) for v in kinds if v in keep]
    if random.random() < 0.4:
        random.shuffle(B)
    terms = A + B
    tot = lt_total(terms)
    if sum(1 for v in tot.values() if v) < 2:
        return None
    text = f"({lt_text(A)}) + ({lt_text(B)})"
    text, vis = one_line(f"Simplify:   {text}", "Add the two expressions (see Show Info).", text)
    return build(text, lt_simple(tot), lt_traps(terms, tot), vis)


def q5_perimeter():
    """A triangle's sides 2a + 3,  a + 4x,  5x + 1  ->  the perimeter in simplest form."""
    kinds = pick_kinds(random.choice([1, 2, 2]), number=True)
    sides = []
    for _ in range(3):
        use = random.sample(kinds, min(2, len(kinds)))
        sides.append([(random.randint(1, 6), v) for v in kinds if v in use])
    terms = [t for s in sides for t in s]
    tot = lt_total(terms)
    shown = ",   ".join(lt_text(s) for s in sides)
    story = f"A triangle has sides  {shown}.  The perimeter is all three sides added together."
    traps = lt_traps(terms, tot) + [lt_simple(lt_total(sides[0] + sides[1]))]    # forgot a side
    return build("What is the triangle's perimeter, in simplest form?", lt_simple(tot), traps,
                 visual=info(story))


# ==========================================
# 6. QUESTION MIX
# ==========================================
GENERATORS = {
    1: [(q1_add_two, "Add two integers"), (q1_add_many, "Add several integers"),
        (q1_add_word, "Adding: word problems")],
    2: [(q2_sub_two, "Subtract two integers"), (q2_rewrite, "Add the opposite"),
        (q2_sub_chain, "Add and subtract"), (q2_sub_word, "Subtracting: word problems")],
    3: [(q3_mul_two, "Multiply two integers"), (q3_mul_many, "Multiply several integers"),
        (q3_mul_word, "Multiplying: word problems")],
    4: [(q4_div_two, "Divide two integers"), (q4_div_mixed, "Multiply and divide"), (q4_mean, "Mean of integers"),
        (q4_div_word, "Dividing: word problems")],
    5: [(q5_simplify, "Simplify"), (q5_simplify, "Simplify"),            # listed twice: the main skill
        (q5_like, "Which are like terms?"), (q5_part, "Coefficient after simplifying"),
        (q5_add, "Add two expressions"), (q5_perimeter, "Perimeter of a triangle")],
}
TOPIC_COUNT = 5
_picker = Picker(GENERATORS)


def make_question(n):
    """(text, correct, 5 choices, visual or None) for topic n (1-5)."""
    return _picker.make(n)[:4]


def make_question_typed(n):
    return _picker.make(n)
