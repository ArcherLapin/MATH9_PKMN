# ==========================================
# q_rational.py  -  Math 9 questions: Rational Numbers (Week 1)
#   (No pygame here: question making only.  Class Raid uses it; any mode can.)
#
#   n = 1  Integer operations          (+, -, x, / with negatives)
#   n = 2  Order of operations         (brackets, then x and /, then + and -)
#   n = 3  Decimals and fractions      (rational numbers, always a whole-number answer)
#   n = 4  Estimation                  (round, then compute: the best estimate)
#
#   Every answer is a whole number.  Numbers are random, so a repeat is very unlikely.
#   Wrong answers are real mistakes first (sign errors, wrong order...).
#   Plain ASCII only: products are written (-6)(4), division with "/".
#   make_question(n) -> (text, correct, [5 choices], None)
# ==========================================
import random
from fractions import Fraction as F

from q_tools import build_num, ask, info, fnum, Picker


def nz(lo, hi):
    return random.choice([i for i in range(lo, hi + 1) if i != 0])


def nz2(lo, hi):
    """Not 0, 1 or -1 (multiplying by 1 is too easy)."""
    return random.choice([i for i in range(lo, hi + 1) if i not in (-1, 0, 1)])


def p(v):
    """A number inside an expression: negatives in brackets  (-4)."""
    s = fnum(v)
    return f"({s})" if F(v) < 0 else s


def first(v):
    """The first number of an expression (no brackets needed)."""
    return fnum(v)


def ints_ok(v):
    return v.denominator == 1 and abs(v) <= 400


# ==========================================
# 1. INTEGER OPERATIONS
# ==========================================
def q1_add_sub():
    vals = [nz(-20, 20) for _ in range(random.randint(3, 4))]
    ops = [random.choice(["+", "-"]) for _ in vals[1:]]
    if not any(o == "-" and v < 0 for o, v in zip(ops, vals[1:])):      # always one "- (negative)"
        k = random.randrange(len(ops))
        ops[k], vals[k + 1] = "-", -abs(vals[k + 1])
    text = first(vals[0]) + "".join(f" {o} {p(v)}" for o, v in zip(ops, vals[1:]))
    ans = vals[0] + sum(v if o == "+" else -v for o, v in zip(ops, vals[1:]))
    wrong_double = vals[0] + sum(v if o == "+" else (v if v < 0 else -v) for o, v in zip(ops, vals[1:]))
    traps = [wrong_double, -ans, ans + 2 * abs(vals[-1]), sum(abs(v) for v in vals) * (1 if ans > 0 else -1)]
    return build_num(ask(f"Evaluate:   {text}"), ans, traps, ok=ints_ok)


def q1_mul_div():
    kind = random.choice(["mm", "md", "dd", "mmm"])
    if kind == "mm":
        a, b = nz2(-15, 15), nz2(-15, 15)
        text, ans = f"({fnum(a)})({fnum(b)})", a * b
        traps = [-ans, a + b, -(a + b)]
    elif kind == "dd":
        b, q = nz2(-15, 15), nz2(-15, 15)
        a = b * q
        text, ans = f"{p(a)} / {p(b)}", q
        traps = [-q, a - b, a * b if abs(a * b) < 400 else None]
    elif kind == "md":                                   # (a)(b) / c, with c dividing b
        a, c, k = nz2(-12, 12), nz2(-9, 9), nz2(-8, 8)
        b = c * k
        text, ans = f"({fnum(a)})({fnum(b)}) / {p(c)}", a * k
        traps = [-ans, a * b * c if abs(a * b * c) < 400 else None, a + k, a * b]
    else:
        a, b, c = nz2(-8, 8), nz2(-8, 8), nz2(-6, 6)
        text, ans = f"({fnum(a)})({fnum(b)})({fnum(c)})", a * b * c
        traps = [-ans, a + b + c, a * b + c]
    return build_num(ask(f"Evaluate:   {text}"), ans, traps, ok=ints_ok)


# ==========================================
# 2. ORDER OF OPERATIONS
# ==========================================
def q2_order():
    t = random.choice("abcde")
    if t == "a":                                         # a + b(c)
        a, b, c = nz(-15, 15), nz(-9, 9), nz(-9, 9)
        text = f"{first(a)} {'+' if b > 0 else '-'} {abs(b)}({fnum(c)})"     # a times-bracket always shows
        ans = a + b * c
        traps = [(a + b) * c, a - b * c, -(a + b * c)]
    elif t == "b":                                       # a - b(c - d)
        a, b, c, d = nz(-20, 20), random.randint(2, 9), nz(-9, 9), nz(-9, 9)
        if c == d:
            return None
        text, ans = f"{first(a)} - {b}({fnum(c)} - {p(d)})", a - b * (c - d)
        traps = [(a - b) * (c - d), a - b * c - d, a - b * (c + d), a + b * (c - d)]
    elif t == "c":                                       # a / (b - c) + d
        q, b, c, d = nz(-9, 9), nz(-9, 9), nz(-9, 9), nz(-12, 12)
        if b == c:
            return None
        a = q * (b - c)
        text, ans = f"{p(a)} / ({fnum(b)} - {p(c)}) + {p(d)}", q + d
        traps = [F(a, b) - c + d if b and a % b == 0 else None, q - d, -q + d, F(a, b - c + d) if b - c + d and a % (b - c + d) == 0 else None]
    elif t == "d":                                       # (a)(b) - c / d
        a, b, d, q = nz(-9, 9), nz(-9, 9), nz(-6, 6), nz(-9, 9)
        c = d * q
        text, ans = f"({fnum(a)})({fnum(b)}) - {p(c)} / {p(d)}", a * b - q
        traps = [a * b + q, -a * b - q, F(a * b - c, d) if (a * b - c) % d == 0 else None]
    else:                                                # (a + b)(c) - d
        a, b, c, d = nz(-9, 9), nz(-9, 9), nz(-6, 6), nz(-12, 12)
        text, ans = f"({fnum(a)} + {p(b)})({fnum(c)}) - {p(d)}", (a + b) * c - d
        traps = [a + b * c - d, (a + b) * c + d, (a + b) * (c - d)]
    return build_num(ask(f"Evaluate:   {text}"), ans, traps, ok=ints_ok)


# ==========================================
# 3. DECIMALS AND FRACTIONS  (whole-number answers)
# ==========================================
def dec(v):
    return fnum(v)


def q3_rational():
    t = random.choice("abcde")
    if t == "a":                                         # (-2.5)(-4)
        for _ in range(100):
            a = F(random.randint(1, 99), random.choice([2, 4, 5, 10]))
            b = F(random.choice([2, 4, 5, 6, 8, 10, 12, 14, 16, 20]))
            if (a * b).denominator == 1 and a.denominator != 1:
                break
        a, b = a * random.choice([1, -1]), b * random.choice([1, -1])
        if abs(a * b) > 400:
            return None
        text, ans = f"({dec(a)})({dec(b)})", a * b
        traps = [-ans, a + b if (a + b).denominator == 1 else None, ans * 10, ans / 10 if (ans / 10).denominator == 1 else None]
    elif t == "b":                                       # (-7.2) / (-0.8)
        q, d = F(nz2(-15, 15)), F(random.choice([2, 3, 4, 5, 6, 7, 8, 9, 12, 15, 25]), 10) * random.choice([1, -1])
        a = q * d
        text, ans = f"{p(a)} / {p(d)}", q
        traps = [-q, q * 10, q / 10 if (q / 10).denominator == 1 else None]
    elif t == "c":                                       # (-2/3)(9)
        den = random.choice([2, 3, 4, 5, 6, 7, 8, 9, 10, 12])
        num = random.choice([k for k in range(1, 3 * den) if F(k, den).denominator == den])
        m = den * random.randint(1, 5)
        fr, whole = F(num, den) * random.choice([1, -1]), m * random.choice([1, -1])
        fs = f"{'-' if fr < 0 else ''}{abs(fr.numerator)}/{fr.denominator}"
        text, ans = f"({fs})({fnum(whole)})", fr * whole
        traps = [-ans, F(abs(fr.numerator) * whole, 1) * (1 if fr > 0 else -1), F(whole, den) * (1 if fr > 0 else -1),
                 ans * 2]
    elif t == "d":                                       # -5/6 - 7/6
        den = random.choice([2, 3, 4, 5, 6, 8])
        for _ in range(100):
            a, b = nz(-3 * den, 3 * den), nz(-3 * den, 3 * den)
            op = random.choice(["+", "-"])
            s = a + b if op == "+" else a - b
            if s % den == 0 and a % den and b % den:
                break
        else:
            return None
        bt = f"{abs(b)}/{den}" if b > 0 else f"(-{abs(b)}/{den})"
        text, ans = f"{a}/{den} {op} {bt}", F(s, den)
        wrong = a - b if op == "+" else a + b
        traps = [-ans, F(wrong, den) if wrong % den == 0 else None, F(s, 2 * den) if s % (2 * den) == 0 else None, s]
    else:                                                # -4.7 + 1.2 - 3.5
        for _ in range(200):
            vals = [F(nz(-99, 99), 10) for _ in range(3)]
            ops = [random.choice(["+", "-"]) for _ in range(2)]
            s = vals[0] + sum(v if o == "+" else -v for o, v in zip(ops, vals[1:]))
            if s.denominator == 1 and s != 0 and all(v.denominator != 1 for v in vals):
                break
        else:
            return None
        text = dec(vals[0]) + "".join(f" {o} {p(v)}" for o, v in zip(ops, vals[1:]))
        ans = s
        alt = vals[0] + sum(v if o == "+" else (v if v < 0 else -v) for o, v in zip(ops, vals[1:]))   # "- (-3)" read as "- 3"
        traps = [-ans, alt if alt.denominator == 1 else None]
    return build_num(ask(f"Evaluate:   {text}"), ans, traps, ok=ints_ok)


# ==========================================
# 4. ESTIMATION
# ==========================================
def near(n):
    """A decimal close to whole number n (like 4.9 or 6.1)."""
    return F(n * 10 + random.choice([-2, -1, 1, 2]), 10)


def q4_estimate():
    t = random.choice("mds")
    if t == "m":
        a, b = nz2(-12, 12), random.randint(2, 12) * random.choice([1, -1])
        x, y = near(a), near(b)
        if x == 0 or y == 0:
            return None
        text, ans = f"({dec(x)})({dec(y)})", a * b
        traps = [-ans, a + b, ans * 10, (a + 1) * (b + 1) if a * b > 0 else (a - 1) * (b + 1)]
    elif t == "d":
        b, q = random.randint(2, 9) * random.choice([1, -1]), nz2(-15, 15)
        a = b * q
        x, y = near(a), near(b)
        text, ans = f"{p(x)} / {p(y)}", q
        traps = [-q, q * 10, a - b, q + 1]
    else:
        whole = [nz(-30, 30) for _ in range(3)]
        vals = [near(w) for w in whole]
        ops = [random.choice(["+", "-"]) for _ in range(2)]
        text = dec(vals[0]) + "".join(f" {o} {p(v)}" for o, v in zip(ops, vals[1:]))
        ans = whole[0] + sum(w if o == "+" else -w for o, w in zip(ops, whole[1:]))
        wrong = whole[0] + sum(abs(w) if o == "+" else -abs(w) for o, w in zip(ops, whole[1:]))
        traps = [-ans, wrong, ans + 10, ans - 10]
    return build_num(ask(f"Best estimate:   {text}"), ans, traps, ok=ints_ok,
                     visual=info("Estimate: round each number to the nearest whole number first, then calculate."))


# ==========================================
# 5. QUESTION MIX
# ==========================================
GENERATORS = {
    1: [(q1_add_sub, "Add and subtract integers"), (q1_mul_div, "Multiply and divide integers")],
    2: [(q2_order, "Order of operations")],
    3: [(q3_rational, "Decimals and fractions")],
    4: [(q4_estimate, "Estimation")],
}
TOPIC_COUNT = 4
_picker = Picker(GENERATORS)


def make_question(n):
    """(text, correct, 5 choices, visual or None) for topic n (1-4)."""
    return _picker.make(n)[:4]


def make_question_typed(n):
    return _picker.make(n)
