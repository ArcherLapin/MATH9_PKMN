# ==========================================
# team_net.py  -  Team Battle: online rooms and turns.  (No pygame in this file.)
#   Every browser meets in a free Firebase Realtime Database. team_battle.py draws the screens.
#
# Right now: 2 students (one room per topic) vs 2 AI Pokemon.
# Later, 2 students vs 2 students: in TEAM_SETUP, change the two "ai" to "human".
# Nothing else needs to change; the room size follows TEAM_SETUP.
#
# How it works (no server code needed):
#   tb/clock/<id>          used once to line up the student's clock with the server's
#   tb/rooms/t1 ... t8     one room per topic (t4 = topic 4.4)
#       waiting/<id>       {j: time joined, t: last heartbeat}   (no names are stored)
#       game               {id, level, start, order: one player id per TEAM_SETUP slot
#                           ("ai2" = an AI slot), alive/<id>: heartbeat,
#                           log/e000, e001...: one entry per turn, over: true}
#   Every browser replays the same turn log the same way, so everyone sees the same HP.
#   A student's turn is written by that student. AI turns (and "zoned out" for a student
#   whose tab closed) are written by the first student still connected.
# ==========================================
import json
import random
import sys
import time

import pokedex

# ---------- Settings you can change ----------
FIREBASE_URL = "https://pkmngame-a5711-default-rtdb.firebaseio.com"

# The battle, in turn order. Same "team" number = same side.
#   pokemon: a name from pokedex.py     player: "human" (a student) or "ai"
TEAM_SETUP = [
    {"pokemon": "Pikachu",   "team": 0, "player": "human", "hp": 300},
    {"pokemon": "Raichu",    "team": 0, "player": "human", "hp": 300},
    {"pokemon": "Vaporeon",  "team": 1, "player": "ai",    "hp": 350},
    {"pokemon": "Flareon",   "team": 1, "player": "ai",    "hp": 350},
]

RANDOM_TURN_ORDER = True   # True: a new random turn order each battle (not shown to students)
                           # False: always the TEAM_SETUP order

PLAYER_POWER = 30          # damage for a correct answer (before the streak bonus)
STREAK_BONUS = 1.2         # x1.2 more damage for each correct answer in a row
CRIT_CHANCE = 5            # % chance a correct answer is a critical hit (x1.5)
AI_ATTACK = 100            # AI damage = move power x AI_ATTACK / 100 (moves: pokedex.py)
BERRIES = 1                # Sitrus Berries per student (eating one uses your turn)
BERRY_HEAL = 50
TURN_SECONDS = 60          # time limit for a student's turn (a topic not listed below uses this)
TURN_SECONDS_BY_TOPIC = {  # topic number: seconds per turn  (1 = 4.1 ... 8 = Unit 4 Review)
    1: 60,                 # 4.1 Standard Form
    2: 60,                 # 4.2 Vertex Form
    3: 60,                 # 4.3 Changing to Vertex Form
    4: 60,                 # 4.4 Factored Form
    5: 60,                 # 4.5 Solving Problems
    6: 60,                 # 4.6 Inequalities: Graphs
    7: 60,                 # 4.7 Inequalities: Algebra
    8: 60,                 # Unit 4 Review
}

# ---------- Timing (milliseconds) ----------
READ_MS = 8000             # time to read the last turn's messages before a student's clock starts
AI_THINK_MS = 4000         # an AI moves this long after the turn before it
INTRO_MS = 7000            # "Team Battle!" messages before the first turn
GRACE_MS = 4000            # wait past a student's deadline before someone else zones them out
LEFT_MS = 12000            # no heartbeat for this long = the student closed the tab
WAIT_FRESH_MS = 9000       # a waiting student counts if their heartbeat is newer than this
WAIT_PURGE_MS = 60000      # old waiting entries are deleted after this
SV = {".sv": "timestamp"}  # Firebase fills in its own time

N = len(TEAM_SETUP)
HUMAN_SLOTS = [i for i, s in enumerate(TEAM_SETUP) if s["player"] == "human"]
ROOM_SIZE = len(HUMAN_SLOTS)


def local_ms():
    return time.time() * 1000.0


def slot_name(i):
    return TEAM_SETUP[i]["pokemon"]


def slot_team(i):
    return TEAM_SETUP[i]["team"]


def is_ai(i):
    return TEAM_SETUP[i]["player"] == "ai"


# ==========================================
# 1. TRANSPORTS: how a request actually gets sent
# ==========================================
class JSTransport:
    """In the browser (pygbag): uses the page's own fetch(). Results are picked up each frame."""
    _JS = r"""
window.__tb = window.__tb || {res: {}};
window.tbReq = function (id, method, url, body) {
  var opt = {method: method, cache: "no-store"};
  if (body !== "") { opt.body = body; }
  fetch(url, opt).then(function (r) {
    return r.text().then(function (t) { window.__tb.res[id] = r.status + "\n" + t; });
  }).catch(function (e) { window.__tb.res[id] = "0\n" + e; });
  return 1;
};
window.tbTake = function (id) {
  var v = window.__tb.res[id];
  if (v === undefined) { return ""; }
  delete window.__tb.res[id];
  return v;
};
"""

    def __init__(self):
        import platform as _pf
        self.win = _pf.window
        try:
            self.win.eval(self._JS)
        except Exception:
            self.win.Function(self._JS)()

    def start(self, rid, method, url, body):
        self.win.tbReq(rid, method, url, body)

    def take(self, rid):
        v = self.win.tbTake(rid)
        v = "" if v is None else str(v)
        if not v:
            return None
        status, _, text = v.partition("\n")
        try:
            return int(status), text
        except ValueError:
            return 0, text


class ThreadTransport:
    """Running as normal Python on a computer (for testing): urllib in a background thread."""
    def __init__(self):
        import threading
        self.threading = threading
        self.res = {}

    def start(self, rid, method, url, body):
        def work():
            import urllib.request
            import urllib.error
            try:
                req = urllib.request.Request(url, data=body.encode() if body else None, method=method)
                with urllib.request.urlopen(req, timeout=10) as r:
                    self.res[rid] = (r.status, r.read().decode())
            except urllib.error.HTTPError as e:
                self.res[rid] = (e.code, e.read().decode(errors="replace"))
            except Exception as e:                       # no internet, bad URL...
                self.res[rid] = (0, str(e))
        self.threading.Thread(target=work, daemon=True).start()

    def take(self, rid):
        return self.res.pop(rid, None)


def make_transport():
    if sys.platform == "emscripten":
        return JSTransport()
    return ThreadTransport()


# ==========================================
# 2. REQUESTS AND THE SERVER CLOCK
# ==========================================
class Call:
    def __init__(self):
        self.done, self.ok, self.status, self.data = False, False, 0, None


class Net:
    def __init__(self, base_url, transport):
        self.base = base_url.rstrip("/")
        self.tr = transport
        self.pending = {}
        self.count = 0
        self.errors = 0              # failed requests in a row (for a "connection problem" note)

    def request(self, method, path, body=None):
        self.count += 1
        rid = f"r{self.count}"
        call = Call()
        self.pending[rid] = call
        self.tr.start(rid, method, f"{self.base}/tb/{path}.json", "" if body is None else json.dumps(body))
        return call

    def get(self, path):
        return self.request("GET", path)

    def put(self, path, value):
        return self.request("PUT", path, value)

    def delete(self, path):
        return self.request("DELETE", path)

    def update(self):
        for rid in list(self.pending):
            r = self.tr.take(rid)
            if r is None:
                continue
            call = self.pending.pop(rid)
            call.status, text = r
            call.ok = 200 <= call.status < 300
            if call.ok:
                try:
                    call.data = json.loads(text) if text else None
                except ValueError:
                    call.ok = False
            call.done = True
            self.errors = 0 if call.ok else self.errors + 1


class Clock:
    """The server's time, estimated from the student's own clock plus an offset."""
    def __init__(self, local=local_ms):
        self.local = local
        self.offset = None

    def ready(self):
        return self.offset is not None

    def now(self):
        return self.local() + (self.offset or 0)


class ClockSync:
    """Write the server time once, read it back, compare with our clock."""
    def __init__(self, net, clock, me):
        self.net, self.clock, self.me = net, clock, me
        self.step, self.call, self.t0, self.t1 = 0, None, 0, 0

    def update(self):
        if self.clock.ready():
            return True
        if self.call is None:
            self.t0 = self.clock.local()
            self.call = self.net.put(f"clock/{self.me}", SV)
            self.step = 1
        elif self.call.done:
            if not self.call.ok:
                self.call = None                           # try again
            elif self.step == 1:
                self.t1 = self.clock.local()
                self.call = self.net.get(f"clock/{self.me}")
                self.step = 2
            else:
                ts = self.call.data
                if isinstance(ts, (int, float)):
                    self.clock.offset = ts - (self.t0 + self.t1) / 2
                    self.net.delete(f"clock/{self.me}")
                    return True
                self.call = None
        return False


def new_id():
    """A player/game id. Includes the time in ms, so two copies can't share one even if
    their random numbers were the same."""
    stamp = int(time.time() * 1000) % (36 ** 6)
    tail = "".join(random.choice("abcdefghjkmnpqrstuvwxyz23456789") for _ in range(8))
    return f"{stamp:x}{tail}"


def room_key(level):
    return f"t{level}"     # (keys that are plain numbers would turn into a list in Firebase)


# ==========================================
# 3. ROOMS (topic screen and waiting room)
# ==========================================
def fresh_waiting(room, now):
    """Ids of the students really waiting in a room, first to join first."""
    w = (room or {}).get("waiting") or {}
    out = []
    for pid, e in w.items():
        if isinstance(e, dict) and isinstance(e.get("t"), (int, float)) and now - e["t"] <= WAIT_FRESH_MS:
            j = e.get("j") if isinstance(e.get("j"), (int, float)) else e["t"]
            out.append((j, pid))
    out.sort()
    return [pid for _, pid in out]


def game_ok(game):
    return (isinstance(game, dict) and isinstance(game.get("order"), list) and len(game["order"]) == N
            and isinstance(game.get("start"), (int, float)))


def game_active(game, now):
    """A battle is going on: not finished, and a student in it is still connected."""
    if not game_ok(game) or game.get("over"):
        return False
    if now - game["start"] < 30000:
        return True
    alive = game.get("alive") or {}
    return any(isinstance(alive.get(game["order"][i]), (int, float)) and now - alive[game["order"][i]] <= LEFT_MS
               for i in HUMAN_SLOTS)


def room_status(room, now):
    """('busy', 0) for a battle in progress, else ('open', number waiting)."""
    if game_active((room or {}).get("game"), now):
        return "busy", 0
    return "open", len(fresh_waiting(room, now))


class Lobby:
    """Reads all the rooms every 2 seconds.  status = {level: (state, count)}."""
    def __init__(self, net, clock, levels):
        self.net, self.clock, self.levels = net, clock, list(levels)
        self.call, self.next_t = None, 0
        self.status = None

    def update(self):
        t = self.clock.local()
        if self.call is None and t >= self.next_t:
            self.call = self.net.get("rooms")
        elif self.call is not None and self.call.done:
            if self.call.ok:
                rooms = self.call.data if isinstance(self.call.data, dict) else {}
                now = self.clock.now()
                self.status = {lv: room_status(rooms.get(room_key(lv)), now) for lv in self.levels}
            self.call, self.next_t = None, t + 2000


class Waiter:
    """Sitting in a topic's waiting room. result becomes ('start', game) or ('full', None)."""
    def __init__(self, net, clock, level, me):
        self.net, self.clock, self.me, self.level = net, clock, me, level
        self.path = f"rooms/{room_key(level)}"
        self.j = None                            # when I joined (server time), once known
        self.count = 1
        self.result = None
        self.beat, self.next_beat = None, 0
        self.poll, self.next_poll = None, 0
        self.made, self.made_call = None, None   # the game I created, if I am the host
        self.left = False

    def leave(self):
        if not self.left:
            self.left = True
            self.net.delete(f"{self.path}/waiting/{self.me}")

    def update(self):
        if self.result or self.left:
            return
        t = self.clock.local()
        if self.made_call is not None and self.made_call.done:
            if not self.made_call.ok:
                self.made = None                 # could not create the game: try again
            self.made_call = None
        if (self.beat is None or self.beat.done) and t >= self.next_beat:
            self.beat = self.net.put(f"{self.path}/waiting/{self.me}", {"j": self.j if self.j else SV, "t": SV})
            self.next_beat = t + 2000
        if self.poll is None and t >= self.next_poll:
            self.poll = self.net.get(self.path)
        elif self.poll is not None and self.poll.done:
            if self.poll.ok:
                self._look(self.poll.data if isinstance(self.poll.data, dict) else {})
            self.poll, self.next_poll = None, t + 1000

    def _look(self, room):
        now = self.clock.now()
        mine = (room.get("waiting") or {}).get(self.me)
        if self.j is None and isinstance(mine, dict) and isinstance(mine.get("j"), (int, float)):
            self.j = mine["j"]
        game = room.get("game")
        if game_active(game, now):
            if self.me in game["order"]:
                self.result = ("start", game)
            elif self.made is None:
                self.result = ("full", None)
            if self.result:
                self.leave()
            return
        fresh = fresh_waiting(room, now)
        self.count = max(1, len(fresh))
        if fresh and fresh[0] == self.me:        # first in line looks after the room
            for pid, e in (room.get("waiting") or {}).items():
                if not isinstance(e, dict) or now - (e.get("t") or 0) > WAIT_PURGE_MS:
                    self.net.delete(f"{self.path}/waiting/{pid}")
            if len(fresh) >= ROOM_SIZE and self.made is None:
                self.made = make_game(fresh[:ROOM_SIZE], self.level)
                self.made_call = self.net.put(f"{self.path}/game", self.made)


def make_game(players, level):
    """Students go into the human slots at random (so who is Pikachu is random)."""
    ids = list(players)
    random.shuffle(ids)
    order = [ids.pop() if i in HUMAN_SLOTS else f"ai{i}" for i in range(N)]
    turns = random.sample(range(N), N) if RANDOM_TURN_ORDER else list(range(N))
    return {"id": new_id(), "level": level, "start": SV, "order": order, "turns": turns}


def turn_order(game):
    """The battle's turn order (slot numbers); TEAM_SETUP order if missing or broken."""
    t = game.get("turns")
    return list(t) if isinstance(t, list) and sorted(t) == list(range(N)) else list(range(N))


# ==========================================
# 4. REPLAYING THE TURN LOG (everyone gets the same answer)
#   Slots are numbered 0..N-1 in TEAM_SETUP order.
#   A message is (text, target slot or None, HP change, effect name or None).
# ==========================================
def teammates(i):
    return [j for j in range(N) if slot_team(j) == slot_team(i)]


def foes(i):
    return [j for j in range(N) if slot_team(j) != slot_team(i)]


def target_for(i, hp):
    """A correct answer hits the opponent in the same position (1st or 2nd); if fainted, another."""
    fs = [j for j in foes(i)]
    first = fs[teammates(i).index(i) % len(fs)]
    if hp[first] > 0:
        return first
    return next((j for j in fs if hp[j] > 0), None)


def log_keys(game):
    log = game.get("log") or {}
    if not isinstance(log, dict):
        return []
    ks = sorted((int(k[1:]), k) for k in log if isinstance(k, str) and k[:1] == "e" and k[1:].isdigit())
    return [k for _, k in ks]


class State:
    pass


def replay(game, my_slot=None):
    """
    Works out the battle from the start, one log entry at a time. Returns a State:
      hp, streak, berries (per slot), active (whose turn, or None), base (when that turn
      started), deadline (for a student's turn), next_key, over, winner (team number),
      entries: (log key, messages) so new entries can be shown.
    """
    s = State()
    s.hp = [TEAM_SETUP[i]["hp"] for i in range(N)]
    s.max_hp = list(s.hp)
    s.streak = [0] * N
    s.berries = [BERRIES] * N
    s.entries, s.over, s.winner = [], False, None
    base = game["start"] + INTRO_MS
    nm = slot_name

    turns = turn_order(game)

    def next_alive(pos):
        """Position in the turn order of the next Pokemon still standing."""
        return next(((pos + k) % N for k in range(N) if s.hp[turns[(pos + k) % N]] > 0), None)

    pos = next_alive(0)
    a = turns[pos]
    keys = log_keys(game)
    log = game.get("log") or {}
    for key in keys:
        ev = log.get(key)
        msgs = []
        if (s.over or not isinstance(ev, dict) or ev.get("g") != game.get("id") or ev.get("p") != a
                or (ev.get("r") == "mv") != is_ai(a) and ev.get("r") != "zo"):
            s.entries.append((key, msgs))             # out-of-date, doubled or wrong-kind entry: ignored
            continue
        p, r = a, ev.get("r")
        if r == "ok":                                  # a student answered correctly
            tgt = ev.get("tg")                         # the opponent they clicked
            if tgt not in foes(p) or s.hp[tgt] <= 0:
                tgt = target_for(p, s.hp)
            d = max(0, min(int(ev.get("d") or 0), 999))
            msgs.append((f"{nm(p)} answered correctly!", None, 0, None))
            if s.streak[p] > 0:
                msgs.append((f"{nm(p)} is pumped! (+{s.streak[p] * 20}%)", None, 0, None))
            msgs.append((f"{nm(p)} used {pokedex.attack_name(nm(p))} on {nm(tgt)}!", None, 0, None))
            msgs.append(("A critical hit! It dealt %d damage!" % d if ev.get("x") else f"It dealt {d} damage!",
                         tgt, -d, pokedex.PLAYER_ATTACK_EFFECT))
            s.hp[tgt] = max(0, s.hp[tgt] - d)
            s.streak[p] += 1
            if s.hp[tgt] == 0:
                msgs.append((f"{nm(tgt)} fainted!", None, 0, None))
        elif r == "mv":                                # an AI's move
            moves = pokedex.moves(nm(p))
            mname, _, _, _, effect = moves[int(ev.get("m") or 0) % len(moves)]
            tgt = ev.get("tg")
            if tgt not in foes(p) or s.hp[tgt] <= 0:
                tgt = target_for(p, s.hp)
            msgs.append((f"{nm(p)} used {mname} on {nm(tgt)}!", None, 0, None))
            if ev.get("ms"):
                msgs.append((f"{nm(p)}'s attack missed!", None, 0, None))
            else:
                d = max(0, min(int(ev.get("d") or 0), 999))
                msgs.append(("A critical hit! It dealt %d damage!" % d if ev.get("x") else f"It dealt {d} damage!",
                             tgt, -d, effect))
                s.hp[tgt] = max(0, s.hp[tgt] - d)
                if s.hp[tgt] == 0:
                    msgs.append((f"{nm(tgt)} fainted!", None, 0, None))
        elif r == "be" and s.berries[p] > 0:          # Sitrus Berry
            s.berries[p] -= 1
            heal = min(BERRY_HEAL, s.max_hp[p] - s.hp[p])
            msgs.append((f"{nm(p)} ate a Sitrus Berry!", None, 0, None))
            msgs.append((f"{nm(p)} recovered {heal} HP!", p, heal, None))
            s.hp[p] += heal
        elif r == "no":                                # wrong answer
            msgs.append((f"{nm(p)} got it wrong!", None, 0, None))
            if p == my_slot and ev.get("c"):
                msgs.append((f"The answer was:  {ev['c']}", None, 0, None))
            if s.streak[p] > 0:
                msgs.append((f"{nm(p)} calms down (0%).", None, 0, None))
            s.streak[p] = 0
        else:                                          # "zo": time ran out
            msgs.append((f"{nm(p)} zoned out!" + ("  (left the battle)" if ev.get("L") else ""), None, 0, None))
            s.streak[p] = 0
        s.entries.append((key, msgs))
        if isinstance(ev.get("t"), (int, float)):
            base = ev["t"]
        for team in {slot_team(j) for j in range(N)}:
            if all(s.hp[j] == 0 for j in range(N) if slot_team(j) == team):
                s.over = True
                s.winner = next(slot_team(j) for j in range(N) if slot_team(j) != team)
        if s.over:
            msgs.append(("The battle is over!", None, 0, None))
        else:
            pos = next_alive(pos + 1)
            a = turns[pos]

    s.active = None if s.over else a
    s.base = base
    s.turn_secs = turn_seconds(game.get("level"))
    s.deadline = base + READ_MS + s.turn_secs * 1000
    last = int(keys[-1][1:]) if keys else -1
    s.next_key = f"e{last + 1:03d}"
    return s


def time_left(state, now):
    """Seconds left on a student's clock (0 .. this topic's time limit)."""
    return max(0, min(state.turn_secs, int((state.deadline - now + 999) // 1000)))


def turn_seconds(level):
    """Time limit for a turn in this topic (TURN_SECONDS_BY_TOPIC, else TURN_SECONDS)."""
    return TURN_SECONDS_BY_TOPIC.get(level, TURN_SECONDS)


def ai_move(i, hp):
    """An AI picks one of its moves and a student to hit (rolled once, then saved in the log)."""
    moves = pokedex.moves(slot_name(i))
    m = random.randrange(len(moves))
    _, power, miss, crit, _ = moves[m]
    targets = [j for j in foes(i) if hp[j] > 0]
    ev = {"m": m, "tg": random.choice(targets) if targets else None}
    damage = int(power * AI_ATTACK / 100)
    if random.randint(1, 100) <= miss:
        ev["ms"] = True
    elif random.randint(1, 100) <= crit:
        ev["d"], ev["x"] = int(damage * 1.5), True
    else:
        ev["d"] = damage
    return ev


# ==========================================
# 5. ONE STUDENT'S SIDE OF A BATTLE
# ==========================================
class Battle:
    """Keeps this browser in step with the battle. The screen reads .state and new messages."""
    def __init__(self, net, clock, level, me, game):
        self.net, self.clock, self.me = net, clock, me
        self.path = f"rooms/{room_key(level)}/game"
        self.game = game
        self.gid = game.get("id")
        self.slot = game["order"].index(me)
        self.state = replay(game, self.slot)
        self.shown = set()                     # log keys already shown as messages
        self.poll, self.next_poll = None, 0
        self.beat, self.next_beat = None, 0
        self.written = set()                   # log keys this browser has written
        self.sending = {}                      # log key -> (entry, request), until it arrives
        self.over_call = None
        self.gone = False                      # the game was replaced or deleted

    # ----- what the screen calls -----
    def my_turn(self):
        return self.state.active == self.slot and self.state.next_key not in self.written

    def send(self, result, damage=0, crit=False, correct_text="", target=None):
        """result: 'ok' (correct; target = the opponent's slot), 'no' (wrong), 'be' (berry)."""
        if not self.my_turn():
            return False
        self._write(self.slot, result, d=damage, x=crit, c=correct_text, tg=target)
        return True

    def damage_now(self):
        """Damage my correct answer does right now, and whether it's a critical hit."""
        power = round(PLAYER_POWER * STREAK_BONUS ** self.state.streak[self.slot])
        crit = random.randint(1, 100) <= CRIT_CHANCE
        return (int(power * 1.5) if crit else power), crit

    def new_messages(self):
        out = []
        for key, msgs in self.state.entries:
            if key not in self.shown:
                self.shown.add(key)
                out += msgs
        return out

    def skip_old(self):
        """Joining part-way: don't replay the whole battle as messages."""
        for key, _ in self.state.entries:
            self.shown.add(key)

    # ----- internals -----
    def _write(self, slot, result, **extra):
        key = self.state.next_key
        ev = {"g": self.gid, "p": slot, "r": result, "t": SV}
        ev.update({k: v for k, v in extra.items() if v or v == 0 and k == "tg"})
        self.written.add(key)
        self.sending[key] = (ev, self.net.put(f"{self.path}/log/{key}", ev))

    def _resend(self):
        """A turn that failed to send is sent again (the same entry, never a new roll)."""
        for key, (ev, call) in list(self.sending.items()):
            if not call.done:
                continue
            if call.ok or key != self.state.next_key:
                del self.sending[key]
            else:
                self.sending[key] = (ev, self.net.put(f"{self.path}/log/{key}", ev))

    def _alive(self, pid, now):
        a = (self.game.get("alive") or {}).get(pid)
        return isinstance(a, (int, float)) and now - a <= LEFT_MS

    def update(self):
        if self.gone:
            return
        t = self.clock.local()
        if not self.state.over and (self.beat is None or self.beat.done) and t >= self.next_beat:
            self.beat = self.net.put(f"{self.path}/alive/{self.me}", SV)
            self.next_beat = t + 2000
        if self.poll is None and t >= self.next_poll:
            self.poll = self.net.get(self.path)
        elif self.poll is not None and self.poll.done:
            if self.poll.ok:
                g = self.poll.data
                if game_ok(g) and g.get("id") == self.gid:
                    self.game = g
                    self.state = replay(g, self.slot)
                elif not self.state.over:
                    self.gone = True
            self.poll, self.next_poll = None, t + 1000
        self._resend()
        self._timers()

    def _timers(self):
        s, now, order = self.state, self.clock.now(), self.game["order"]
        if s.over:
            c = self.over_call
            if c is None or (c.done and not c.ok):
                self.over_call = self.net.put(f"{self.path}/over", True)
            return
        if s.active is None or s.next_key in self.written:
            return
        if s.active == self.slot:                              # my turn: my own clock
            if now >= s.deadline:
                self._write(self.slot, "zo")
            return
        # Anyone else's turn: the first student still connected (not the one whose turn it
        # is) plays the AI and covers for a student who stopped responding.
        keeper = next((i for i in HUMAN_SLOTS
                       if i != s.active and (order[i] == self.me or self._alive(order[i], now))), None)
        if keeper != self.slot:
            return
        if is_ai(s.active):
            if now >= s.base + AI_THINK_MS:
                ev = ai_move(s.active, s.hp)
                self._write(s.active, "mv", **ev)
        elif now >= s.deadline + GRACE_MS:
            self._write(s.active, "zo")
        elif (not self._alive(order[s.active], now) and now >= s.base + 3000
              and now - self.game["start"] > 15000):
            self._write(s.active, "zo", L=True)
