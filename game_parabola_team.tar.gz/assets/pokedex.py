# ==========================================
# pokedex.py  -  every Pokemon the game can show.  THE file to edit when you add a Pokemon.
#   (No pygame here: plain data, used by single player and team battles.)
#
# Sprite files, for folder N:
#   pokemonN/pokemonN_front (1).gif, (2).gif, ...   facing you (opponents)
#   pokemonN/pokemonN_back (1).gif, (2).gif, ...    seen from behind (your own Pokemon)
#   pokemonN/pokemonN_faint.ogg                     faint sound (optional)
# If a Pokemon has only one of front/back, that one is used for both.
# Sprites are sized and placed automatically (the game finds the visible part of the GIF),
# so a new sprite needs no position numbers. "scale" makes one a bit bigger (1.2) or smaller (0.8).
# Exception: an entry with "single" uses those exact hand-tuned numbers in single player
# (the original game's positions). Team battles always use the automatic spots.
#
# To add a Pokemon: copy an entry, change the name, folder and moves. That's it.
#
# Moves: (name, power, miss %, crit %, effect)
#   effect = the animation and sound: "hit", "fire", "water", "leaf", "bolt", "thunder"
#   Damage = power x attack / 100.  Low power: rarely misses, crits often.
#                                   High power: misses often, rarely crits.
# "attack" = the move name used when a student answers correctly (Pikachu and Raichu).
# ==========================================

POKEMON = {
    # ---------- the students' team ----------
    "Pikachu": {"folder": 0, "attack": "Thundershock", "scale": 0.8},     # smaller than Raichu
    "Raichu":  {"folder": 1, "attack": "Thunderbolt",
                "single": (575, 485, 50, 350, 70, 0, 0.75)},                 # original single-player spot

    # ---------- opponents ----------
    "Vaporeon": {"folder": 2, "moves": [
        ("Water Gun",    20,  0, 30, "water"),
        ("Bite",         30,  8, 15, "hit"),
        ("Aurora Beam",  35, 15,  8, "hit"),
        ("Hydro Pump",   45, 35,  5, "water")]},
    "Flareon": {"folder": 3, "scale": 1.2, "moves": [                      # head size like Vaporeon's
        ("Ember",        20,  0, 30, "fire"),
        ("Quick Attack", 30,  8, 15, "hit"),
        ("Flamethrower", 35, 15,  8, "fire"),
        ("Fire Blast",   45, 35,  5, "fire")]},

    # ---------- single-player opponents (same moves as the original game) ----------
    # "single" = the original hand-tuned single-player layout:
    #   (HP box x, HP box y, sprite x, sprite y, Thunderbolt x shift, Thunderbolt y shift, sprite scale)
    #   sprite x, y = top-left corner of the GIF;  scale = zoom on the GIF's real size.
    "Charizard": {"folder": 4, "single": (150, 100, 625,  -50, 70,    0, 0.8), "moves": [
        ("Tackle",       25,  0,  0, "hit"),
        ("Iron Tail",    30,  9, 15, "hit"),
        ("Flamethrower", 35, 15,  5, "fire"),
        ("Fire Punch",   30, 12, 10, "fire")]},
    "Blastoise": {"folder": 5, "single": (150, 100, 650,  220, 50, -350, 0.8), "moves": [
        ("Tackle",       25,  0,  0, "hit"),
        ("Iron Tail",    30, 10, 15, "hit"),
        ("Skull Bash",   30, 20, 30, "hit"),
        ("Hydro Pump",   35, 30, 10, "water")]},
    "Venusaur": {"folder": 6, "single": (150, 100, 600,  175, 50, -350, 0.9), "moves": [
        ("Bolt Strike",  30, 10, 10, "thunder"),
        ("Body Slam",    35, 15,  5, "hit"),
        ("Skull Bash",   25,  5, 20, "hit"),
        ("Leaf Tornado", 40, 30,  5, "leaf")]},
    "Infernape": {"folder": 7, "single": (150, 100, 700,   80, 50, -350, 1.3), "moves": [
        ("Iron Tail",    30,  9, 15, "hit"),
        ("Body Slam",    35, 15,  5, "hit"),
        ("Skull Bash",   25,  5, 20, "hit"),
        ("Fire Punch",   30, 12, 10, "fire")]},
    "Empoleon": {"folder": 8, "single": (150, 100, 650,  130, 50, -350, 1.1), "moves": [
        ("Aqua Jet",     20,  0, 30, "water"),
        ("Drill Peck",   30,  8, 15, "hit"),
        ("Flash Cannon", 35, 15,  8, "hit"),
        ("Hydro Pump",   45, 35,  5, "water")]},
    "Torterra": {"folder": 9, "single": (150, 100, 650,  130, 50, -350, 1.1), "moves": [
        ("Bite",         20,  0, 30, "hit"),
        ("Body Slam",    30,  8, 12, "hit"),
        ("Earthquake",   40, 25,  5, "hit"),
        ("Leaf Tornado", 45, 35,  5, "leaf")]},
    "Snorlax": {"folder": 10, "single": (150, 100, 650,  150, 50, -350, 1.0), "moves": [
        ("Headbutt",     20,  0, 30, "hit"),
        ("Fire Punch",   30,  8, 15, "fire"),
        ("Body Slam",    40, 20,  8, "hit"),
        ("Giga Impact",  50, 40,  5, "hit")]},
    "Mewtwo": {"folder": 11, "single": (150, 100, 650,  150, 50, -350, 1.0), "moves": [
        ("Aura Sphere",  25,  0, 30, "hit"),
        ("Psychic",      30,  8, 15, "hit"),
        ("Flamethrower", 40, 20,  8, "fire"),
        ("Thunder",      50, 40,  5, "thunder")]},
}

# effect -> (animations, sound file name without .ogg)
# These use only the vfx files you already have:
#   hit = vfx/hit,  firepunch = vfx/firepunch,  hydropump = vfx/water,
#   leaftornado = vfx/leaf_tornado,  thunderbolt = vfx/lightning,  thunder = vfx/green_thunder
# A new move just picks one of these effects; it never needs a new vfx file.
EFFECTS = {
    "hit":     (["hit"],                "hit"),
    "fire":    (["firepunch"],          "firepunch"),
    "water":   (["hydropump"],          "hydropump"),
    "leaf":    (["leaftornado", "hit"], "leaftornado"),
    "bolt":    (["thunderbolt", "hit"], "thunderbolt"),
    "thunder": (["thunder", "hit"],     "thunderbolt"),
}

PLAYER_ATTACK_EFFECT = "bolt"     # the students' attack when they answer correctly
_DEFAULT_MOVES = [("Tackle", 30, 5, 10, "hit")]


def info(name):
    """The entry for a Pokemon (an empty one if the name isn't listed)."""
    return POKEMON.get(name, {"folder": None})


def moves(name):
    return info(name).get("moves") or _DEFAULT_MOVES


def attack_name(name):
    return info(name).get("attack", "Thundershock")
