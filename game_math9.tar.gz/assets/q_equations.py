# ==========================================
# q_equations.py  -  Math 9 questions: Multistep Equations (Week 7)
#   (No pygame here: question making only.  main.py shows them.)
#
#   n = 1  Variables on Both Sides        (W7L1, DeltaMath: Three Step Linear Equations)
#   n = 2  Equations with Decimals        (W7L2, DeltaMath: Linear Equations with Decimals)
#   n = 3  Equations with Fractions       (W7L3, DeltaMath: Fractional Linear Equations 1 & 2)
#   n = 4  One / No / Infinite Solutions  (W7L4, DeltaMath: Lin. Eq. w/ Distribution Lev 3)
#
# Every question is checked so it has exactly the chosen answer.  Wrong choices
# are real student mistakes first.  (Same generators as the Week 7 game, unchanged.)
#
# What main.py uses:  make_question(n) -> (text, correct, options, visual)
#   visual is always None here (these questions are text only).
# ==========================================

import random
from fractions import Fraction as F


# ==========================================
# 1. NUMBER FORMATTING
# ==========================================
# Only plain ASCII is used ("-" not the unicode minus, "1/2" not "½")
# so every character exists in caslon.ttf.

def is_dec2(v):
    """True if v has at most 2 decimal places (e.g. 3.75, -0.4, 6)."""
    return (F(v) * 100).denominator == 1


def fmt_dec(v):
    """Fraction -> '3.75', '-0.4', '6'  (v must satisfy is_dec2)."""
    n = int(F(v) * 100)
    sign = "-" if n < 0 else ""
    whole, frac = divmod(abs(n), 100)
    if frac == 0:
        return f"{sign}{whole}"
    return f"{sign}{whole}." + f"{frac:02d}".rstrip("0")


def fmt_frac(v):
    """Fraction -> '4', '-2/3' (always simplest form)."""
    v = F(v)
    return str(v.numerator) if v.denominator == 1 else f"{v.numerator}/{v.denominator}"


def fmt_num(v, mode):
    return fmt_dec(v) if mode == "dec" else fmt_frac(v)


# ==========================================
# 2. EQUATION BUILDING BLOCKS
# ==========================================
# An equation side is a list of nodes:
#   X(a)              ->  a*x
#   C(b)              ->  constant b
#   Mul(m, [nodes])   ->  m(...)          m = -1 shows as  -( ... )
#   Frac(sign, [nodes], d) -> +/- (numerator)/d
# One node per equation is a "slot": its value is solved for so the
# equation has exactly the answer we picked.  This guarantees that every
# generated question is correct and has a clean answer.

class X:
    def __init__(self, a, slot=False):
        self.a, self.slot = F(a), slot


class C:
    def __init__(self, b, slot=False):
        self.b, self.slot = F(b), slot


class Mul:
    def __init__(self, m, inner):
        self.m, self.inner = F(m), inner


class Frac:
    def __init__(self, sign, num, d):
        self.sign, self.num, self.d = sign, num, d


# ---------- text rendering ----------
def _coef_x(a, mode):
    if a == 1:
        return "x"
    return f"{fmt_num(a, mode)}x"


def _node_parts(n, mode):
    """Return (sign, unsigned_text) for one node."""
    if isinstance(n, X):
        return (1 if n.a > 0 else -1), _coef_x(abs(n.a), mode)
    if isinstance(n, C):
        return (1 if n.b >= 0 else -1), fmt_num(abs(n.b), mode)
    if isinstance(n, Mul):
        inner = "(" + render_side(n.inner, mode) + ")"
        m = abs(n.m)
        if m == 1:
            body = inner
        elif m.denominator != 1 and mode != "dec":
            body = f"({fmt_frac(m)}){inner}"
        else:
            body = f"{fmt_num(m, mode)}{inner}"
        return (1 if n.m > 0 else -1), body
    if isinstance(n, Frac):
        num = render_side(n.num, mode)
        if len(n.num) > 1:
            num = f"({num})"
        return n.sign, f"{num}/{n.d}"
    raise TypeError(n)


def render_side(nodes, mode):
    out = ""
    for i, n in enumerate(nodes):
        s, body = _node_parts(n, mode)
        if i == 0:
            out += ("-" if s < 0 else "") + body
        else:
            out += (" - " if s < 0 else " + ") + body
    return out


# ---------- evaluation (correct and with typical student mistakes) ----------
def _ev_list(nodes, mk=None):
    a = b = F(0)
    for n in nodes:
        da, db = _ev(n, mk)
        a += da
        b += db
    return a, b


def _ev(n, mk=None):
    if isinstance(n, X):
        return n.a, F(0)
    if isinstance(n, C):
        return F(0), n.b
    if isinstance(n, Mul):
        if mk == "first_only":             # 2(x + 3) -> 2x + 3,  -(x - 2) -> -x - 2
            a0, b0 = _ev(n.inner[0])
            ar, br = _ev_list(n.inner[1:])
            return n.m * a0 + ar, n.m * b0 + br
        if mk == "neg_keep" and n.m < 0:   # -3(x - 2) -> -3x - 6
            a0, b0 = _ev(n.inner[0])
            ar, br = _ev_list(n.inner[1:])
            return n.m * a0 + abs(n.m) * ar, n.m * b0 + abs(n.m) * br
        a, b = _ev_list(n.inner)
        return n.m * a, n.m * b
    if isinstance(n, Frac):
        if mk == "frac_first_only" and n.sign < 0 and len(n.num) > 1:
            # - (x - 1)/3  ->  (-x - 1)/3   (no brackets around numerator)
            a0, b0 = _ev(n.num[0])
            ar, br = _ev_list(n.num[1:])
            return (-a0 + ar) / n.d, (-b0 + br) / n.d
        a, b = _ev_list(n.num)
        return n.sign * a / n.d, n.sign * b / n.d
    raise TypeError(n)


def _literals(nodes):
    for n in nodes:
        if isinstance(n, X):
            yield n.a
        elif isinstance(n, C):
            yield n.b
        elif isinstance(n, Mul):
            yield n.m
            yield from _literals(n.inner)
        elif isinstance(n, Frac):
            yield F(1, n.d)
            yield from _literals(n.num)


def _lcm(a, b):
    from math import gcd
    return a * b // gcd(a, b)


class Equation:
    def __init__(self, left, right, mode):
        self.left, self.right, self.mode = left, right, mode

    def text(self):
        return f"{render_side(self.left, self.mode)} = {render_side(self.right, self.mode)}"

    def linear(self, mk=None):
        """Return (A, B, Cc, D) for  A x + B = Cc x + D,  optionally with a mistake."""
        if mk in ("lcd_skip", "dec_skip") and (mk == "dec_skip") != (self.mode == "dec"):
            return None
        if mk == "lcd_skip":       # multiply fraction terms by LCD but forget whole terms
            lcd = 1
            for v in _literals(self.left + self.right):
                lcd = _lcm(lcd, F(v).denominator)
            if lcd == 1:
                return None
            def side(nodes):
                a = b = F(0)
                for n in nodes:
                    da, db = _ev(n)
                    k = lcd if isinstance(n, (Frac, Mul)) else 1
                    a += k * da
                    b += k * db
                return a, b
            return side(self.left) + side(self.right)
        if mk == "dec_skip":       # multiply decimal terms by 10/100 but forget whole terms
            dp = 1
            for v in _literals(self.left + self.right):
                if not is_dec2(v):
                    return None
                if (F(v) * 10).denominator != 1:
                    dp = 100
                elif F(v).denominator != 1:
                    dp = max(dp, 10)
            if dp == 1:
                return None
            def side(nodes):
                a = b = F(0)
                for n in nodes:
                    da, db = _ev(n)
                    has_dec = any(F(v).denominator != 1 for v in _literals([n]))
                    k = dp if has_dec else 1
                    a += k * da
                    b += k * db
                return a, b
            return side(self.left) + side(self.right)
        return _ev_list(self.left, mk) + _ev_list(self.right, mk)

    def solve(self, mk=None):
        lin = self.linear(mk)
        if lin is None:
            return None
        A, B, Cc, D = lin
        if A == Cc:
            return "inf" if B == D else "none"
        return (D - B) / (A - Cc)

    def slots(self):
        found = []
        def walk(nodes):
            for n in nodes:
                if getattr(n, "slot", False):
                    found.append(n)
                if isinstance(n, Mul):
                    walk(n.inner)
                if isinstance(n, Frac):
                    walk(n.num)
        walk(self.left)
        walk(self.right)
        return found


def _solve_slot(eq, node, attr, f, target):
    """Set node.attr so that f(eq) == target (f is affine in the slot value)."""
    setattr(node, attr, F(0))
    f0 = f(eq)
    setattr(node, attr, F(1))
    f1 = f(eq)
    if f1 == f0:
        return None
    val = (target - f0) / (f1 - f0)
    setattr(node, attr, val)
    return val


def _residual(x):
    def f(eq):
        A, B, Cc, D = eq.linear()
        return (A - Cc) * x + (B - D)
    return f


def _coef_gap(eq):
    A, B, Cc, D = eq.linear()
    return A - Cc


def _const_gap(eq):
    A, B, Cc, D = eq.linear()
    return B - D


def finish(left, right, mode, x, ok):
    """Solve the constant slot so the answer is x. ok(value) checks it looks nice."""
    eq = Equation(left, right, mode)
    cslot = [n for n in eq.slots() if isinstance(n, C)][0]
    if abs(_coef_gap(eq)) in (0, 1):     # gap of 1 skips the divide step (too easy)
        return None
    v = _solve_slot(eq, cslot, "b", _residual(x), 0)
    if v is None or not ok(v):
        return None
    if eq.solve() != x:
        return None
    return eq


# ==========================================
# 3. RANDOM PICKERS
# ==========================================
def nz(lo, hi):
    return random.choice([i for i in range(lo, hi + 1) if i != 0])


def int_ok(limit=40):
    return lambda v: v.denominator == 1 and v != 0 and abs(v) <= limit


def dec_ok(limit=40):
    return lambda v: is_dec2(v) and v != 0 and abs(v) <= limit


def frac_target(int_lo=-12, int_hi=12, p_frac=0.3):
    if random.random() < p_frac:
        while True:
            q = random.choice([2, 3, 4, 5])
            p = nz(-11, 11)
            v = F(p, q)
            if v.denominator != 1:
                return v
    return F(nz(int_lo, int_hi))


def _sometimes_neg(v, p=0.5):
    return -v if random.random() < p else v


# One-decimal values like 0.3, 1.2, 7.5 (never whole numbers)
def d1(max_tenths=99):
    while True:
        n = random.randint(1, max_tenths)
        if n % 10:
            return F(n, 10)


# Two-decimal values like 0.25, 1.35, 0.45
def d2():
    return F(random.choice([5, 15, 25, 35, 45, 55, 65, 75, 85, 95, 105, 125, 135, 145, 175, 225, 12, 24, 36, 48, 64, 84]), 100)


# ==========================================
# 4. LEVEL GENERATORS
# ==========================================

# How often the correct answer is a fraction (Topics 1, 3, 4) or a decimal
# (Topic 2), and how often a whole-number answer gets ONE fraction/decimal trap.
# These are balanced so a fraction choice is right exactly as often as a
# whole-number choice: students can't rule out a type of answer.
#   balance rule:  f * (4 - 3) = (1 - f) * k    ->   k = f / (1 - f)
ANSWER_FRAC_RATE = {1: 0.30, 2: 0.45, 3: 0.35, 4: 0.25}
FRAC_TRAP_RATE = {lvl: f / (1 - f) for lvl, f in ANSWER_FRAC_RATE.items() if lvl != 4}

# ------------------------------------------------------------------
# Level 1 - Variables on Both Sides  (integers, some negative-bracket)
#   e.g.  4x + 7 = x + 19     3 - 2x = 5x - 11     8 + x = 2 + 3x
#         -6x - 8 = -4x - 20  (DeltaMath)      2 - (-x + 1) = 3x - 7
# ------------------------------------------------------------------
def gen_level1():
    want_frac = random.random() < ANSWER_FRAC_RATE[1]
    for _ in range(3000):
        t = random.choices("abcdef", weights=[18, 14, 14, 14, 20, 20])[0]
        x = frac_target(-12, 12, 1.0 if want_frac else 0.0)
        a, c = nz(-9, 9), nz(-9, 9)
        if a == c:
            continue
        if t == "a":
            L, R = [X(a), C(nz(-15, 15))], [X(c), C(0, True)]
        elif t == "b":
            L, R = [C(random.randint(1, 15)), X(a)], [C(0, True), X(c)]
        elif t == "c":
            L, R = [C(random.randint(1, 15)), X(-abs(a))], [X(c), C(0, True)]
        elif t == "d":
            a1 = random.randint(3, 9)
            a2 = random.randint(1, a1 - 2)   # e.g. 7x - 3x, never 9x - 8x
            L, R = [X(a1), X(-a2), C(nz(-12, 12))], [X(c), C(0, True)]
        elif t == "e":   # 2 - (-x + 1) = 3x - 7
            p = _sometimes_neg(random.randint(1, 6), 0.75)
            q = _sometimes_neg(random.randint(1, 9), 0.6)
            L, R = [C(nz(-12, 12)), Mul(-1, [X(p), C(q)])], [X(c), C(0, True)]
        else:            # 4x - (-2x - 3) = 9 + x
            p = _sometimes_neg(random.randint(1, 6), 0.75)
            q = _sometimes_neg(random.randint(1, 9), 0.6)
            L, R = [X(a), Mul(-1, [X(p), C(q)])], [C(0, True), X(c)]
            if random.random() < 0.5:
                L, R = R, L
        eq = finish(L, R, "frac", x, int_ok(40))
        if eq:
            return eq
    return Equation([X(4), C(7)], [X(1), C(19)], "frac")


# ------------------------------------------------------------------
# Level 2 - Equations with Decimals (1 and 2 decimal places mixed)
#   e.g.  0.5x + 1.2 = 0.2x + 3       2(1.5x - 0.4) = x + 3.2
#         -(2x + 1.5) = x - 4.5       2 - (-6x - 1.9) - 2x = 5.9
#         2 + 2(0.2x + 3) = 0.5(4x + 4)      (DeltaMath)
#         -(-8.7x + 8) - 8 = 1.3(-x + 1) - 10 (DeltaMath)
# ------------------------------------------------------------------
_DEC_MULTS = [2, 3, 4, 5, F(2, 10), F(4, 10), F(5, 10), F(6, 10), F(15, 10), F(25, 10),
              -2, -3, F(-5, 10), F(12, 10), 6]


def _dec_target(want_dec):
    if not want_dec:
        return F(nz(-10, 10))
    r = random.random()
    if r < 0.4:
        return F(_sometimes_neg(random.choice([1, 3, 5, 7, 9, 11, 13, 15])), 2)
    if r < 0.7:
        return F(_sometimes_neg(random.choice([2, 4, 6, 8, 12, 14, 16, 18, 22, 24])), 10)
    return F(_sometimes_neg(random.choice([1, 3, 5, 7, 9, 11, 13, 15])), 4)


def gen_level2():
    want_dec = random.random() < ANSWER_FRAC_RATE[2]
    for _ in range(4000):
        mix = random.random() < 0.5            # mix in 2-decimal numbers
        def dv():
            v = d2() if (mix and random.random() < 0.4) else d1()
            return v
        def dsign(p=0.4):
            return _sometimes_neg(dv(), p)
        def xc(p=0.4):     # x-coefficient: decimal, sometimes 1
            return _sometimes_neg(F(1) if random.random() < 0.15 else dv(), p)
        t = random.choices("abcdefgh", weights=[16, 16, 14, 12, 12, 10, 10, 10])[0]
        x = _dec_target(want_dec)
        m = F(random.choice(_DEC_MULTS))
        if t == "a":
            L, R = [X(xc(0.3)), C(dsign())], [X(xc(0.3)), C(0, True)]
        elif t == "b":
            L, R = [Mul(m, [X(xc(0.2)), C(dsign())])], [X(xc()), C(0, True)]
        elif t == "c":
            L, R = [Mul(-1, [X(xc(0.3)), C(dsign())])], [X(xc()), C(0, True)]
        elif t == "d":   # 2 - (-6x - 1.9) - 2x = 5.9
            L = [C(random.randint(1, 9)), Mul(-1, [X(-dv()), C(dsign(0.7))]), X(_sometimes_neg(random.randint(1, 5), 0.6))]
            R = [C(0, True)]
        elif t == "e":   # 2 + 2(0.2x + 3) = 0.5(4x + 4)
            n = F(random.choice([2, 3, F(5, 10), F(4, 10), F(15, 10), 4]))
            L = [C(nz(-9, 9)), Mul(m if m > 0 else -m, [X(xc(0.2)), C(dsign())])]
            R = [Mul(n, [X(xc(0.2)), C(0, True)])]
        elif t == "f":   # 2.4x = 6(-0.6x - 4) - 9
            L = [X(xc(0.2))]
            R = [Mul(m, [X(xc(0.5)), C(nz(-9, 9))]), C(0, True)]
        elif t == "g":   # -(-8.7x + 8) - 8 = 1.3(-x + 1) - 10
            L = [Mul(-1, [X(_sometimes_neg(dv(), 0.7)), C(nz(-9, 9))]), C(nz(-12, 12))]
            R = [Mul(F(random.choice([12, 13, 25, 15, 4, 5, 6, 8])) / 10 if random.random() < 0.6 else F(random.randint(2, 6)),
                     [X(_sometimes_neg(1, 0.5)), C(nz(-9, 9))]), C(0, True)]
        else:            # 8.4x - (3.2x - 1) - 1 = -x
            L = [X(xc(0.2)), Mul(-1, [X(xc(0.3)), C(nz(-9, 9))]), C(0, True)]
            R = [X(_sometimes_neg(F(1) if random.random() < 0.5 else dv(), 0.5))]
        if not all(is_dec2(v) for v in _literals(L + R)):
            continue
        if all(F(v).denominator == 1 for v in _literals(L + R)):
            continue                      # every Topic 2 question must contain a decimal
        one_dp = (lambda v: (v * 10).denominator == 1) if not mix else (lambda v: True)
        if not mix and not all((F(v) * 10).denominator == 1 for v in _literals(L + R)):
            continue
        eq = finish(L, R, "dec", x, lambda v: dec_ok(40)(v) and one_dp(v))
        if eq:
            return eq
    return Equation([X(F(5, 10)), C(F(12, 10))], [X(F(2, 10)), C(3)], "dec")


# ------------------------------------------------------------------
# Level 3 - Equations with Fractions  (clear denominators, simplest form)
#   e.g.  (1/2)(7x + 10) = 2x + 9          (x - 2)/3 - (x - 1)/4 = 2
#         (x + 1)/2 = (x + 5)/3            (x - 3)/2 + (x + 1)/5 = x - 4
#         (x + 2)/3 - 1/2 = (x - 1)/4      (x + 1)/3 - 2 = (x - 1)/2
# ------------------------------------------------------------------
_FRAC_MULTS = [F(1, 2), F(1, 3), F(1, 4), F(1, 5), F(1, 8), F(2, 3), F(3, 2), F(3, 4), F(5, 3), F(2, 5)]
_DENS = [2, 3, 4, 5, 6, 8, 10, 12]


def _den_pair():
    while True:
        d1_, d2_ = random.sample(_DENS, 2)
        if _lcm(d1_, d2_) <= 24:
            return d1_, d2_


def _cancels_away(nodes):
    """True if a fraction disappears without clearing, e.g. (2x - 6)/2 or (1/2)(4x - 12)."""
    from math import gcd
    for n in nodes:
        if isinstance(n, Frac):
            parts, den = n.num, n.d
        elif isinstance(n, Mul) and n.m.denominator != 1:
            parts, den = n.inner, n.m.denominator
        else:
            continue
        g = 0
        for k in parts:
            g = gcd(g, int(k.a) if isinstance(k, X) else int(k.b))
        if g % den == 0:
            return True
    return False


def gen_level3():
    want_frac = random.random() < ANSWER_FRAC_RATE[3]
    for _ in range(4000):
        t = random.choices("abcdef", weights=[18, 20, 16, 18, 14, 14])[0]
        x = frac_target(-10, 10, 1.0 if want_frac else 0.0)
        da, db = _den_pair()
        sx = lambda: random.choice([1, 1, 1, 2, 3])
        if t == "a":   # (1/2)(7x + 10) = 2x + 9      (fraction times a bracket, x on both sides)
            m = random.choice(_FRAC_MULTS)
            L = [Mul(m, [X(random.randint(1, 9)), C(nz(-15, 15))])]
            R = [X(nz(-4, 4)), C(0, True)]
            if random.random() < 0.4:
                L, R = R, L
        elif t == "b":  # (x - 2)/3 - (x - 1)/4 = 2     (sometimes  - (-x + 1)/4 )
            a2 = _sometimes_neg(sx(), 0.3)
            L = [Frac(1, [X(sx()), C(nz(-9, 9))], da), Frac(-1, [X(a2), C(nz(-9, 9))], db)]
            R = [C(0, True)]
        elif t == "c":  # (x + 1)/2 = (x + 5)/3
            L, R = [Frac(1, [X(sx()), C(nz(-9, 9))], da)], [Frac(1, [X(sx()), C(0, True)], db)]
        elif t == "d":  # (x - 3)/2 + (x + 1)/5 = x - 4
            sign2 = random.choice([1, -1])
            L = [Frac(1, [X(sx()), C(nz(-9, 9))], da), Frac(sign2, [X(sx()), C(nz(-9, 9))], db)]
            R = [X(random.randint(1, 3)), C(0, True)]
        elif t == "e":  # (x + 2)/3 - 1/2 = (x - 1)/4     (a plain fraction term too)
            d3 = random.choice([2, 3, 4, 6])
            if _lcm(_lcm(da, db), d3) > 24:
                continue
            n = random.choice([k for k in range(1, d3) if F(k, d3).denominator == d3])
            L = [Frac(1, [X(sx()), C(nz(-9, 9))], da), Frac(random.choice([1, -1]), [C(n)], d3)]
            R = [Frac(1, [X(sx()), C(0, True)], db)]
        else:           # x/3 + 2 = (x - 1)/2   or   (x + 1)/3 - 2 = (x - 1)/2
            num = [X(1)] if random.random() < 0.4 else [X(sx()), C(nz(-9, 9))]
            L = [Frac(1, num, da), C(nz(-6, 6))]
            R = [Frac(1, [X(sx()), C(0, True)], db)]
        eq = finish(L, R, "frac", x, int_ok(40))
        if eq and not _cancels_away(eq.left + eq.right):
            return eq
    return Equation([Frac(1, [X(1), C(1)], 2)], [Frac(1, [X(1), C(5)], 3)], "frac")


# ------------------------------------------------------------------
# Level 4 - Multi-step: one solution, no solution, or infinitely many
#   e.g.  3(x + 2) - x = 2(x + 3)           (infinitely many)
#         3x - (-2x - 1) = 5(x - 1)         (no solution)
#         6x - (2x - 7) = 2(x + 5) + 1      (one solution)
#         -(5x + 3) + 10 = -3(-x - 3)       (DeltaMath)
# ------------------------------------------------------------------
def gen_level4():
    want_frac = random.random() < ANSWER_FRAC_RATE[4]      # only used for one-solution questions
    # 60/20/20 keeps guessing fair: 3 number choices vs 2 word choices on screen
    kind = random.choices(["one", "none", "inf"], weights=[60, 20, 20])[0]
    for _ in range(4000):
        t = random.choices("abcdefg", weights=[16, 16, 16, 12, 12, 14, 14])[0]
        m, n = nz(-5, 6), random.randint(2, 6)
        p, s = _sometimes_neg(random.randint(1, 4), 0.3), _sometimes_neg(random.randint(1, 4), 0.3)
        q = _sometimes_neg(random.randint(1, 9), 0.5)
        if m in (1,):
            continue
        if t == "a":    # 3(x + 2) - x = 2(x + 3)
            L = [Mul(m, [X(p), C(q)]), X(0, True)]
            R = [Mul(n, [X(s), C(0, True)])]
        elif t == "b":  # 3x - (-2x - 1) = 5(x - 1)
            L = [X(0, True), Mul(-1, [X(_sometimes_neg(p, 0.6)), C(_sometimes_neg(abs(q), 0.6))])]
            R = [Mul(n, [X(s), C(0, True)])]
        elif t == "c":  # 6x - (2x - 7) = 2(x + 5) + 1
            L = [X(0, True), Mul(-1, [X(p), C(q)])]
            R = [Mul(n, [X(s), C(nz(-9, 9))]), C(0, True)]
        elif t == "d":  # 2(3x + 1) = 6x + 5
            L = [Mul(n, [X(p), C(q)])]
            R = [X(0, True), C(0, True)]
        elif t == "e":  # 5(x + 1) - 3 = 5x + 2
            L = [Mul(m, [X(p), C(q)]), C(nz(-9, 9))]
            R = [X(0, True), C(0, True)]
        elif t == "f":  # 7(2x + 3) - 6x = -(-9x - 7) + 6x  (+ c)
            L = [Mul(n, [X(p), C(q)]), X(nz(-6, 6))]
            R = [Mul(-1, [X(-random.randint(1, 9)), C(_sometimes_neg(random.randint(1, 9), 0.6))]), X(0, True), C(0, True)]
        else:           # -(5x + 3) + 10 = -3(-x - 3)
            L = [Mul(-1, [X(random.randint(1, 6)), C(nz(-9, 9))]), C(nz(-12, 12)), X(0, True)]
            R = [Mul(-random.randint(2, 4), [X(_sometimes_neg(1, 0.6)), C(0, True)])]
        eq = Equation(L, R, "frac")
        xslot = [k for k in eq.slots() if isinstance(k, X)][0]
        cslot = [k for k in eq.slots() if isinstance(k, C)][0]
        if kind == "one":
            xslot.a = F(nz(-6, 6))
            if _coef_gap(eq) == 0:
                continue
            x = frac_target(1, 1, 1.0) if want_frac else F(nz(-10, 10))
            if finish(eq.left, eq.right, "frac", x, int_ok(40)) is None:
                continue
        else:
            v = _solve_slot(eq, xslot, "a", _coef_gap, 0)
            if v is None or v.denominator != 1 or v == 0 or abs(v) > 9:
                continue
            target = 0 if kind == "inf" else nz(-12, 12)
            w = _solve_slot(eq, cslot, "b", _const_gap, target)
            if w is None or not int_ok(40)(w):
                continue
        if eq.solve() != {"one": eq.solve(), "none": "none", "inf": "inf"}[kind]:
            continue
        return eq
    return Equation([Mul(3, [X(1), C(2)]), X(-1)], [Mul(2, [X(1), C(3)])], "frac")


# ==========================================
# 5. ANSWER OPTIONS  (1 correct + 4 traps)
# ==========================================
NO_SOL, INF_SOL = "No solution", "Infinitely many"
MISTAKES = ["first_only", "neg_keep", "frac_first_only", "lcd_skip", "dec_skip"]


def _opt(v, mode):
    if v == "none":
        return NO_SOL
    if v == "inf":
        return INF_SOL
    return f"x = {fmt_num(v, mode)}"


def _nice(v, mode, correct=None):
    if not isinstance(v, F):
        return False
    cap = max(20, 4 * abs(correct)) if isinstance(correct, F) else 20
    if abs(v) > cap:
        return False
    if mode == "dec":
        return is_dec2(v)
    return v.denominator <= 30


def _numeric_traps(eq, correct):
    """Wrong answers students actually get, most realistic first."""
    out = []
    for mk in MISTAKES:
        r = eq.solve(mk)
        if isinstance(r, F):
            out.append(r)
    A, B, Cc, D = eq.linear()
    gen = []
    if A != Cc:
        gen.append((D + B) / (A - Cc))           # moved a constant with the wrong sign
        if D != B:
            gen.append((A - Cc) / (D - B))       # divided the wrong way
        gen.append((D - B) - (A - Cc))           # subtracted instead of divided
    if A + Cc != 0:
        gen.append((D - B) / (A + Cc))           # moved an x-term with the wrong sign
    if isinstance(correct, F):
        gen.append(-correct)                     # sign error at the end
    random.shuffle(gen)
    return out + gen


def _shape(v):
    return "int" if (isinstance(v, F) and v.denominator == 1) else "frac"


def _fallbacks(correct, mode, want):
    """Plausible extra wrong answers of the wanted type ('int' or 'frac')."""
    c = correct if isinstance(correct, F) else F(random.choice([2, 3, 4, 5, 6, -2, -3]))
    out = []
    if want == "int":
        base = int(round(c))
        if c.denominator != 1:
            out += [F(c.numerator), F(c.denominator), F(-c.numerator), F(base), F(-base)]
        out += [F(base + d) for d in (1, -1, 2, -2, 3, -3, 5)] + [F(-base), F(2 * base)]
    elif mode == "dec":
        steps = [F(1, 2), F(-1, 2), F(1, 4), F(-1, 4), F(1, 10), F(-1, 10), F(3, 10), F(-3, 10)]
        out += [c + st for st in steps] + [-c + F(1, 2), c / 2, -c / 2, c / 10]
        if c.denominator != 1:
            out += [-c, c * 10]
    else:
        if c.denominator != 1:
            p, q = c.numerator, c.denominator
            out += [-c, F(p + 1, q), F(p - 1, q), F(q, p), F(p, q + 1), F(p + 2, q), c + 1, c - 1]
        else:
            for q in (2, 3, 4, 5):
                out += [F(int(c) * q + 1, q), F(int(c) * q - 1, q), F(int(c), q), F(q, int(c) or 1)]
    random.shuffle(out)
    return [v for v in out if _shape(v) == want]


def _pick_numeric(eq, correct, mode, shapes, banned):
    """
    Choose wrong numeric options, one per entry in `shapes` ('int'/'frac').
    Real student mistakes are used first; made-up near misses fill the rest.
    """
    traps = _numeric_traps(eq, correct)
    seen, chosen = set(banned), []
    for want in shapes:
        pick = None
        for v in traps + _fallbacks(correct, mode, want):
            if _shape(v) != want or not _nice(v, mode, correct):
                continue
            s_ = _opt(v, mode)
            if s_ not in seen:
                pick = s_
                break
        if pick is None:                       # last resort: any unused whole number
            for k in random.sample(range(-15, 16), 31):
                if _opt(F(k), mode) not in seen:
                    pick = _opt(F(k), mode)
                    break
        seen.add(pick)
        chosen.append(pick)
    return chosen


def get_question_and_options(level):
    """
    Returns (question_text, correct_str, [5 option strings, shuffled]).
    """
    gen = {1: gen_level1, 2: gen_level2, 3: gen_level3, 4: gen_level4}[level]
    eq = gen()
    mode = eq.mode
    correct = eq.solve()
    correct_s = _opt(correct, mode)

    if level == 4:
        if isinstance(correct, F):
            fixed = [correct_s, NO_SOL, INF_SOL]
            shapes = ["frac", "int"] if _shape(correct) == "frac" else ["int", "int"]
        else:
            other = INF_SOL if correct == "none" else NO_SOL
            fixed = [correct_s, other, "x = 0"]
            shapes = ["frac" if random.random() < 0.45 else "int" for _ in range(2)]
        options = fixed + _pick_numeric(eq, correct, mode, shapes, fixed)
    else:
        if _shape(correct) == "frac":
            shapes = ["frac", "frac", "frac", "int"]
        else:
            shapes = ["int"] * 4
            if random.random() < FRAC_TRAP_RATE[level]:
                shapes[0] = "frac"
        options = [correct_s] + _pick_numeric(eq, correct, mode, shapes, [correct_s])

    prefix = "Solve for x (simplest form):" if level == 3 else "Solve for x:"
    random.shuffle(options)
    return f"{prefix}   {eq.text()}", correct_s, options


# ==========================================
# 6. WHAT main.py CALLS
# ==========================================
TOPIC_COUNT = 4


def make_question(n):
    """(question text, correct choice, 5 choices, visual or None) for topic n (1-4)."""
    text, correct, options = get_question_and_options(n)
    return text, correct, options, None
