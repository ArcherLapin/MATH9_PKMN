# ==========================================
# team_battle.py  -  Team Battle screens for Mr. Chung's Pokemon Math Battle (Math 9).
#   Pick a topic (one room per topic) -> wait for a partner -> battle -> Master / Trainee.
#   Who is in the battle, HP, damage and the timer: top of team_net.py.
#   Which sprites a Pokemon uses: pokedex.py.
#   This file: screens and where things go on screen.
#   (Same as the Precalculus 11 game, plus: unit tabs on the topic screen, Math 9 win/lose
#    lines, and tables/graphs shown over the battle area with a Show/Hide button.)
# ==========================================
import asyncio
import random
import re

import pygame

import pokedex
import team_net as tn
from main_tool import (
    rx, ry, rs, curr_w, curr_h,
    resource_path, render_rich, fit_size, draw_center, draw_lines,
    Pokemon, Button, MessageSystem, TabBar, play_random_track, MUSIC_END_EVENT,
)

TEAM_MUSIC = [1, 2, 3]            # Kanto music: the opponents (Vaporeon, Flareon) are from Kanto
MSG_MS = 1500                     # each battle message shows this long (a click skips ahead)
VFX_SCALE = 0.6                   # attack animations are smaller than in single player

# Where the 4 Pokemon stand (screen 1080 x 950; the battle area is y = 0 to 720).
#   anchor = the point under its feet,  scale = zoom on the GIF's real size,  box = its HP box.
# Every Pokemon always has the same spot, on everyone's screen (TEAM_SETUP order):
#   your side, seen from behind:  1st of your team on the left (a bit back), 2nd on the right
#   the other side, from the front: 1st on the left (a bit back), 2nd on the right
# One zoom per side, so sizes stay natural. (Bigger/smaller overall: change the scale;
# one Pokemon only: "scale" in pokedex.py.)
# The HP boxes of the two sides mirror each other around the middle of the battle area.
SPOTS = {
    "mine1": dict(anchor=(140, 650), scale=0.65, box=(774, 520), panel=True),
    "mine2": dict(anchor=(435, 685), scale=0.70, box=(774, 614), panel=True),
    "foe1":  dict(anchor=(720, 455), scale=0.60, box=(36, 24), panel=True),
    "foe2":  dict(anchor=(905, 470), scale=0.70, box=(36, 118), panel=True),
}
TARGET_COLOR = (255, 90, 90)      # the glow on name plates you can click to attack
SIDE_COLORS = [(255, 225, 120), (255, 150, 140)]       # name text: your side, the other side

WIN_LINES = ["Both sides balanced: x = victory.",
             "Your win has a positive slope!",
             "One solution, and you found it.",
             "Checked and verified: you win!"]
LOSE_LINES = ["Every Master started as a Trainee.",
              "Rise over run: next time, you rise!",
              "No solution this time. There's always the next equation.",
              "Your line only goes up from here!"]


# ==========================================
# 1. SMALL HELPERS
# ==========================================
def short_topic(title):
    """'4.4 Factored Form' -> 'Factored Form',  'Unit Review (all lessons)' -> 'Unit Review'."""
    t = re.sub(r"^\d+\.\d+\s+", "", title)
    return re.sub(r"\s*\(.*?\)", "", t).strip()


def join_names(names):
    return names[0] if len(names) == 1 else ", ".join(names[:-1]) + " and " + names[-1]


async def frame(clock, fps):
    pygame.display.update()
    await asyncio.sleep(0)
    clock.tick(fps)


def click_sound(sounds):
    if sounds.get("click"):
        sounds["click"].play()


def draw_note(screen, net, text=""):
    if net is not None and net.errors >= 3:
        text = "Can't reach the team server. Check the internet connection (retrying...)."
    if text:
        draw_center(screen, text, 22, (150, 20, 20), 905)


async def message_screen(screen, clock, fps, lines):
    """A few lines of text. Click to go back."""
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return "quit"
            if event.type == pygame.MOUSEBUTTONDOWN:
                return None
        screen.fill((128, 128, 128))
        for i, line in enumerate(lines):
            draw_center(screen, line, 30 if i == 0 else 24, (0, 0, 0), 300 + i * 55)
        draw_center(screen, "Click anywhere to go back.", 22, (40, 40, 40), 800)
        await frame(clock, fps)


# ==========================================
# 2. TOPIC SCREEN (one tab per unit, one room per topic) AND WAITING ROOM
# ==========================================
async def topic_screen(screen, clock, fps, sounds, net, sync, lobby, api, note=""):
    """Returns a topic level, None for Back, or 'quit'."""
    units = api.units                                   # (key, tab name, heading, ready?)
    keys = [u[0] for u in units]
    tabs = TabBar([u[1] for u in units], y=130)
    ready = [u[3] for u in units]

    def make_buttons(unit_key):
        out = []
        rows = [t for t in api.topics if t[4] == unit_key]
        for i, (level, title, is_open, lock, _) in enumerate(rows):      # up to 8: 4 rows of 2
            b = Button(120 + (i % 2) * 440, 240 + (i // 2) * 80, 400, 66)
            b.level, b.title, b.is_open, b.lock = level, title, is_open, lock
            out.append(b)
        return out

    buttons = make_buttons(api.ui["unit"])
    back = Button(40, 860, 160, 60)
    back.text = "Back"
    humans = [tn.slot_name(i) for i in tn.HUMAN_SLOTS]
    subtitle = f"You and your partner: {join_names(humans)}" if len(humans) == 2 \
        else f"{tn.ROOM_SIZE} students per battle"
    while True:
        net.update()
        if sync.update():
            lobby.update()
        for b in buttons:
            st = (lobby.status or {}).get(b.level)
            b.open = b.is_open and st is not None and st[0] == "open" and st[1] < tn.ROOM_SIZE
            if not b.is_open:
                b.text = b.title + b.lock
            elif st is None:
                b.text = f"{b.title}   ..."
            elif st[0] == "busy":
                b.text = f"{b.title}   (battle in progress)"
            else:
                b.text = f"{b.title}   {min(st[1], tn.ROOM_SIZE)}/{tn.ROOM_SIZE}"
            b.color, b.text_color = ((150, 200, 200), (0, 0, 0)) if b.open else ((170, 170, 170), (100, 100, 100))

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return "quit"
            if event.type == pygame.MOUSEBUTTONDOWN:
                if back.clicked(event.pos):
                    click_sound(sounds)
                    return None
                t = tabs.clicked(event.pos)
                if t is not None:
                    if ready[t]:                        # a grey "coming soon" tab does nothing
                        click_sound(sounds)
                        api.ui["unit"] = keys[t]
                        buttons = make_buttons(api.ui["unit"])
                    break
                for b in buttons:
                    if b.clicked(event.pos) and b.open:
                        click_sound(sounds)
                        return b.level

        screen.fill((128, 128, 128))
        draw_center(screen, "Team Battle: pick a topic", 46, (0, 0, 0), 50)
        draw_center(screen, subtitle, 26, (20, 40, 90), 100)
        active = keys.index(api.ui["unit"])
        tabs.draw(screen, active, ready)
        draw_center(screen, units[active][2], 26, (20, 40, 90), 212)
        for b in buttons:
            b.draw(screen)
        draw_center(screen, f"A battle starts as soon as {tn.ROOM_SIZE} students pick the same topic.",
                    22, (40, 40, 40), 600)
        back.draw(screen)
        draw_note(screen, net, note)
        await frame(clock, fps)


async def waiting_screen(screen, clock, fps, sounds, net, waiter, title):
    """Returns ('start', game), ('full', None), ('exit', None) or ('quit', None)."""
    exit_btn = Button(390, 640, 300, 70)
    exit_btn.text = "Exit"
    while True:
        net.update()
        waiter.update()
        if waiter.result:
            return waiter.result
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                waiter.leave()
                return "quit", None
            if event.type == pygame.MOUSEBUTTONDOWN and exit_btn.clicked(event.pos):
                click_sound(sounds)
                waiter.leave()
                return "exit", None
        screen.fill((128, 128, 128))
        dots = "." * (1 + (pygame.time.get_ticks() // 500) % 3)
        draw_center(screen, title, 44, (0, 0, 0), 170)
        draw_center(screen, f"Waiting for players{dots}", 36, (0, 0, 0), 320)
        draw_center(screen, f"{min(waiter.count, tn.ROOM_SIZE)} / {tn.ROOM_SIZE} players", 44, (20, 40, 90), 420)
        draw_center(screen, "The battle starts by itself when everyone is here.", 24, (40, 40, 40), 520)
        exit_btn.draw(screen)
        draw_note(screen, net)
        await frame(clock, fps)


# ==========================================
# 3. THE BATTLE
# ==========================================
async def battle_screen(screen, clock, fps, sounds, vfx, api, net, clk, battle, level):
    """Plays one battle. Returns True (my side won), False (lost), None (reset), or 'quit'."""
    me = battle.slot
    my_side = tn.slot_team(me)
    partners = [i for i in tn.teammates(me) if i != me]
    foes = tn.foes(me)
    nm = tn.slot_name

    # Pokemon on screen: same spot for each Pokemon on every screen ("(you)" marks yours).
    fighters = {}
    mine = tn.teammates(me)
    places = list(zip(mine[:2], ["mine1", "mine2"])) + list(zip(foes[:2], ["foe1", "foe2"]))
    for i, place in places:
        hp = tn.TEAM_SETUP[i]["hp"]
        mon = Pokemon(nm(i), hp, hp, 100, 100, vfx, view="back" if tn.slot_team(i) == my_side else "front",
                      spot=SPOTS[place], vfx_scale=VFX_SCALE)
        mon.label = nm(i) + ("  (you)" if i == me else "")
        mon.label_color = SIDE_COLORS[0 if tn.slot_team(i) == my_side else 1]
        fighters[i] = mon
    draw_order = [i for i, place in places if place in ("foe2", "foe1", "mine2")] + \
                 [i for i, place in places if place == "mine1"]

    ms = MessageSystem()
    msg_since = [0]
    title = api.topic_title(level)
    if battle.state.entries:                                # joined part-way (should be rare)
        battle.skip_old()
    else:
        ms.add(f"Team Battle: {title}!")
        ms.add(f"You are {nm(me)}!" + (f"  Your partner is {join_names([nm(i) for i in partners])}." if partners else ""))
    for i, mon in fighters.items():
        mon.hp = battle.state.hp[i]
        if mon.hp <= 0:
            mon.fainted = True

    buttons = [Button(80, 795, 290, 60), Button(395, 795, 290, 60), Button(710, 795, 290, 60),
               Button(80, 865, 290, 60), Button(395, 865, 290, 60), Button(710, 865, 290, 60)]
    graph_button = Button(850, 744, 140, 42, color=(250, 215, 90))
    turn = {"q": None, "key": None, "panel": None, "graph_open": False, "pick": False}

    def load_img(name, size):
        try:
            return pygame.transform.scale(pygame.image.load(resource_path(name)), size)
        except (pygame.error, FileNotFoundError, OSError):
            return None
    bg = load_img("background.jpg", (curr_w, ry(720)))
    tb = load_img("textbox.png", (curr_w, curr_h - ry(720)))

    sounds["music_pool"] = TEAM_MUSIC
    play_random_track(TEAM_MUSIC)

    def new_question():
        q = api.next_question(level)
        turn["q"], turn["key"] = q, battle.state.next_key
        turn["panel"] = api.build_graph_panel(q.graph) if q.graph else None
        turn["graph_open"], turn["pick"] = False, False
        for k in range(5):
            buttons[k].text = q.options[k]
        buttons[5].text = f"Sitrus Berry x{battle.state.berries[me]}"

    def asking():
        """True while I'm looking at my question."""
        return (battle.my_turn() and not ms.has_active_message() and not battle.state.over
                and turn["key"] == battle.state.next_key and turn["q"] is not None)

    def targets():
        """Opponents I can attack (still standing)."""
        return [i for i in foes if battle.state.hp[i] > 0]

    def attack(target):
        """Send my correct answer with the opponent I picked."""
        d, x = battle.damage_now()
        battle.send("ok", d, x, target=target)
        turn["q"], turn["pick"] = None, False

    def click(pos):
        if turn["graph_open"]:                        # a click hides the table/graph...
            turn["graph_open"] = False
            if not any(b.clicked(pos) for b in buttons):
                return None                           # ...and a click on an answer also answers
        if ms.has_active_message():
            ms.clear()
            return None
        if battle.state.over:
            return "done"
        if not asking():
            return None
        if turn["pick"]:                              # correct answer: click a name plate
            for i in targets():
                if fighters[i].box_rect().collidepoint(pos):
                    click_sound(sounds)
                    attack(i)
                    return None
            return None
        if turn["panel"] is not None and graph_button.clicked(pos):
            click_sound(sounds)
            turn["graph_open"] = True
            return None
        for btn in buttons:
            if not btn.clicked(pos):
                continue
            click_sound(sounds)
            if btn is buttons[5]:
                if battle.state.berries[me] <= 0:
                    ms.add("You are out of Berries!")
                elif battle.state.hp[me] >= battle.state.max_hp[me]:
                    ms.add("Your HP is already full!")
                else:
                    battle.send("be")
                return None
            q = turn["q"]
            if btn.text == q.correct:
                if sounds.get("correct"):
                    sounds["correct"].play()
                if len(targets()) == 1:               # only one opponent left: no need to pick
                    attack(targets()[0])
                else:
                    turn["pick"] = True
                    turn["graph_open"] = False
            else:
                battle.send("no", correct_text=q.correct)
                turn["q"] = None
            return None
        return None

    def draw_clock(s, compact):
        """Whose turn (and the clock).  compact = a smaller box in the corner (table/graph open)."""
        if s.over or s.active is None:
            return
        if tn.is_ai(s.active):
            label, col = f"{nm(s.active)}'s turn", (0, 0, 0)
        else:
            secs = tn.time_left(s, clk.now())
            who = "Your turn" if s.active == me else f"{nm(s.active)}'s turn"
            label = f"{who}   {secs // 60}:{secs % 60:02d}"
            col = (200, 20, 20) if secs <= 10 else (0, 0, 0)
        box = pygame.Rect(rx(875), ry(6), rx(198), ry(44)) if compact else pygame.Rect(rx(760), ry(10), rx(310), ry(62))
        pygame.draw.rect(screen, (255, 255, 255), box)
        pygame.draw.rect(screen, (0, 0, 0), box, max(1, rs(3)))
        t = render_rich(label, fit_size(label, 22 if compact else 28, 180 if compact else 290), col)
        screen.blit(t, t.get_rect(center=box.center))

    while True:
        net.update()
        battle.update()
        if battle.gone:
            pygame.mixer.music.stop()
            await message_screen(screen, clock, fps, ["This battle was reset.", "Pick a topic to play again."])
            return None
        s = battle.state

        for text, target, change, effect in battle.new_messages():
            mon = fighters.get(target)
            if change < 0:
                anims, snd = pokedex.EFFECTS.get(effect, pokedex.EFFECTS["hit"])
                ms.add(text, target=mon, hp_change=change, vfx=anims, sound=sounds.get(snd))
            else:
                ms.add(text, target=mon, hp_change=change)

        # messages move on by themselves (a click skips ahead)
        had = bool(ms.current)
        ms.update()
        if ms.current and not had:
            msg_since[0] = pygame.time.get_ticks()
        if ms.current and pygame.time.get_ticks() - msg_since[0] > MSG_MS:
            ms.clear()
        if not ms.has_active_message():
            for i, mon in fighters.items():
                mon.hp = s.hp[i]                      # stay exactly in step with the turn log
        for mon in fighters.values():
            if mon.hp <= 0:
                mon.play_faint_sound()

        if battle.my_turn() and not s.over and turn["key"] != s.next_key and not ms.has_active_message():
            new_question()
        # Picked the right answer but not a target, and time is nearly up: attack the usual one.
        if turn["pick"] and battle.my_turn() and clk.now() >= s.deadline - 1500:
            attack(tn.target_for(me, s.hp))

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return "quit"
            if event.type == MUSIC_END_EVENT:
                play_random_track(sounds.get("music_pool") or [])
            if event.type == pygame.MOUSEBUTTONDOWN:
                if click(event.pos) == "done":
                    pygame.mixer.music.stop()
                    return s.winner == my_side
            elif event.type == pygame.KEYDOWN and turn["graph_open"]:
                turn["graph_open"] = False

        # ---------- draw ----------
        screen.fill((0, 0, 0))
        if bg: screen.blit(bg, (0, 0))
        pygame.draw.rect(screen, (75, 117, 155), (0, ry(720), curr_w, curr_h - ry(720)))
        if tb: screen.blit(tb, (0, ry(720)))
        for i in draw_order:
            fighters[i].draw(screen, active=(i == s.active and not s.over))

        showing = turn["graph_open"] and turn["panel"] is not None and asking()
        if showing:                                      # table/graph over the battle area
            api.draw_graph_overlay(screen, turn["panel"])
        draw_clock(s, compact=showing)

        if ms.has_active_message():
            ms.draw(screen)
        elif s.over:
            draw_lines(screen, "Click anywhere to continue.", (0, 0, 0), 80, 765, 920)
        elif asking() and turn["pick"]:
            draw_lines(screen, "Correct!  Click the name of the Pokemon you want to attack.",
                       (255, 255, 255), 85, 768, 905)
            if (pygame.time.get_ticks() // 300) % 2 == 0:          # blinking glow on the plates
                for i in targets():
                    pygame.draw.rect(screen, TARGET_COLOR, fighters[i].box_rect(), max(3, rs(5)))
        elif asking():
            has_graph = turn["panel"] is not None
            draw_lines(screen, turn["q"].text, (255, 255, 255), 85, 760, 755 if has_graph else 905)
            for btn in buttons:
                btn.draw(screen)
            if has_graph:
                kind = getattr(turn["q"].graph, "kind", "Graph")
                graph_button.text = ("Hide " if turn["graph_open"] else "Show ") + kind
                graph_button.draw(screen)
        elif s.active == me:
            draw_lines(screen, "Sending your answer...", (255, 255, 255), 85, 768, 905)
        elif s.active is not None:
            wait = "is getting ready..." if tn.is_ai(s.active) else "is answering..."
            draw_lines(screen, f"{nm(s.active)} {wait}", (255, 255, 255), 85, 768, 905)

        draw_note(screen, net)
        await frame(clock, fps)


async def title_screen(screen, clock, fps, sounds, won, topic, partner_names):
    """Master of ... / Trainee of ...  Click (after a short delay) to continue."""
    start = pygame.time.get_ticks()
    line = random.choice(WIN_LINES if won else LOSE_LINES)
    who = f"You and {join_names(partner_names)} are now" if partner_names else "You are now"
    if won and sounds.get("correct"):
        sounds["correct"].play()
    while True:
        ready = pygame.time.get_ticks() - start > 1500
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return "quit"
            if event.type == pygame.MOUSEBUTTONDOWN and ready:
                click_sound(sounds)
                return None
        screen.fill((150, 115, 20) if won else (40, 70, 120))
        draw_center(screen, "YOUR TEAM WON!" if won else "Your team lost this time.", 40, (255, 255, 255), 170)
        draw_center(screen, who, 28, (255, 255, 255), 270)
        box = pygame.Rect(rx(90), ry(330), rx(900), ry(170))
        pygame.draw.rect(screen, (255, 255, 255), box)
        pygame.draw.rect(screen, (0, 0, 0), box, max(1, rs(4)))
        title = ("Master of " if won else "Trainee of ") + topic
        draw_center(screen, title, fit_size(title, 60, 860), (120, 80, 0) if won else (20, 40, 90), 415)
        draw_center(screen, line, fit_size(line, 28, 980), (255, 255, 255), 580)
        if ready:
            draw_center(screen, "Click anywhere to go back to the topics.", 24, (230, 230, 230), 800)
        await frame(clock, fps)


# ==========================================
# 4. THE WHOLE TEAM MODE  (called from main.py)
# ==========================================
async def team_mode(screen, clock, fps, sounds, vfx, api):
    """Returns None (back to the start screen) or 'quit'."""
    if not tn.FIREBASE_URL:
        return await message_screen(screen, clock, fps, [
            "Team Battle isn't set up yet.", "Add the Firebase database URL at the top of team_net.py."])
    try:
        net = tn.Net(tn.FIREBASE_URL, tn.make_transport())
    except Exception:
        return await message_screen(screen, clock, fps, ["Team Battle can't connect from this browser."])
    clk = tn.Clock()
    me = tn.new_id()
    sync = tn.ClockSync(net, clk, me)
    lobby = tn.Lobby(net, clk, [t[0] for t in api.topics])

    note = ""
    while True:
        level = await topic_screen(screen, clock, fps, sounds, net, sync, lobby, api, note)
        if level in (None, "quit"):
            return level
        note = ""
        title = api.topic_title(level)
        waiter = tn.Waiter(net, clk, level, me)
        kind, game = await waiting_screen(screen, clock, fps, sounds, net, waiter, title)
        if kind == "quit":
            return "quit"
        if kind == "full":
            note = f"{title} just started without you. Pick it again in a moment, or another topic."
            continue
        if kind != "start":
            continue
        battle = tn.Battle(net, clk, level, me, game)
        won = await battle_screen(screen, clock, fps, sounds, vfx, api, net, clk, battle, level)
        if won == "quit":
            return "quit"
        if won is None:
            continue
        partners = [tn.slot_name(i) for i in tn.teammates(battle.slot) if i != battle.slot]
        if await title_screen(screen, clock, fps, sounds, won, short_topic(title), partners) == "quit":
            return "quit"
        lobby.status = None                  # refresh the topics
